# PRD・ADR・BDD 文書キット（是正版 2.0.0）

確認日：2026-09-19。受領した `PRD_ADR_BDD_Kit_20260919.zip`（版1.0.0）を敵対的にレビューし、指摘を是正して作り直したもの。形式は UTF-8 の Markdown と Mermaid。特定のベンダー・言語・AI 製品に依存しない。

## 構成

| 分類 | テンプレート | 記入例 | 記載指示書 |
|---|---|---|---|
| PRD | [prd/PRD_TEMPLATE.md](prd/PRD_TEMPLATE.md) | [prd/PRD_SAMPLE.md](prd/PRD_SAMPLE.md) | [prd/PRD_GUIDE.md](prd/PRD_GUIDE.md) |
| ADR | [adr/ADR_TEMPLATE.md](adr/ADR_TEMPLATE.md) | [ADR-0001](adr/ADR-0001-ai-authority-boundary.md)・[ADR-0002](adr/ADR-0002-decision-consistency.md) | [adr/ADR_GUIDE.md](adr/ADR_GUIDE.md) |
| BDD | [bdd/BDD_TEMPLATE.md](bdd/BDD_TEMPLATE.md) | [bdd/BDD_SAMPLE.md](bdd/BDD_SAMPLE.md) | [bdd/BDD_GUIDE.md](bdd/BDD_GUIDE.md) |

| 共通 | 内容 |
|---|---|
| [01_ADVERSARIAL_REVIEW.md](01_ADVERSARIAL_REVIEW.md) | 元キットへの指摘19件（証拠・根本原因・是正・再発を止める検査） |
| [02_RESEARCH_AND_DECISIONS.md](02_RESEARCH_AND_DECISIONS.md) | 出典（今回確認したものと継承したものを区別）と採用判断 |
| [03_CONVENTIONS.md](03_CONVENTIONS.md) | 正本・ID・関係・状態・ゲート・Markdown と Mermaid の規約 |
| [04_TRACEABILITY.md](04_TRACEABILITY.md) | 追跡表（**自動生成**。手で編集しない） |
| [05_AI_AGENT_INSTRUCTIONS.md](05_AI_AGENT_INSTRUCTIONS.md) | AI エージェントと人への作業指示、レビュー指示、実装への引き継ぎ |
| [90_VALIDATION_REPORT.md](90_VALIDATION_REPORT.md) | 実際に行った検証と結果、未実施の範囲 |
| `features/` | BDD 記入例から生成した `.feature`（**自動生成**） |
| `tools/`・`kit.toml`・`evidence/` | リンター、Mermaid 描画検証、設定、検証の証跡 |

## 使い方

1. テンプレートを自分のリポジトリにコピーし、`kit.toml` の `[docs]` を自分の文書のパスに書き換える。
2. 記載指示書に沿って記入する。見出しに「（任意）」が付く節は、不要なら節ごと削除する。
3. `python tools/kit_lint.py trace`、`extract`、`check` の順に実行する。依存は `pip install gherkin-official PyYAML`。
4. 図を変えたら `python tools/render_mermaid.py --mermaid-dir <npm の mermaid>` を実行する。

## 記入例について

FlowApprove（社内ソフトウェア利用申請とAI審査補助）は架空の題材で、組織・数値・期間・承認はすべて説明用である。記入例は「利用者が書く値の例」になるよう、正規の状態（draft・accepted など）を書き、架空であることは front matter の `sample: true` で示している。製品の実装・試験・実在の承認は存在しない。

## このキットが保証しないこと

リンターの合格は、構造・参照・構文の整合を示すだけである。要件が妥当か、具体例が業務上足りているか、設計判断が正しいかは、人が確かめる。規制のある領域（医療・金融・安全など）では、適用される制度の要求を別に定める必要がある。
