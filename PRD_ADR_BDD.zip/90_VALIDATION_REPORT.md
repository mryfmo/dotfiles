# 検証報告

実施日：2026-09-19。ここに書くのは、この作業の中で実際に実行した検証だけである。検証の対象は文書であり、製品（FlowApprove は架空で未実装）の試験ではない。レビューと是正は同一の主体（Claude）が行っており、独立した第三者レビューではない。

## 1. 実行した検証と結果

| 検証 | 方法 | 結果 | 証跡 |
|---|---|---|---|
| 文書の全検査 | `python tools/kit_lint.py check` | 合格（エラー0・警告0）。FR 28・NFR 9・ルール 23・シナリオ 41（展開後 66 ケース）・ADR 2・図 11 | `evidence/kit_lint_check.json` |
| Gherkin の構文 | Cucumber 公式 parser（gherkin-official 42.0.1）で、記入例の8機能とテンプレートの1機能を解析し pickle に展開。記載指示書の例2件も単独で解析 | すべて成功 | 同上 |
| テンプレートと記入例の一致 | 必須節・節の順序・表の見出し・front matter のキーを機械照合 | PRD・ADR 2件・BDD とも一致 | 同上 |
| 要件の形式 | EARS の型と構文、1文、文末、優先度、根拠IDの実在、受入の存在 | 28件とも適合。優先度は Must 25・Should 2・Could 1 | 同上 |
| 目的・指標の接続 | 全 GOAL が FR の根拠になっているか、全指標に計測手段があるか | 適合 | 同上 |
| 要件とルールの双方向照合 | PRD の「受入」列のルールIDと、シナリオの要件タグから逆算したルールの集合を比較 | 28件とも一致 | 同上 |
| ステップ語彙の再利用 | 数値と引用符の中身を除いた文型の一回限り率 | 0.384（172ステップ・66文型。元キットは0.875） | 同上 |
| ADR | 状態語彙、`addresses` の実在、選択肢2つ以上、採用案が一覧にある、全案に短所、確認方法 | 2件とも適合 | 同上 |
| 生成物の一致 | 追跡表と `features/*.feature` を正本から再生成した内容と比較 | 一致 | 同上 |
| Mermaid の描画 | 公式 npm 配布物の Mermaid 11.14.0 と 12.0.0 を Chromium で実行し、全11図を解析・描画。不正な図が拒否されることも確認 | 両方の版で 11/11 成功。全図に代替テキスト（title 要素）あり | `evidence/mermaid_render.json` |
| 描画証跡の鮮度 | 証跡に記録した図ごとの SHA-256 と現行の図を照合 | 一致 | `evidence/kit_lint_check.json` |
| 図の目視 | PRD の状態図と ADR-0002 のシーケンス図を 12.0.0 で画像化して確認 | 日本語の表示・矢印・失われた応答の表現に問題なし | 画像は同梱していない |
| リンターの変異試験 | 18種類の欠陥（2文の要件、型の不一致、存在しない根拠、検証計画の欠落、必須節の改名、構文破壊、ID重複、未知のタグ、受入との不一致、試験用語、採用案の不一致、addresses 不正、状態語彙外、リンク切れ、列数、古い描画証跡、追跡表と .feature の手修正）を1つずつ注入 | 18件とも検出 | `evidence/kit_lint_selftest.json` |
| 移植性 | テンプレートだけから、別名・別ディレクトリ構成で任意節を全て削除した最小プロジェクトを作り、`trace`・`extract`・`check` を実行 | 合格（Mermaid 証跡が無い旨の警告のみ）。**この試験で、追跡表を下位ディレクトリに置くとリンクが切れる不具合を発見し修正した** | `evidence/portability_test.json` |

## 2. 是正版に対する敵対的レビューで見つけ、直したもの

| 見つけた問題 | 原因 | 是正 |
|---|---|---|
| 同時に届いた決裁の敗者（SCN-021）と期限後の再送（SCN-025）は、「版の不一致」と「終端状態」の両方に当たり、どちらの拒否理由を返すかが要件から決まらなかった。順序によっては、権限のない相手に終端状態であることが漏れる | 拒否条件を要件ごとに独立に書き、重なりを検討していなかった | 優先順位の要件 FR-028 を追加し、RULE-023（SCN-041・SCN-042）で具体化。Discovery の記録と変更履歴にも反映 |
| 追跡表のリンクが、追跡表をリポジトリ直下に置く前提になっていた | 記入例の構成でしか試していなかった | 追跡表の置き場所からの相対パスを計算するよう修正。移植性試験を同梱して再発を検出 |
| リンターが、表の中でインラインコードとして示したアンカーの書き方を、本物のアンカーとして数えていた | 本文とコードの区別が不十分 | アンカーとリンクの検出からインラインコードを除外 |
| 参考意見と内容版の結び付き（版の取り違え防止という目的の中心）が要件に無かった | 元キットの要件を分解する際に落とした | FR-027 と RULE-022（SCN-040）を追加 |

## 3. 環境

| 項目 | 値 |
|---|---|
| Python | 3.12.3 |
| gherkin-official | 42.0.1（2026-08-05公開、確認時点で最新） |
| PyYAML | 6.0.3 |
| Mermaid | 11.14.0、12.0.0（2026-09-10公開）。いずれも npm の公式配布物 `dist/mermaid.min.js` |
| ブラウザ | Playwright 同梱の Chromium（版は `evidence/mermaid_render.json` に記録） |

## 4. 実施していないこと

| 項目 | 理由・扱い |
|---|---|
| 製品の実装、シナリオの実行、NVT の実行 | FlowApprove は架空。`last_run: not_run`、ADR の確認結果は「未実施」のまま |
| 実行ツール（Cucumber-JVM・pytest-bdd など）での `.feature` の読み込み | 公式 parser での解析までを確認。実行ツールの選定は利用者の案件で行う |
| GitHub・GitLab・VS Code などでの表示確認 | 各環境が採用する Mermaid の版と Markdown の方言は環境ごとに異なる。明示アンカーに `<a id>` を使っているため、HTML を除去する環境ではアンカーが効かない |
| 業務責任者による内容の妥当性確認、独立した第三者によるレビュー | 未実施。具体例が業務上足りているかは機械検査の対象外 |
| 継承した出典の再確認 | 02_RESEARCH_AND_DECISIONS.md で「継承」と明示したものは今回確認していない |
| ISO/IEC 25010:2023 の本文の確認 | 有償のため、ISO の概要ページと arc42 の解説で確認。日本語の特性名は仮訳 |

## 5. 再現手順

```text
pip install gherkin-official PyYAML playwright
playwright install chromium
npm install mermaid@12.0.0            # 別のディレクトリで mermaid@11.14.0 も
python tools/kit_lint.py trace
python tools/kit_lint.py extract
python tools/render_mermaid.py --mermaid-dir <.../node_modules/mermaid> [--mermaid-dir ...]
python tools/kit_lint.py check --json evidence/kit_lint_check.json
python tools/kit_lint.py selftest --json evidence/kit_lint_selftest.json
python tools/portability_test.py
```
