# Jev All Engines — 指定全エンジンの統合実装

バージョン: 3.0.0 / 作業・検証日: 2026-09-21（JST）

## 配布物の位置づけ

目的・入力・制約を入口として、LDP/Aviaryを介した能力選択・実行・再計画、原文と観測の保持、独立評価、GEPA/Trace/AFlow/AutoSkillによる候補生成・再利用を接続するPython実装です。**LDP、Aviary、OpenFugu、Router-R1、ROMA、AutoSkill、AFlow、Trace、XGrammar、GEPA、GLiNER2は全て必須対象のままです。Jevと生成LLMのサービスも必要です。**

**この配布物の全ネイティブ受入試験は不合格です。全エンジン・実モデルを通した完成版ではありません。** `docs/VERIFICATION_ja.md` と `reports/native-acceptance.json` が今回実施した検証の正本です。ソースの接続実装、固定応答による契約試験、公開エンジン本体の実行、実モデルでの業務品質を区別しています。未導入のエンジンを独自アルゴリズムで代替する経路はありません。

過去の完成報告やテスト件数は、この版の合格根拠に使用していません。今回のZIPには、保存されたコード・データ・ログを実際に収録し、`MANIFEST.json`でファイル単位の整合性を確認できるようにしています。

## 実装した接続

| 能力 | 元エンジンの使用箇所 |
|---|---|
| 状態に基づく操作選択 | LDP `Agent` / `FxnOp` / `compute_graph` |
| ツール実行と観測 | Aviary `Environment` / `Tool` / `exec_tool_calls` |
| 処理編成・学習済みルーティング | OpenFugu `ConductorExecutor` / `FuguRouter` |
| 多段モデルルーティング | Router-R1 公開 `infer_vllm.py` |
| 再帰的分解・計画・集約 | ROMA `RecursiveSolver.async_solve` |
| スキル形成・検索 | AutoSkill `ingest` / `search` |
| ワークフロー構造探索・再利用 | AFlow `Optimizer` / `GraphUtils` |
| グラフからの改善 | Microsoft Trace `OptoPrime` |
| 制約付き生成 | XGrammar コンパイラー / matcher / token mask / HF LogitsProcessor |
| 全体実行の改善 | GEPA `optimize` / `GEPAAdapter` |
| 原文の情報抽出 | GLiNER2 `AutoExtractor` |
| 型付きの判断 | Jev REST / Choice・Score・Noul応答検証 |
| 目的解釈・推論・生成 | 管理者が登録したChat CompletionsまたはAnthropic Messages |

この表は**呼び出すコードの対応表**であり、全項目の実行成功を意味しません。実行結果は別の検証表に記録します。詳細は `docs/ENGINE_INTEGRATION.md`、構成・境界は `docs/ARCHITECTURE.md` を参照してください。

## 1. ファイルを検査する

ZIP展開後、展開元のZIPに対して実行します。Pythonの標準ライブラリだけを使用します。

```bash
python scripts/verify_package.py ../jev-all-engines.zip
```

CRC、全収録ファイル、サイズ、SHA-256、ソースツリーのハッシュを照合します。外部の独立した電子署名ではありません。再展開する場合は `--extract` に**存在しない新しいディレクトリ**を指定します。既存ファイルを上書きしません。

```bash
python scripts/verify_package.py ../jev-all-engines.zip --extract ../verified-copy
```

## 2. 共通ホスト環境と契約試験

共通ホストの対象はPython 3.12〜3.14、実機検証はLinux/Python 3.13.5です。Router-R1は別のPython 3.10環境を使用します。全構成の配備対象はLinuxです。Mac/Windows上で全エンジンを実行済みとはしていません。

```bash
uv sync --extra dev
uv run pytest
uv run jev-all --help
```

契約試験では、外部モデル・実エンジンを模した応答を使うテストを明示しています。これを実モデルの能力評価に数えません。製品の起動コマンドに、テスト用の代替モデルを登録する機能はありません。

`uv sync` は依存取得可能な環境を必要とします。この配布物に全依存解決済みの `uv.lock` は含めていません。`configs/engines.lock.json` は元ソースのコミットと主要版を固定するファイルであり、全ての間接依存まで固定したlockfileではありません。

## 3. 指定された全エンジンの環境を構築する

```bash
uv run python scripts/bootstrap.py --workers 3
```

全11対象を取得し、各エンジン専用の仮想環境を作成します。元ソースのコミット、取得失敗、依存解決、`uv pip check` とインストール後のfreezeは `native_envs/reports/` に記録します。一つでも失敗すると終了コードは2です。対象除外や、失敗を成功と扱うオプションはありません。

生成される `native_envs/runtime.generated.json` を配備用設定の基準にします。各エンジンは同じPython環境へ無理に混載せず、共通の操作・観測プロトコルで接続します。

**同梱wheelについて:** `third_party/wheels/` はこの環境で取得できた原本9個です。全エンジンや全OSのオフラインインストール一式ではありません。Linux/CPython 3.13専用のバイナリを含みます。`--offline` は、既に正しいGitソースと必要な全wheelがそろっている場合の利用向けであり、この配布物だけで成功したとはしていません。

## 4. 実モデルとサービスを結び付ける

秘密値は環境変数で指定し、設定JSON・配布ZIPに書き込みません。

```bash
export JU_LLM_API_KEY='配備先の生成LLMキー'
export JU_JEV_API_KEY='配備先のJevキー'
export JEV_API_TOKEN="$(uv run python -c 'import secrets; print(secrets.token_urlsafe(32))')"
```

ローカルで取得・利用許諾を確認したモデルディレクトリは、`scripts/pin_model.py` で**全ファイル**をハッシュ固定します。これは取得や精度評価を行うコマンドではありません。

```bash
uv run python scripts/pin_model.py /models/gliner2 --name gliner2 \
  --revision '確認した固定revision' --output config-private/gliner2-pin.json
```

モデル名は `gliner2`、`router_r1`、`openfugu_backbone`、`structured_llm` を使用します。複数のpin JSONを一つのオブジェクトに統合した `models.json` を指定します。OpenFuguのルーター係数は `openfugu_vector` に `path` と `sha256` を設定します。公開済みの学習済みチェックポイントを使用するための接続であり、この環境でRouter-R1/OpenFuguの再学習を実施したわけではありません。

Router-R1が使用するプール内のモデルIDには、`services.llm.routes` で個別の実モデルを明示的に結び付けます。不明なモデルIDを無視して全て同じモデルへ転送することはありません。

```json
{
  "登録したモデルID": {
    "endpoint": "https://管理者が確認したサービス/v1/chat/completions",
    "model": "固定したモデルID",
    "api_key_env": "WORKER_MODEL_API_KEY",
    "external": true,
    "protocol": "chat_completions"
  }
}
```

上記は書式例であり、存在するAPI URLではありません。配備先の実際のURLとモデルIDを登録します。公開プールとモデル結合を変えた場合、学習済みルーターの品質を改めて評価する必要があります。

```bash
uv run python scripts/configure_services.py \
  --base native_envs/runtime.generated.json \
  --output config-private/runtime.json \
  --llm-endpoint '実際のChat Completionsエンドポイント' \
  --llm-model '実際の固定モデルID' \
  --models config-private/models.json \
  --routes config-private/routes.json \
  --allow-public-egress
```

ローカルLLMの場合は `--llm-local`、認証不要の管理下ローカルサービスの場合に限り `--llm-no-key` を使用します。外部送信は管理者設定と個別要求の両方で許可された公開データだけです。非公開データの送信を検証用フラグで解除しません。

## 5. AFlowの生成コードを隔離する

AFlowが生成するPythonコードはホスト上で直接実行しません。取得済みの固定ソースからOCIイメージをビルドします。

```bash
uv run python scripts/build_aflow_image.py --config config-private/runtime.json
```

`reports/aflow-image.json` のイメージIDを配備設定の `engines.aflow.image` に固定します。実行時はnetworkなし、read-only root、権限削減、CPU/メモリ/プロセス数上限を適用します。モデルAPIや評価器へのアクセスは許可されたゲートウェイ経由です。

本配布環境ではDockerが使用できず、イメージのビルド・OCI実行は未検証です。設定上の `sandbox` という文字列だけを、OS隔離の証拠にはしません。

## 6. 全体受入試験と昇格

```bash
uv run python scripts/verify_native_all.py \
  --config config-private/runtime.json \
  --output reports/deployment-native-acceptance.json \
  --ack-external-cost
```

`--ack-external-cost` は、明示された公開合成データを設定済みの外部サービスへ送り、API費用が発生し得る試験への同意です。元データの区分を書き換えるものではありません。認証キーそのものを提供するフラグでもありません。

受入判定は以下の全てを要求します。

1. 全11エンジンとJev/LLMの17機能検査が成功すること。
2. 未使用のtestを使った目標駆動の全体実行が、固定oracleを満たすこと。
3. スキル・ワークフロー等の候補を反映し、新しい要求で実際に利用すること。
4. 旧版への切り戻しを確認すること。

欠落や失敗を `skip` で除外しません。**独立評価だけが成功しても、全17機能の検証証明がなければ本番版へ昇格できません。** この配布物ではこのゲートは不合格であり、本番active版は作られていません。

## 7. 受入合格後の利用

```bash
# ターミナル1
uv run jev-all --config config-private/runtime.json serve
# ターミナル2
uv run jev-all --config config-private/runtime.json worker
```

認証付きの `POST /runs` に `datasets/request.json` と同形式の目的・入力・制約を送ります。`GET /runs/{run_id}` と `/events` で結果と観測を確認できます。`/healthz` はプロセス生存確認であって、全モデルの利用可能性を保証しません。

CLIの同期実行:

```bash
uv run jev-all --config config-private/runtime.json run datasets/request.json --output reports/result.json
```

明示的に候補版を調べる場合は `seed` が返したIDを `run --bundle` に指定します。`seed` は承認操作ではなく、通常のAPI受付にはactive版が必要です。

## 8. 品質と運用の境界

形式制約は意味上の正解保証ではありません。構造化された誤答、原文の否定・条件の見落とし、誤った計画は、独立した業務評価が必要です。Jevの確信度、GLiNERの抽出スコア、ルーターのスコアを同じ確率として合算しません。

単一ホスト/単一ワークスペースの実装です。多テナントの強い分離、HA、分散DB、任意の外部更新APIのexactly-once、バックアップや記憶媒体からの物理消去まで保証していません。実行中の失敗は保存し、結果不明の副作用を自動再試行しません。

GEPA/Trace/AFlowのテキスト・構造改善と、OpenFugu/Router-R1の重みの再学習は別工程です。この版には公開推論コードと既存チェックポイントへの接続はありますが、両ルーターの本番用再学習・再配備までの全工程を実証済みとはしていません。過去レビュー24件の全面的な是正完了も主張していません。

## ファイル構成

- `src/jev_fullstack/`: 共通契約、実行、状態、権限、全体評価、ネイティブ接続。
- `src/jev_gepa/`: 初期版の厳格なJev応答検証。独自判断モデルではありません。
- `scripts/`: 全エンジンの取得、設定、モデル固定、受入、配布・再検証。
- `tests/`: 契約・制御試験と原本OpenFuguモジュールの明示的fixture試験。
- `datasets/`: 日本語の公開合成train/validation/test/post_promotionと要求例。
- `third_party/`: 実際に取得した上流wheelと、原本照合したOpenFuguのConductorモジュール。
- `reports/`: この版の実行結果、失敗、終了コード、配布物の再検証証拠。

再ビルド:

```bash
uv run python scripts/package.py --output ../jev-all-engines.zip
uv run python scripts/package.py --source-only --output ../jev-all-engines-source.zip
```

ソース版はバイナリwheelを省いた同一ソースです。全エンジンが実行済みの軽量版や、全依存を含む閉域配布物という意味ではありません。
