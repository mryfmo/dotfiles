# 共通の実行・状態・評価基盤

## 実行経路

```mermaid
flowchart TB
  Request[目的・入力・制約] --> Contract[拘束条件を維持する出力契約]
  Contract --> LDP[LDP Agent・FxnOp 計算グラフ]
  LDP --> Decision[能力・引数・順序の選択]
  Decision --> Auth[権限・情報区分・予算・版の検証]
  Auth --> Aviary[Aviary Environment]
  Aviary --> Gateway[共通ゲートウェイ]
  Gateway --> Extract[GLiNER2]
  Gateway --> Judge[Jev]
  Gateway --> Reason[LLM]
  Gateway --> Compose[OpenFugu]
  Gateway --> Route[Router-R1]
  Gateway --> Recursive[ROMA]
  Gateway --> Grammar[XGrammar]
  Gateway --> Reuse[AutoSkillの承認済みスキル]
  Gateway --> Workflow[AFlowの承認済み構造]
  Extract & Judge & Reason & Compose & Route & Recursive & Grammar & Reuse & Workflow --> Observe[根拠・成功・不足・失敗の観測]
  Observe --> State[(暗号化状態・操作履歴・予算)]
  State --> LDP
  LDP --> Output[出力契約に沿う成果物]
  State --> Eval[独立した全体評価]
  Eval --> Improve[改善ジョブ]
  Improve --> GEPA[GEPA]
  Improve --> Trace[Trace OptoPrime]
  Improve --> AFlow[AFlow構造探索]
  Improve --> Skill[AutoSkill形成・更新]
  GEPA & Trace & AFlow & Skill --> Candidate[隔離された候補版]
  Candidate --> Holdout[固定oracle・未使用test]
  Holdout --> Promote[比較更新による昇格]
  Promote --> State
```

LLM内部の非公開思考ではなく、実行要求、引数、観測、失敗、使用量、構成版を証拠として保存する。全エンジンを毎回順番に実行する固定パイプラインではない。全11エンジンが構成契約上必須であり、個別リクエストでの選択・省略と、配備からの除外は別である。

## 責任の境界

`Supervisor`が唯一のコミット主体である。`Action`は候補であり、権限付与ではない。Aviaryへ渡した操作はスコープに結合し、別の操作への書換え・同じ操作の再送を拒否する。プランナーから別のプランナーへの無制限の再帰委譲は認めず、新しいSupervisorの判断を必要とする。

各エンジンは専用Python環境・元リポジトリのパスで動く。AFlowのトップレベル`workspace`/`scripts`と別プロジェクトの同名モジュールを同じPython環境に混載しない。モデルキーはホストに残し、子プロセスには期限付きゲートウェイトークンだけを渡す。Router-R1のモデルIDは、管理者が登録した`services.llm.routes`へ解決する。不明なモデル名を無視して全て同じモデルに送ることはしない。

## 状態と回復

SQLite WALを単一ホストで使用する。初期化のプロセス間ロック、実行リース、fencing token、状態revision、親子共通予算を実装した。結果を記録する前に停止した操作は`outcome_unknown`として残し、自動再実行しない。本システムに破壊的な業務APIは既定で登録していない。外部更新を追加する場合には、相手側の冪等性キー・結果照会・補償をその能力契約へ実装する必要がある。

一時的なツール失敗や欠損は観測としてLLMへ返す。一方、権限拒否は別経路で迂回しない。下流の情報区分は親・子・改善ジョブへ引き継ぐ。プライベートな訓練情報から作ったスキルを経由して外部送信が許されることはない。

## 評価と更新

最適化に渡すのはtrain/validationの要求と、全体実行から測った結果である。正解はホスト評価器に残す。test・post_promotionの要求取得は最適化ゲートウェイから拒否する。入力IDを変えた同一内容のsplit移動やtest再使用も拒否する。これは同一ワークスペース内の制御であり、管理者が別環境へ正解をコピーする行為を防ぐ機能ではない。

版は全エンジンの識別子、モデル結合、方策、スキル・構造のハッシュをまとめて固定する。実行途中に設定を混在させない。候補保存と本番への昇格を分離し、合格した独立評価の実行IDと全17ネイティブ機能検査の保存証明を要求する。単独の簡単な課題で正解しただけでは、未導入エンジンを残して昇格できない。コードから直接DBを変更できる信頼済み管理者まで隔離した仕組みではない。

## 実装範囲の限界

このソースには各エンジンの公開APIを呼び出す接続実装がある。一方、この配布環境で全エンジンの実重み・実APIを動かしたことを意味しない。`VERIFICATION_ja.md`と機械可読レポートを確認する。モデル重み・API認証・CUDA・OCI実行環境を代替実装で埋めていない。

高可用性、分散DB、複数組織の強いテナント隔離、全媒体・バックアップからの物理消去を実装済みとはしていない。AFlow以外の公開Pythonエンジンは信頼済みの依存として動作する。生成コードを実行するAFlowは、ネットワークなし・読み取り専用ルート・権限削減・資源制限付きのOCI実行を必須とする。
