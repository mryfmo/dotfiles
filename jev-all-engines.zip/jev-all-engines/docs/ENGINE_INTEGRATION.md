# 指定エンジンと実際の接続箇所

| 必須対象 | 本体の接続点 | この配布物の担当ファイル |
|---|---|---|
| LDP | Agent / FxnOp / compute_graph | native/ldp_aviary.py |
| Aviary | Environment / Tool / exec_tool_calls | native/ldp_aviary.py |
| OpenFugu | ConductorExecutor / FuguRouter | native/openfugu.py |
| Router-R1 | 公開infer_vllm.pyをrunpyで実行 | native/router_r1.py |
| ROMA | RecursiveSolver.async_solve | native/roma.py |
| AutoSkill | AutoSkill.ingest / search | native/autoskill.py |
| AFlow | Optimizer.optimize / GraphUtils.load_graph | native/aflow.py |
| Trace | trace.node / bundle / OptoPrime.backward・step | native/trace.py |
| XGrammar | GrammarCompiler / GrammarMatcher / token bitmask / LogitsProcessor | native/xgrammar.py |
| GEPA | optimize / GEPAAdapter / EvaluationBatch | native/gepa.py |
| GLiNER2 | AutoExtractor.from_pretrained / extract_entities | native/gliner2.py |
| Jev | 公式REST形式＋元v1の厳格な応答検証 | services.py / jev_gepa/providers.py |
| LLM | 管理者登録のChat CompletionsまたはAnthropic Messages | services.py |

`configs/engines.lock.json`はソース・主要配布版の指定であり、全依存を解決済みとする`uv.lock`ではない。インストール成功後の各環境についてbootstrapがfreezeと依存整合チェックを記録する。

## 置換していない部分

独自の回帰器をOpenFugu/Router-R1と呼ぶこと、単なる候補列挙をGEPA/AFlowと呼ぶこと、独自スキル保存処理をAutoSkillと呼ぶことはしない。本体が見つからなければ、そのエンジンの呼び出しは明示的に失敗する。

単体試験の`tests/conftest.py`にはSupervisorの契約検査専用の固定応答fixtureがある。これは製品の実行経路に登録されず、ネイティブ受入試験にも使われない。`tests/test_original_openfugu.py`だけは、原本照合したConductorモジュールを別プロセスで動かし、モデル側の応答を明示的なfixtureにしている。DAG実行の確認と、学習済みルーター・LLMの品質確認を混同しない。

## 同梱できた原本

`third_party/wheels/manifest.json`に実際の配布物とSHA-256を記録する。Aviary・LDP・XGrammar等の公開wheelと必要な一部依存を同梱したが、全エンジン・全依存・全OSを網羅したオフラインリポジトリではない。Linux CPython 3.13向けのバイナリを含む。

OpenFuguは`openfugu/ultra.py`全体を原本のGit blob SHA-1 `4ec8991c20dff610de0007ce46f35dadf96cfbc8`と照合した。これはOpenFugu全リポジトリやminiルーター重みを同梱したという意味ではない。原本モジュールの試験では`compose`以外を受け付けない。通常配備のbootstrapは、OpenFuguを含む指定全リポジトリを取得する。

上流のLICENSE/NOTICEは各wheelのdist-infoおよび同梱ソースに保持される。外部モデルの重み・データセット・API契約はコードのライセンスと別である。重みや秘密値を、このZIPへ含めたとはしていない。
