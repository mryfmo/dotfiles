# 上流ソース・配布物の来歴

実際の接続先と固定ソースを示します。全ソースの取得や実行成功を示す表ではありません。

| 対象 | 上流リポジトリ | 固定revision / version |
|---|---|---|
| ldp | https://github.com/Future-House/ldp | `7220ca1e06292b856b1a3f1fe2c94170bc933055` |
| aviary | https://github.com/Future-House/aviary | `7167342915e656fba1d93af4a5f0549cb803cd76` |
| openfugu | https://github.com/trotsky1997/OpenFugu | `7ad7ccf977c1b5f38bbd07ba33d86fe655c17be8` |
| router_r1 | https://github.com/ulab-uiuc/Router-R1 | `801a240e37701577907c32de27a548af4e6c4430` |
| roma | https://github.com/sentient-agi/ROMA | `a6e3bb4f9e0694375fa627fa4b8bf8cae50592a6` |
| autoskill | https://github.com/ECNU-ICALK/AutoSkill | `94c47ca488d4ba4117d20272e66d49b9877e68cf` |
| aflow | https://github.com/FoundationAgents/AFlow | `3f457218fc716093fe53f6df8a5d5e6379d66346` |
| trace | https://github.com/microsoft/Trace | `8190d032e43ffe18943a8cad9ea9ee99e43d6773` |
| xgrammar | https://github.com/mlc-ai/xgrammar | `82505d0d987c36a4209fb3d8571cf6b0f28b5acd` |
| gepa | https://github.com/gepa-ai/gepa | `0.1.4` |
| gliner2 | https://github.com/fastino-ai/GLiNER2 | `d7c727458bf6929bc9ef5ee04e13c3f717a7c455` |

## このZIP内に保存された原本

`third_party/wheels/manifest.json`が取得した上流wheelのSHA-256とサイズです。ソース版ZIPではwheelそのものは省き、記録のみを保持します。

OpenFuguの`openfugu/ultra.py`は、公開commitにあるファイル全体をそのまま保存しました。確認したGit blob SHA-1は`4ec8991c20dff610de0007ce46f35dadf96cfbc8`です。来歴・利用条件は同階層の`PROVENANCE.json`、`LICENSE`、`NOTICE`を参照してください。OpenFuguは独立した再実装であり、Sakana AI公式配布物と混同していません。

各wheelの`dist-info/licenses`等にある原著作者の利用条件を保持しています。取得・導入されるモデルの重み、API、学習データの利用条件は別に確認する必要があります。フォントファイル、モデルの重み、APIキーは収録していません。

GEPAのAdapter契約、AFlowのOptimizerの実際のメソッド、AutoSkillのConfig/ingest/search、LDP/Aviaryの操作と観測の契約を元ソースと照合しました。照合したことと実際の全エンジン受入成功は別です。

## 構築・実行設定の留意点

ソースcommitを固定していても、間接依存の全版・OS・モデル・エンドポイントを自動的に固定するわけではありません。この配布で全依存解決済みのuv.lockを偽造していません。bootstrapの導入成功後に作るfreeze/checkの記録を、配備環境の再現性確認に使用してください。
