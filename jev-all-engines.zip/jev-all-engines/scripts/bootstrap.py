#!/usr/bin/env python3
"""Acquire all mandatory upstream engines and isolate their dependency environments.

The source lock is not a falsely claimed dependency lock. Exact uv freeze reports
are written ONLY after installation succeeds. A failed engine makes exit status 2.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor,as_completed
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def run(argv,log,cwd=None,timeout=600):
    start=time.time()
    with log.open('ab') as f:
        f.write(('\n$ '+' '.join(argv)+'\n').encode());f.flush()
        try:
            p=subprocess.run(argv,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,timeout=timeout,
                             env={**os.environ,'GIT_TERMINAL_PROMPT':'0','UV_HTTP_TIMEOUT':'30','UV_HTTP_RETRIES':'1'})
            return {'returncode':p.returncode,'seconds':time.time()-start,'argv':argv}
        except subprocess.TimeoutExpired:
            return {'returncode':124,'seconds':time.time()-start,'argv':argv,'error':'timeout'}


def bootstrap_one(name,spec,dest,offline,fetch_only):
    result={'engine':name,'status':'blocked','steps':[],'source':None}
    folder=dest/'sources'/name;log=dest/'reports'/(name+'.log')
    envpath=dest/'envs'/name
    if spec.get('revision'):
        if not (folder/'.git').exists():
            if folder.exists() and any(folder.iterdir()):
                result['reason']='refusing to overwrite a non-Git source directory';return result
            folder.mkdir(parents=True,exist_ok=True)
            result['steps'].append(run(['git','init',str(folder)],log))
            result['steps'].append(run(['git','remote','add','origin','https://github.com/'+spec['repo']+'.git'],log,folder))
        if not offline:
            result['steps'].append(run(['git','fetch','--depth','1','origin',spec['revision']],log,folder,120))
            if result['steps'][-1]['returncode']:
                result['reason']='source fetch failed';return result
            result['steps'].append(run(['git','checkout','--detach','FETCH_HEAD'],log,folder))
        p=subprocess.run(['git','rev-parse','HEAD'],cwd=folder,capture_output=True,text=True)
        if p.returncode or p.stdout.strip()!=spec['revision']:
            result['reason']='pinned source absent or mismatched';return result
        if subprocess.run(['git','diff','--exit-code'],cwd=folder,stdout=subprocess.DEVNULL).returncode:
            result['reason']='unrecorded upstream source modification';return result
        result['source']={'repo':spec['repo'],'revision':p.stdout.strip()}
    else:
        folder.mkdir(parents=True,exist_ok=True)
    if fetch_only:
        result['status']='source_acquired' if spec.get('revision') else 'package_required'
        return result
    result['steps'].append(run(['uv','venv','--python',spec['python'],str(envpath)],log))
    if result['steps'][-1]['returncode']:
        result['reason']='Python environment creation failed';return result
    py=envpath/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    args=['uv','pip','install','--python',str(py)]
    if offline:args+=['--no-index','--find-links',str(ROOT/'third_party/wheels')]
    # Native worker protocol is standard-library only. No fake package is installed
    # to satisfy an unresolved transitive dependency.
    if spec.get('requirements_file'):
        args+=['-r',str(folder/spec['requirements_file'])]
    args += [v.replace('@source',str(folder)) for v in spec.get('install',[])]
    result['steps'].append(run(args,log,folder))
    if result['steps'][-1]['returncode']:
        result['reason']='dependency installation failed';return result
    checked=run(['uv','pip','check','--python',str(py)],log)
    result['steps'].append(checked)
    if checked['returncode']:
        result['reason']='dependency consistency check failed';return result
    frozen=subprocess.run(['uv','pip','freeze','--python',str(py)],capture_output=True,text=True,check=True)
    (dest/'reports'/(name+'.freeze.txt')).write_text(frozen.stdout,encoding='utf-8')
    result.update(status='installed',python=str(py),source_path=str(folder),
        freeze_sha256=hashlib.sha256(frozen.stdout.encode()).hexdigest())
    return result


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--directory',type=Path,default=ROOT/'native_envs')
    ap.add_argument('--offline',action='store_true');ap.add_argument('--fetch-only',action='store_true')
    ap.add_argument('--workers',type=int,default=3)
    args=ap.parse_args();dest=args.directory.resolve()
    for part in ('sources','envs','reports'): (dest/part).mkdir(parents=True,exist_ok=True)
    lock=json.loads((ROOT/'configs/engines.lock.json').read_text())
    expected={'ldp','aviary','openfugu','router_r1','roma','autoskill','aflow','trace','xgrammar','gepa','gliner2'}
    if set(lock['engines'])!=expected:raise ValueError('mandatory source scope was changed')
    results=[]
    with ThreadPoolExecutor(max_workers=max(1,min(4,args.workers))) as pool:
        futures={pool.submit(bootstrap_one,n,s,dest,args.offline,args.fetch_only):n for n,s in lock['engines'].items()}
        for future in as_completed(futures):
            name=futures[future]
            try:r=future.result()
            except Exception as e:r={'engine':name,'status':'blocked','reason':type(e).__name__+': '+str(e)}
            results.append(r);print(name,r['status'],flush=True)
            (dest/'reports/bootstrap.json').write_text(json.dumps({'results':results},ensure_ascii=False,indent=2),encoding='utf-8')
    engineconfig={}
    for name,spec in lock['engines'].items():
        folder=dest/'sources'/name
        engineconfig[name]={**{k:spec[k] for k in ('revision','distribution','version','source_paths') if k in spec},
            'python':str(dest/'envs'/name/('Scripts/python.exe' if os.name=='nt' else 'bin/python')),
            'source':str(folder),'execution':'container' if spec.get('requires_os_sandbox') else 'process',
            'image':'jev-aflow:locked' if name=='aflow' else None,'cuda_devices':'0' if spec.get('requires_cuda') else ''}
    config={'project_root':str(ROOT),'workspace':str(ROOT/'workspace'),'engines':engineconfig,
        'authority':{'allow_external':False,'allow_effects':False,'max_actions':500,'max_units':100000,'max_depth':3},
        'services':{'llm':{'endpoint':'','model':'','api_key_env':'JU_LLM_API_KEY','external':True,'protocol':'chat_completions'},
                    'jev':{'endpoint':'https://api.typesafe.ai/v1/systemone','model':'jev-1.13.0','api_key_env':'JU_JEV_API_KEY','external':True}},
        'models':{},'datasets':{split:str(ROOT/'datasets'/f'{split}.json') for split in ('train','validation','test','post_promotion')}}
    (dest/'runtime.generated.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
    success=all(r['status'] in ({'source_acquired','package_required'} if args.fetch_only else {'installed'}) for r in results)
    return 0 if success else 2

if __name__=='__main__':sys.exit(main())
