#!/usr/bin/env python3
"""Build a native AFlow image from the pinned original checkout and record its ID."""
import argparse,json,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from jev_fullstack.container_rpc import NativeRunner
from jev_fullstack.settings import load_settings

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',default=str(ROOT/'configs/runtime.json'))
    args=ap.parse_args();cfg=load_settings(args.config)
    runner=NativeRunner(ROOT,cfg);source,identity=runner._identity('aflow',cfg['engines']['aflow'])
    default=ROOT/'native_envs/sources/aflow'
    if source!=default:raise ValueError('use the default source location for this reproducible Docker build context')
    subprocess.run(['docker','build','-f',str(ROOT/'deploy/Dockerfile.aflow'),'-t','jev-aflow:locked',str(ROOT)],check=True)
    image=subprocess.check_output(['docker','image','inspect','--format','{{.Id}}','jev-aflow:locked'],text=True).strip()
    output={'engine':'aflow','image':image,'upstream':identity,'execution_network':'none'}
    (ROOT/'reports').mkdir(exist_ok=True);(ROOT/'reports/aflow-image.json').write_text(json.dumps(output,indent=2))
    print(json.dumps(output,indent=2))
    return 0
if __name__=='__main__':raise SystemExit(main())
