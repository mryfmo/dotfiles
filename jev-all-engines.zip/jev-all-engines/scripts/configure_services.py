#!/usr/bin/env python3
"""Create an explicit deployment binding; never write credentials into config."""
import argparse,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from jev_fullstack.settings import load_settings

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--base',default=str(ROOT/'configs/runtime.json'))
    ap.add_argument('--output',type=Path,required=True);ap.add_argument('--llm-endpoint',required=True)
    ap.add_argument('--llm-model',required=True);ap.add_argument('--llm-local',action='store_true')
    ap.add_argument('--llm-no-key',action='store_true');ap.add_argument('--allow-public-egress',action='store_true')
    ap.add_argument('--models',type=Path);ap.add_argument('--routes',type=Path)
    args=ap.parse_args()
    if args.output.exists():raise FileExistsError('refusing to overwrite deployment configuration')
    cfg=load_settings(args.base)
    cfg['services']['llm'].update(endpoint=args.llm_endpoint,model=args.llm_model,
        external=not args.llm_local,requires_key=not args.llm_no_key)
    cfg['authority']['allow_external']=args.allow_public_egress
    if args.models:cfg['models'].update(json.loads(args.models.read_text(encoding='utf-8')))
    if args.routes:cfg['services']['llm']['routes']=json.loads(args.routes.read_text(encoding='utf-8'))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    try:load_settings(args.output)
    except Exception:
        args.output.unlink();raise
    print(args.output)
if __name__=='__main__':main()
