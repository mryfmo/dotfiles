#!/usr/bin/env python3
"""Create a portable config without inventing credentials or model checkpoints."""
import json
from pathlib import Path
ROOT=Path(__file__).absolute().parents[1]
lock=json.loads((ROOT/'configs/engines.lock.json').read_text())
engines={}
for n,spec in lock['engines'].items():
    engines[n]={k:spec[k] for k in ('repo','revision','distribution','version','source_paths') if k in spec}
    engines[n].update(python=f'native_envs/envs/{n}/bin/python',source=f'native_envs/sources/{n}',
                      execution='container' if n=='aflow' else 'process',image='jev-aflow:locked' if n=='aflow' else None,
                      device='cuda:0' if n=='router_r1' else 'cpu')
cfg={'project_root':'..','workspace':'workspace','engines':engines,
     'authority':{'allow_external':False,'allow_effects':False,'max_actions':500,'max_units':100000,'max_depth':3},
     'services':{'llm':{'endpoint':'','model':'','api_key_env':'JU_LLM_API_KEY','external':True,'protocol':'chat_completions'},
                 'jev':{'endpoint':'https://api.typesafe.ai/v1/systemone','model':'jev-1.13.0','api_key_env':'JU_JEV_API_KEY','external':True}},
     'models':{},'datasets':{s:f'datasets/{s}.json' for s in ('train','validation','test','post_promotion')}}
out=ROOT/'configs/runtime.json'
if out.exists():raise FileExistsError('configuration already exists; refusing to overwrite')
out.write_text(json.dumps(cfg,ensure_ascii=False,indent=2),encoding='utf-8')
print(out)
