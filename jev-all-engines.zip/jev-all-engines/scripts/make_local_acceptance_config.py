#!/usr/bin/env python3
"""Record the actual local test interpreter and the original wheel identities.

This configuration does not claim that missing sources/models are installed.
The portable deployment config remains configs/runtime.json.
"""
import json,sys
from pathlib import Path
ROOT=Path(__file__).absolute().parents[1]
cfg=json.loads((ROOT/'configs/runtime.json').read_text());cfg['project_root']=str(ROOT);cfg['workspace']=str(ROOT/'local-native-workspace')
manifest=json.loads((ROOT/'third_party/wheels/manifest.json').read_text())
for name in cfg['engines']:
 cfg['engines'][name]['python']=str(ROOT/'.native-test-env/bin/python')
 cfg['engines'][name]['source']=str(ROOT/'native_envs/sources'/name)
 if name in ('ldp','aviary','xgrammar'):
  prefix={'ldp':'ldp-','aviary':'fhaviary-','xgrammar':'xgrammar-'}[name]
  wh=next(x for x in manifest if x['file'].startswith(prefix))
  cfg['engines'][name].update(wheel='third_party/wheels/'+wh['file'],wheel_sha256=wh['sha256'],source_paths=[])
cfg['engines']['openfugu'].update(source=str(ROOT/'third_party/source_modules/openfugu'),
 source_paths=['.'],source_snapshot={'revision':'7ad7ccf977c1b5f38bbd07ba33d86fe655c17be8',
 'files':{'openfugu/ultra.py':'4ec8991c20dff610de0007ce46f35dadf96cfbc8'},'operations':['compose']})
(ROOT/'configs/local.acceptance.json').write_text(json.dumps(cfg,ensure_ascii=False,indent=2))
