#!/usr/bin/env python3
"""Build a manifest-backed source delivery. Never include workspaces or credentials.

The full edition additionally includes original, hash-recorded wheel artifacts;
it is NOT a complete offline dependency repository.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import stat
import zipfile

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE_ROOT = 'jev-all-engines'
ROOT_FILES = { 'pyproject.toml', 'README_ja.md', '.env.example', '.gitignore', '.dockerignore' }
DIRECTORIES = {'src', 'scripts', 'configs', 'datasets', 'tests', 'docs', 'deploy', 'third_party'}
REPORTS = {
    'unit-tests.xml', 'unit-tests.log', 'unit-test-exit.json', 'coverage.json',
    'native-acceptance.json', 'native-acceptance.log', 'native-gate-exit.json',
    'source-acquisition.json', 'source-acquisition.log', 'missing-native-dependencies.log',
    'offline-wheel-install.log', 'native-venv.log', 'native-imports-stage2.log',
    'archive-roundtrip.json', 'archive-roundtrip.log', 'archive-roundtrip.xml',
    'wheel-build.log', 'wheel-install.log', 'installed-cli.log',
    'verification-summary.json', 'environment.json',
}
EXCLUDED_PARTS = {'__pycache__', '.pytest_cache', '.git', '.venv', 'node_modules'}
PROHIBITED_SUFFIXES = {'.pyc', '.pyo', '.db', '.sqlite', '.sqlite3', '.key', '.pem', '.ttf', '.otf', '.woff', '.woff2'}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def collect(root: Path, source_only: bool = False) -> dict[str, bytes]:
    root = root.absolute()
    files: dict[str, bytes] = {}
    for path in sorted(root.rglob('*')):
        relative = path.relative_to(root)
        if any(part in EXCLUDED_PARTS for part in relative.parts):
            continue
        allowed = (len(relative.parts) == 1 and relative.name in ROOT_FILES)
        allowed |= relative.parts[0] in DIRECTORIES
        allowed |= len(relative.parts) == 2 and relative.parts[0] == 'reports' and relative.name in REPORTS
        allowed |= len(relative.parts) == 2 and relative.parts[0] == 'dist' and relative.suffix == '.whl'
        if not allowed:
            continue
        if path.is_symlink():
            raise ValueError(f'symlink cannot be packaged: {relative}')
        if not path.is_file():
            continue
        if relative.name == '.env' or path.suffix.lower() in PROHIBITED_SUFFIXES:
            raise ValueError(f'private or prohibited file: {relative}')
        if relative.as_posix() == 'configs/local.acceptance.json':
            continue
        if source_only and path.suffix == '.whl':
            continue
        files[relative.as_posix()] = path.read_bytes()
    mandatory = {'README_ja.md', 'pyproject.toml', 'configs/engines.lock.json', 'src/jev_fullstack/runtime.py',
                 'scripts/verify_native_all.py', 'scripts/verify_package.py', 'reports/native-acceptance.json'}
    absent = mandatory - files.keys()
    if absent:
        raise ValueError(f'delivery files missing: {sorted(absent)}')
    return files


def build(root: Path, destination: Path, source_only: bool = False) -> dict:
    files = collect(root, source_only)
    entries = {name: {'sha256': sha256(content), 'bytes': len(content)} for name, content in files.items()}
    code_entries = {name: entry for name, entry in entries.items()
                    if name.split('/')[0] in {'src', 'scripts', 'tests', 'configs', 'datasets'} or name == 'pyproject.toml'}
    code_digest = sha256(json.dumps(code_entries, sort_keys=True, separators=(',', ':')).encode())
    manifest = {
        'format': 1, 'archive_root': ARCHIVE_ROOT,
        'edition': 'source' if source_only else 'source-with-acquired-upstream-wheels',
        'acceptance_status': 'see reports/native-acceptance.json; packaging does not assert acceptance',
        'source_tree_sha256': code_digest,
        'manifest_self_excluded': True,
        'files': entries,
    }
    files['MANIFEST.json'] = (json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode()
    destination = destination.absolute()
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_name(destination.name + '.tmp')
    with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, content in sorted(files.items()):
            info = zipfile.ZipInfo(f'{ARCHIVE_ROOT}/{name}', date_time=(2026, 9, 21, 0, 0, 0))
            info.create_system = 3
            mode = 0o755 if name.startswith('scripts/') and name.endswith('.py') else 0o644
            info.external_attr = (stat.S_IFREG | mode) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, content)
    with zipfile.ZipFile(temporary) as archive:
        if archive.testzip() is not None:
            raise ValueError('ZIP CRC verification failed')
    temporary.replace(destination)
    return {'path': str(destination), 'bytes': destination.stat().st_size,
            'sha256': sha256(destination.read_bytes()), 'entries': len(files),
            'source_tree_sha256': code_digest, 'edition': manifest['edition']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--source-only', action='store_true')
    args = parser.parse_args()
    print(json.dumps(build(args.root, args.output, args.source_only), ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
