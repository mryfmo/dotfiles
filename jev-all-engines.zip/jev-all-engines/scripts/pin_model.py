#!/usr/bin/env python3
"""Hash every file in an operator-acquired local checkpoint without downloading it.

This is provenance creation, not model evaluation or automatic trust approval.
"""
import argparse,hashlib,json,os
from pathlib import Path

def pin(path):
    path=Path(path).absolute()
    if not path.is_dir() or path.is_symlink():raise ValueError('regular checkpoint directory required')
    hashes={}
    for f in sorted(path.rglob('*')):
        if f.is_symlink():raise ValueError('checkpoint symlinks are not accepted; use an exported copy')
        if f.is_file():
            h=hashlib.sha256()
            with f.open('rb') as stream:
                for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
            hashes[f.relative_to(path).as_posix()]=h.hexdigest()
    if not hashes:raise ValueError('empty model directory')
    return {'path':str(path),'files':hashes}

def main():
    a=argparse.ArgumentParser();a.add_argument('checkpoint',type=Path);a.add_argument('--name',required=True)
    a.add_argument('--revision',required=True);a.add_argument('--output',type=Path,required=True)
    args=a.parse_args();data={args.name:{**pin(args.checkpoint),'revision':args.revision}}
    if args.output.exists():raise FileExistsError('refusing to overwrite a model pin')
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(data,indent=2)+'\n')
    print(args.output)
if __name__=='__main__':main()
