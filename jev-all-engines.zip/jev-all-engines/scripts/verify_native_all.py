#!/usr/bin/env python3
"""Native-engine + model integration gate. Missing engines are failures, never skips.

All mandatory engines remain in this gate. It runs each engine through the shared
supervisor/gateway and then performs goal-driven independent system evaluation.
Synthetic inputs do not replace upstream packages, model weights or model services.
"""
import argparse,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from jev_fullstack.contracts import REQUIRED_ENGINES,GoalRequest,Action,Bundle,canonical
from jev_fullstack.runtime import Supervisor
from jev_fullstack.settings import load_settings
from jev_fullstack.evaluation import EvaluationManager


from jev_fullstack.acceptance import functional_checks

def execute_case(s,bundle,label,capability,args,phase='execute'):
    request=GoalRequest.model_validate({'goal':'合成データで指定した実エンジンの処理を検証する。成功を自己申告しない。',
        'inputs':[{'id':'synthetic','content':{'case':label,'payload':args},'classification':'public'}],
        'requirements':['実装元と実行結果を記録する'],
        'constraints':{'max_actions':500,'max_units':100000,'deadline_seconds':300,
            'allow_external':s.settings['authority'].get('allow_external',False)}})
    rid=s.submit(request,bundle);owner='acceptance';fence=s.store.claim(rid,owner,lease_seconds=600)
    scope=s._scope(rid,owner,fence,phase=phase)
    try:
        if capability=='ldp.decide':
            r=s.native('ldp','decide',args,scope);passed=r.status=='ok' and r.value.get('decision',{}).get('kind') in ('act','finish','unresolved')
            evidence=r.model_dump(mode='json')
        else:
            r=s.invoke(Action(capability=capability,arguments=args,input_refs=('synthetic',)),scope)
            passed=r.status=='ok';evidence=r.model_dump(mode='json')
        if passed:
            checks=functional_checks(label,evidence)
            passed=all(checks.values())
        else:checks={'engine_call_succeeded':False}
        error=None if passed else {'type':'FunctionalCheckFailed','detail':str(checks)}
    except Exception as exc:
        passed=False;evidence={};checks={'engine_call_succeeded':False};error={'type':type(exc).__name__,'detail':str(exc)[:1500]}
    row=s.store.get(rid);state=row['state'];state['output']=evidence;state['error']=error
    s.store.save(rid,owner,fence,row['revision'],state,'succeeded' if passed else 'failed')
    return {'case':label,'capability':capability,'passed':passed,'run_id':rid,'response':evidence,
            'error':error,'checks':checks,'operations':s.store.operations(rid),'events':s.store.events(rid)}


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',required=True);ap.add_argument('--output',type=Path,default=ROOT/'reports/native-acceptance.json')
    ap.add_argument('--ack-external-cost',action='store_true');args=ap.parse_args()
    cfg=load_settings(args.config);s=Supervisor(cfg);results=[];acceptance=None
    try:
        if cfg.get('authority',{}).get('allow_external') and not args.ack_external_cost:
            raise PermissionError('explicit acknowledgment required before paid external calls with synthetic data')
        if args.ack_external_cost and cfg.get('authority',{}).get('allow_external'):
            public_data={}
            for name,source in s.settings.get('datasets',{}).items():
                dataset=json.loads(Path(source).read_text(encoding='utf-8')) if isinstance(source,str) else json.loads(json.dumps(source))
                if dataset.get('synthetic') is not True:
                    raise PermissionError('the native acceptance command accepts only explicitly synthetic datasets for this consent flag')
                for example in dataset['examples']:
                    if any(d.get('classification','public')!='public' for d in example['request'].get('inputs',[])):
                        raise PermissionError('nonpublic test input cannot be made public by the test harness')
                    example['request'].setdefault('constraints',{})['allow_external']=True
                public_data[name]=dataset
            s.settings['datasets']=public_data
        e=EvaluationManager.from_config(s);base=s.store.bundle() if s.store.active() else s.seed();working=base
        cases=[
            ('ldp','ldp.decide',{'messages':[{'role':'system','content':'Return a JSON Decision with kind finish, output {"ok":true}, evidence [], and no action.'},{'role':'user','content':'構造化された確認結果を返してください。'}],'tools':[]},'execute'),
            ('aviary','aviary.execute',{'action':{'capability':'xgrammar.validate','arguments':{'text':'{"ok":true}','schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}}}},'execute'),
            ('xgrammar-validation','xgrammar.validate',{'text':'{"ok":true}','schema':{'type':'object','properties':{'ok':{'type':'boolean'}},'required':['ok'],'additionalProperties':False}},'execute'),
            ('xgrammar-generation','xgrammar.generate',{'prompt':'Return JSON with the sum of 17 and 23 in the sum field.','schema':{'type':'object','properties':{'sum':{'type':'integer'}},'required':['sum'],'additionalProperties':False},'max_new_tokens':128},'execute'),
            ('gliner2','gliner2.extract',{'text':'Alice works at Acme in London.','labels':['person','organization','location']},'execute'),
            ('jev','jev.judge',{'state':'解約は希望していません。料金だけ確認したいです。','questions':{'cancel':{'type':'choice','instructions':'解約の意思を明示しているか。料金確認のみや否定はno。','criteria':{'yes':'明示的に解約を希望','no':'解約を希望していない'}}}},'execute'),
            ('llm','llm.reason',{'prompt':'17+23の結果をJSON {"sum":整数}として返してください。'},'execute'),
            ('openfugu-compose','openfugu.compose',{'goal':'Alice works at Acme in London. Extract names then explain the evidence.','slots':[{'capability':'gliner2.extract','description':'Extract typed entities and source spans'},{'capability':'llm.reason','description':'Explain and combine evidence'}]},'execute'),
            ('openfugu-router','openfugu.route',{'messages':[{'role':'user','content':'Compare the two proposed calculations, then verify the total.'}],'mask':[True]*7},'execute'),
            ('router_r1','router_r1.solve',{'goal':'A has 17 items, B has 23 items. Establish the total and verify it.'},'execute'),
            ('roma','roma.solve',{'goal':'17と23の合計を求め、別の計算順序でも検算し、JSONで合計を返してください。'},'execute'),
            ('autoskill-ingest','autoskill.ingest',{'messages':[{'role':'user','content':'今後も集計では必ず元データの単位を保持し、欠損をゼロと混同せず、原文IDを出典として返してください。'},{'role':'assistant','content':'この継続的な業務条件を適用します。'}]},'improve'),
            ('trace','trace.optimize',{'candidate':dict(base.prompts),'dataset_id':'train'},'improve'),
            ('gepa','gepa.optimize',{'candidate':dict(base.prompts),'train_id':'train','validation_id':'validation','max_metric_calls':8},'improve'),
            ('aflow-optimize','aflow.optimize',{'dataset_id':'validation','rounds':1},'improve'),
        ]
        for name,cid,payload,phase in cases:
            if name in ('trace','gepa'):payload['candidate']=dict(working.prompts)
            r=execute_case(s,working,name,cid,payload,phase);results.append(r)
            value=r.get('response',{}).get('value',{})
            candidate=value.get('best_candidate',value.get('candidate')) if isinstance(value,dict) else None
            if r['passed'] and isinstance(candidate,dict):
                working=e._candidate(working,candidate)
            artifact=value.get('candidate_artifact') if isinstance(value,dict) else None
            if artifact:
                alias=artifact['kind']+'-'+artifact['id'][:16]
                working=working.model_copy(update={'parent':working.sha256,'version':'native-probe-'+name,'artifacts':{**working.artifacts,alias:artifact['id']}})
                s.store.add_bundle(working)
                if artifact['kind']=='skills':
                    results.append(execute_case(s,working,'autoskill-search','autoskill.search',{'query':'集計の欠損と単位をどう扱うか','skill_snapshot':alias}))
                elif artifact['kind']=='workflow':
                    results.append(execute_case(s,working,'aflow-execute','aflow.execute',{'goal':'17+23の合計をJSONで返す','workflow_snapshot':alias}))
            print(name, 'passed' if r['passed'] else 'FAILED',flush=True)
            args.output.parent.mkdir(parents=True,exist_ok=True)
            args.output.write_text(json.dumps({'status':'running','results':results},ensure_ascii=False,indent=2),encoding='utf-8')
        # Do not hide absent dependent cases simply because generation failed.
        present={r['case'] for r in results}
        for name in ('autoskill-search','aflow-execute'):
            if name not in present:results.append({'case':name,'passed':False,'error':{'type':'PrerequisiteFailed','detail':'the native candidate artifact was not produced'}})
        acceptance=e.verify(working,'test',baseline=base)
        all_pass=all(r['passed'] for r in results) and acceptance['passed']
        replay=[];rollback=None
        if all_pass:
            s.store.attest_native(working.sha256,results)
            # Accepting a candidate is not evidence that it is actually used.
            old=s.store.active()
            if old is None:
                baseline_runs=acceptance.get('baseline') or []
                baseline_ok=bool(baseline_runs) and all(r['status']=='succeeded' and r['score']==1 for r in baseline_runs)
                if not baseline_ok:raise RuntimeError('no accepted rollback version; paired baseline did not pass')
                evidence={'split':'test','passed':True,'run_ids':[r['run_id'] for r in baseline_runs],
                    'candidate':baseline_runs,'dataset_sha256':acceptance['dataset_sha256'],
                    'oracle':'exact-json-v1','accuracy':1.0,'scope':'baseline half of the same independently scored paired comparison'}
                eid=s.store.record_evaluation(base.sha256,None,evidence);s.store.attest(base.sha256,eid)
                s.store.attest_native(base.sha256,results)
                s.promote(base.sha256,None);old=base.sha256
            s.promote(working.sha256,old)
            for ex in e.datasets.get('post_promotion',{}).get('examples',[]):
                req=GoalRequest.model_validate(ex['request'])
                s.store.register_eval_input(req,working.sha256,'post_promotion')
                rr=s.run(s.submit(req))
                replay.append({'run_id':rr['run_id'],'bundle_id':rr['state']['bundle_sha256'],
                    'passed':rr['status']=='succeeded' and e._score(ex,rr['state'].get('output'))==1})
            all_pass=all_pass and bool(replay) and all(x['passed'] for x in replay)
            if old:
                s.promote(old,working.sha256);rollback={'active':s.store.active(),'expected':old,'passed':s.store.active()==old}
                all_pass=all_pass and rollback['passed']
        else:replay=[{'passed':False,'reason':'native functional or independent acceptance prerequisite failed'}]
        report={'status':'passed' if all_pass else 'failed','all_required_engines':sorted(REQUIRED_ENGINES),
            'required_services':['jev','llm'],'results':results,'system_acceptance':acceptance,
            'post_promotion':replay,'rollback':rollback,
            'scope':'native functional integration on synthetic data; not exhaustive production/generalization assurance'}
        args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        return 0 if all_pass else 2
    except Exception as exc:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps({'status':'failed','all_required_engines':sorted(REQUIRED_ENGINES),
            'results':results,'system_acceptance':acceptance,'error':{'type':type(exc).__name__,'detail':str(exc)[:1500]}},ensure_ascii=False,indent=2),encoding='utf-8')
        return 2
    finally:s.close()
if __name__=='__main__':sys.exit(main())
