#!/usr/bin/env python3
"""Verify archive CRC, exact member set, lengths, SHA-256 and source-tree digest.

No archive content executes during verification. --extract requires a new target
and rejects absolute paths, traversal, symlinks, duplicate entries and oversized
archives. Hashes are integrity checks, not an independent publisher signature.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import stat
import zipfile

MAX_UNCOMPRESSED = 512 * 1024 * 1024
MAX_MEMBERS = 10000


def verify(archive_path: Path, extract_to: Path | None = None) -> dict:
    with zipfile.ZipFile(archive_path) as archive:
        entries = archive.infolist()
        if not entries or len(entries) > MAX_MEMBERS:
            raise ValueError('invalid archive member count')
        names = [item.filename for item in entries]
        if len(set(names)) != len(names):
            raise ValueError('duplicate archive member')
        if sum(item.file_size for item in entries) > MAX_UNCOMPRESSED:
            raise ValueError('archive exceeds extraction size budget')
        for item in entries:
            path = PurePosixPath(item.filename)
            mode = item.external_attr >> 16
            if (path.is_absolute() or '..' in path.parts or '\\' in item.filename or ':' in item.filename
                    or path.parts[0] != 'jev-all-engines' or stat.S_ISLNK(mode) or item.is_dir()):
                raise ValueError('unsafe archive path or member type')
        manifest_path = 'jev-all-engines/MANIFEST.json'
        manifest = json.loads(archive.read(manifest_path))
        if manifest.get('format') != 1 or manifest.get('archive_root') != 'jev-all-engines':
            raise ValueError('unsupported manifest')
        expected = {'jev-all-engines/' + name for name in manifest['files']} | {manifest_path}
        if set(names) != expected:
            raise ValueError('archive/manifest member set mismatch')
        for name, metadata in manifest['files'].items():
            raw = archive.read('jev-all-engines/' + name)
            if len(raw) != metadata['bytes'] or hashlib.sha256(raw).hexdigest() != metadata['sha256']:
                raise ValueError('content checksum mismatch: ' + name)
        source_entries = {name: entry for name, entry in manifest['files'].items()
                          if name.split('/')[0] in {'src', 'scripts', 'tests', 'configs', 'datasets'} or name == 'pyproject.toml'}
        tree_hash = hashlib.sha256(json.dumps(source_entries, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        if tree_hash != manifest['source_tree_sha256']:
            raise ValueError('source tree digest mismatch')
        if archive.testzip() is not None:
            raise ValueError('ZIP CRC failure')
        if extract_to is not None:
            extract_to = extract_to.absolute()
            if extract_to.exists():
                raise FileExistsError('extract into a new directory; existing files are never overwritten')
            extract_to.mkdir(parents=True)
            try:
                for item in entries:
                    target = extract_to.joinpath(*PurePosixPath(item.filename).parts)
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with archive.open(item) as src, target.open('xb') as dst:
                        shutil.copyfileobj(src, dst)
                    target.chmod(0o644)
            except Exception:
                shutil.rmtree(extract_to)
                raise
    return {'verified': True, 'path': str(Path(archive_path).absolute()),
            'bytes': Path(archive_path).stat().st_size,
            'sha256': hashlib.sha256(Path(archive_path).read_bytes()).hexdigest(),
            'entries': len(names), 'source_tree_sha256': tree_hash,
            'extracted_to': str(extract_to) if extract_to else None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('--extract', type=Path)
    args = parser.parse_args()
    print(json.dumps(verify(args.archive, args.extract), indent=2))

if __name__ == '__main__':
    main()
