#!/usr/bin/env python3
"""Render an evidence-based report; never turn packaging success into acceptance."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
s=json.loads((ROOT/'reports/verification-summary.json').read_text())
r=json.loads((ROOT/'reports/native-acceptance.json').read_text())
u=s['unit_tests'];n=s['native_gate']
roundtrip_path=ROOT/'reports/archive-roundtrip.json'
roundtrip=json.loads(roundtrip_path.read_text()) if roundtrip_path.exists() else None
reasons={
 'ldp':'公開LDPは導入されたが、litellm依存が未取得。',
 'aviary':'実Aviary Environmentから共通ゲートウェイ経由で実XGrammarを呼び、結果を観測として返した。',
 'xgrammar-validation':'実コンパイラー・matcher・CPU token maskでJSON構造を検査した。LLM生成ではない。',
 'xgrammar-generation':'transformersの間接依存と、固定したローカルLLMチェックポイントが未充足。',
 'gliner2':'上流ソース・環境・実重みが未取得/未設定。',
 'jev':'送信許可・認証が設定されていないため実APIを呼んでいない。',
 'llm':'エンドポイント・固定モデル・認証・送信許可が未設定。',
 'openfugu-compose':'原本Conductorは用意できたが、厳格受入では実LLMが未設定。モデルfixtureによる別試験と区別する。',
 'openfugu-router':'miniルーターの元ソース、backbone、学習済み係数が未取得/未設定。',
 'router_r1':'上流ソース・対応vLLM/CUDA・学習済み重みが未充足。',
 'roma':'上流ソース・DSPy依存・実LLM設定が未充足。',
 'autoskill-ingest':'上流ソース・実LLM設定が未充足。',
 'autoskill-search':'ネイティブのスキル候補生成が成功していないため、前提未達。',
 'trace':'上流ソース・依存・実反省LLMが未充足。',
 'gepa':'公式GEPAパッケージが未取得。独自探索で置換していない。',
 'aflow-optimize':'OS隔離の実行環境と上流ソース・依存が未充足。ホスト上へ迂回させていない。',
 'aflow-execute':'ネイティブ構造探索で候補を生成できていないため、前提未達。',
}
lines=['# 実行・配布検証報告', '', '作業日: 2026-09-21（JST） / パッケージ: jev-all-engines 3.0.0', '',
'## 結論', '',
'**共通基盤のテストは成功していますが、全指定エンジン・実モデルを通した受入判定は不合格です。** ZIPの作成・CRC・ハッシュ照合は、システムの受入合格の代わりではありません。完成条件を軽量化したり、未導入エンジンを対象から除外したりしていません。','',
'## 実際の試験結果','',
'| 試験 | 結果 | 根拠 |','|---|---|---|',
f'| 新実装の契約・制御・配布試験 | {u["passed"]}成功、{u["failures"]}失敗、{u["errors"]}エラー、{u["skipped"]}スキップ | reports/unit-tests.xml・unit-tests.log |',
f'| 全ネイティブ機能受入 | {n["passed"]}/{n["total"]}成功、終了コード{n["returncode"]} | reports/native-acceptance.json・native-gate-exit.json |',
'| 目的から成果物までの独立test | 不合格 | reports/native-acceptance.json: system_acceptance |',
'| 合格候補の昇格・再使用・切り戻し | ネイティブ受入の前提未達により未完了 | 同post_promotion・rollback |',
'| アプリwheelの生成・実インストール・ソース外CLI起動 | 成功 | reports/wheel-build.log・wheel-install.log・installed-cli.log |',
(f'| ZIP展開後の再テスト | {roundtrip["tests"]["passed"]}成功、ソースツリーハッシュ一致 | reports/archive-roundtrip.json・log・xml |' if roundtrip else '| ZIP展開後の再テスト | この報告生成時点では未記録 | 配布前に別ディレクトリで再実行する |'),
'',f'文カバレッジは全`jev_fullstack`を分母として **{s["coverage"]["percent_covered"]:.2f}%**（{s["coverage"]["covered_lines"]}/{s["coverage"]["num_statements"]}行）です。ネイティブ子プロセス内の行はこの測定に合算していません。高カバレッジ、全コード実行、全不具合解消を主張する結果ではありません。','',
'## ネイティブ機能別の実行結果','',
'| 検査 | 判定 | 確認できた範囲／未達理由 |','|---|---|---|']
for row in r['results']:
 lines.append(f'| {row["case"]} | {"成功" if row["passed"] else "不合格"} | {reasons.get(row["case"],"詳細はJSONのerror・response・eventsを参照")} |')
lines += ['', '## テストの意味を混同しないための区分','',
'`tests/conftest.py`のContractProviderFixture/ContractRunnerFixtureは、要求保存・権限・予算・再計画・候補反映を検査する固定応答です。ネイティブエンジンの代用品として製品実行に登録していません。状態遷移の試験には、テスト専用の検証証明fixtureを使います。その値を今回のネイティブ受入合格の証拠に使っていません。','',
'`tests/test_original_openfugu.py`は原本のConductorモジュールを別プロセスで実行します。元モジュール全体をGit blob SHA-1と照合し、DAG順序・引き継ぎ・不正経路拒否・呼び出し回数を確認します。ただし、Conductorとworkerへのモデル応答は明示的なfixtureです。OpenFuguの学習済みルーター、実モデルによる編成能力の検証ではありません。','',
'ホストの決定的な計算・原文参照・暗号化SQLite・複数プロセス競合・認証・取消・ハッシュ検査は実コードを動かしています。合成の日本語算術データを、実際の企業業務での精度保証やJev/GLiNERの品質保証として扱いません。','',
'## 今回検出し是正した箇所','',
'- 共通モジュール・設定・評価器・起動経路の欠落を復元し、パッケージとして構成。',
'- 操作と元要求の結合、仮想環境のPythonパス保持、SQLite初期化と並行更新の保護。',
'- 改善処理に必要な推論呼び出しの権限を修正し、実行と改善の境界は維持。',
'- 入力名変更によるtest再使用、非公開情報の子実行経由の送信、未知モデルIDの暗黙置換を拒否。',
'- 無限値がPydanticのJSON化でnullに変換される前に、非有限値・非JSON型を拒否。',
'- 観測の表形式出力を次の計算の入力に使用できるよう接続し、絞り込み→集計を検証。',
'- 独立testの成功だけでは、全17ネイティブ機能の未達を残した本番昇格を許可しない。',
'- 配布時の秘密値混入・相対パス脱出・改ざん・既存ファイル上書きを防ぐ検査を追加。','',
'これは過去レビュー24件を全面的に解決したことを意味しません。全エンジンの実接続、実モデルの業務品質、nativeルーターの再学習・重み再配備、実際のAFlow生成コード隔離、負荷・運用試験等は未完了です。','',
'## 再現環境と取得状況','',
'Python 3.13.5 / Linux。ホストは既存の依存パッケージを使用しました。ネイティブ試験の仮想環境は、実際に取得したwheelを`--no-index --no-deps`で導入し、既存親環境のsite-packagesを明示的につないだものです。空の環境から全依存を解決できた証拠ではありません。','',
'全11対象への取得処理を実行し、Gitソース取得10件は失敗、GEPAはパッケージ取得が必要な状態として記録しています。PyPIからのGEPA/litellm取得も実行し、終了コード2でした。ソースの取得失敗を、そのエンジンが非公開・存在しないという結論に読み替えていません。','',
'実際のコマンドと終了コードは`reports/source-acquisition.log`、`source-acquisition.json`、`missing-native-dependencies.log`に残しています。APIキーの値、モデル重み、稼働DB、マスター鍵、仮想環境は配布物へ収録していません。','',
'## 再検証コマンド','',
'```bash',
'uv run pytest --junitxml=reports/recheck.xml',
'uv run python scripts/verify_native_all.py --config config-private/runtime.json \\',
'  --ack-external-cost --output reports/recheck-native.json',
'python scripts/verify_package.py ../jev-all-engines.zip',
'```','',
'ネイティブ試験では合成データだけを使用し、実際のモデル・APIへの送信許可を別に要求します。CLI生存確認、wheelインストール成功、ZIP破損なしだけで全機能が正常と判定しません。', '']
(ROOT/'docs/VERIFICATION_ja.md').write_text('\n'.join(lines),encoding='utf-8')
print(ROOT/'docs/VERIFICATION_ja.md')
