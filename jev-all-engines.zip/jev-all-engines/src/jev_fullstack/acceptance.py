"""Native functional acceptance, separate from whole-system semantic evaluation."""
import json
REQUIRED_NATIVE_CASES=frozenset({
 'ldp','aviary','xgrammar-validation','xgrammar-generation','gliner2','jev','llm',
 'openfugu-compose','openfugu-router','router_r1','roma','autoskill-ingest','autoskill-search',
 'trace','gepa','aflow-optimize','aflow-execute'})

def functional_checks(label,response):
    """Observable task checks, not a provider's self-reported success flag."""
    value=response.get('value',{})
    out={'nonempty_result':isinstance(value,dict) and bool(value)}
    if not out['nonempty_result']:return out
    if label=='ldp':out['decision_payload']=value.get('decision',{}).get('output')=={'ok':True}
    elif label=='aviary':out['native_downstream_result']=value.get('result',{}).get('value',{}).get('valid') is True
    elif label=='xgrammar-validation':out['schema_accepted']=value.get('valid') is True
    elif label=='xgrammar-generation':out['generated_value']=value.get('value')=={'sum':40}
    elif label=='gliner2':
        entities=value.get('extraction',{}).get('entities',{})
        detected={(k,x.get('text')) for k,items in entities.items() for x in items if isinstance(x,dict)}
        out['source_entities']={('person','Alice'),('organization','Acme'),('location','London')} <= detected
    elif label=='jev':out['negation_retained']=value.get('answers',{}).get('cancel',{}).get('choice')=='no'
    elif label=='llm':
        try:out['arithmetic_json']=json.loads(value.get('text',''))=={'sum':40}
        except (ValueError,TypeError):out['arithmetic_json']=False
    elif label=='openfugu-compose':out['executed_dag']=bool(value.get('steps')) and bool(value.get('final'))
    elif label=='openfugu-router':out['trained_route']=type(value.get('agent_id')) is int and 0<=value['agent_id']<7
    elif label=='router_r1':out['terminated_answer']='</answer>' in value.get('output','')
    elif label=='roma':out['completed_recursive_result']=bool(value.get('result')) and bool(value.get('nodes'))
    elif label=='autoskill-ingest':out['native_skill_formed']=bool(value.get('skills')) and bool(value.get('candidate_artifact'))
    elif label=='autoskill-search':out['native_skill_retrieved']=bool(value.get('hits'))
    elif label=='trace':out['native_update_and_reevaluation']=bool(value.get('candidate')) and 'before' in value and 'after' in value
    elif label=='gepa':out['multiple_evaluated_candidates']=int(value.get('candidates',0))>1 and bool(value.get('validation_scores'))
    elif label=='aflow-optimize':out['native_graph_search']=len(value.get('evaluations',[]))>=2 and bool(value.get('candidate_artifact'))
    elif label=='aflow-execute':out['selected_workflow_executed']=bool(value.get('text')) and type(value.get('round')) is int
    return out

