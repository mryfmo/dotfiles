"""Authenticated single-workspace HTTP API and independently runnable workers."""
from __future__ import annotations
from contextlib import asynccontextmanager
import os
import secrets
import time
from fastapi import FastAPI,HTTPException,Header
from .contracts import GoalRequest
from .runtime import Supervisor
from .state import Conflict

def create_app(settings):
    token=os.environ.get('JEV_API_TOKEN','')
    if len(token)<32:raise ValueError('set JEV_API_TOKEN to a random value of at least 32 characters')
    supervisor=Supervisor(settings)
    @asynccontextmanager
    async def lifespan(app):
        yield
        supervisor.close()
    app=FastAPI(title='Jev All Engines',version='3.0.0',lifespan=lifespan)
    def auth(value):
        if not value or not secrets.compare_digest(value,'Bearer '+token):raise HTTPException(401,'authorization required')
    @app.get('/healthz')
    def health():return {'alive':True,'readiness':'not_assessed','native_acceptance_required':True}
    @app.post('/runs',status_code=202)
    def submit(request:GoalRequest,authorization:str|None=Header(default=None)):
        auth(authorization)
        try:return {'run_id':supervisor.submit(request,queued=True)}
        except (ValueError,PermissionError) as e:raise HTTPException(409,str(e)) from e
    @app.get('/runs/{run_id}')
    def get(run_id:str,authorization:str|None=Header(default=None)):
        auth(authorization)
        try:return supervisor.store.get(run_id)
        except KeyError as e:raise HTTPException(404,'run not found') from e
    @app.post('/runs/{run_id}/cancel')
    def cancel(run_id:str,authorization:str|None=Header(default=None)):
        auth(authorization)
        try:supervisor.store.cancel(run_id)
        except KeyError as e:raise HTTPException(404,'run not found') from e
        return {'cancelled':True}
    @app.get('/runs/{run_id}/events')
    def events(run_id:str,authorization:str|None=Header(default=None)):
        auth(authorization)
        try:
            supervisor.store.get(run_id)
            return supervisor.store.events(run_id)
        except KeyError as e:raise HTTPException(404,'run not found') from e
    return app

def worker(settings):
    s=Supervisor(settings)
    try:
        while True:
            for rid in s.store.queued():
                try:s.run(rid)
                except Conflict:continue
            time.sleep(.5)
    except KeyboardInterrupt:pass
    finally:s.close()
