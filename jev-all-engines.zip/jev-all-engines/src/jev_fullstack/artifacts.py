"""Content-addressed, immutable candidate snapshots with source revocation.

Artifacts are private workspace files, NOT physically erasable cryptographic
vaults. Hash verification precedes every use. Never infer approval from capture.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
from .contracts import canonical, digest
from .state import _file_lock

class ArtifactStore:
    def __init__(self,workspace):
        self.root=Path(workspace).absolute()/'artifacts';self.root.mkdir(parents=True,exist_ok=True)
        self.revoked=self.root/'revocations.json'
    def capture(self,source,*,allowed_root,kind,run_id,operation_id,input_fingerprints,classification):
        source=Path(source).absolute();allowed=Path(allowed_root).resolve()
        if source.is_symlink() or not source.resolve().is_relative_to(allowed) or not source.is_dir():raise ValueError('artifact source escaped its workspace')
        files={};total=0
        for p in sorted(source.rglob('*')):
            if p.is_symlink():raise ValueError('symlink in candidate artifact')
            if p.is_dir():continue
            if not p.is_file():raise ValueError('nonregular artifact entry')
            data=p.read_bytes();total+=len(data)
            if total>10_000_000 or len(files)>=1000:raise ValueError('artifact resource limit')
            files[p.relative_to(source).as_posix()]=hashlib.sha256(data).hexdigest()
        if not files:raise ValueError('empty candidate artifact')
        manifest={'kind':kind,'run_id':run_id,'operation_id':operation_id,'classification':classification,
                  'input_fingerprints':sorted(set(input_fingerprints)),'files':files}
        aid=digest(manifest)
        with _file_lock(self.root/'.write.lock'):
            destination=self.root/aid
            if not destination.exists():
                temp=Path(tempfile.mkdtemp(dir=self.root,prefix='.capture-'))
                try:
                    shutil.copytree(source,temp/'data',symlinks=False)
                    (temp/'manifest.json').write_bytes(canonical(manifest))
                    for rel,sha in files.items():
                        if hashlib.sha256((temp/'data'/rel).read_bytes()).hexdigest()!=sha:raise ValueError('artifact changed during capture')
                    os.replace(temp,destination)
                finally:
                    if temp.exists():shutil.rmtree(temp)
        return aid
    def resolve(self,aid):
        if not isinstance(aid,str) or len(aid)!=64 or any(x not in '0123456789abcdef' for x in aid):raise ValueError('invalid artifact identifier')
        with _file_lock(self.root/'.write.lock'):
            revoked=json.loads(self.revoked.read_text()) if self.revoked.exists() else []
            if aid in revoked:raise PermissionError('artifact revoked')
            path=self.root/aid;manifest=json.loads((path/'manifest.json').read_text())
            if digest(manifest)!=aid:raise ValueError('artifact manifest changed')
            actual=set()
            for p in (path/'data').rglob('*'):
                if p.is_symlink():raise ValueError('artifact symlink substitution')
                if p.is_file():actual.add(p.relative_to(path/'data').as_posix())
            if actual!=set(manifest['files']):raise ValueError('artifact file set changed')
            for rel,sha in manifest['files'].items():
                p=path/'data'/rel
                if not p.resolve().is_relative_to((path/'data').resolve()) or hashlib.sha256(p.read_bytes()).hexdigest()!=sha:raise ValueError('artifact content changed')
            return path/'data',manifest
    def revoke_input(self,fp):
        with _file_lock(self.root/'.write.lock'):
            revoked=set(json.loads(self.revoked.read_text())) if self.revoked.exists() else set()
            affected=[]
            for p in self.root.glob('*/manifest.json'):
                manifest=json.loads(p.read_text())
                if fp in manifest['input_fingerprints']:affected.append(p.parent.name)
            revoked.update(affected)
            tmp=self.root/'.revocations.tmp';tmp.write_bytes(canonical(sorted(revoked)));os.replace(tmp,self.revoked)
            return affected
