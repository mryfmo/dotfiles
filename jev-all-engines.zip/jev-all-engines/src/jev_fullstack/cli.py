"""Command line for configuration, native acceptance and serving requests."""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import secrets
import sys
from .contracts import GoalRequest,canonical
from .settings import load_settings
from .runtime import Supervisor
from .evaluation import EvaluationManager

def main(argv=None):
    ap=argparse.ArgumentParser(prog='jev-all')
    ap.add_argument('--config',default='configs/runtime.json')
    sub=ap.add_subparsers(dest='command',required=True)
    sub.add_parser('seed')
    run=sub.add_parser('run');run.add_argument('request',type=Path);run.add_argument('--bundle');run.add_argument('--output',type=Path)
    inspect=sub.add_parser('inspect');inspect.add_argument('run_id')
    verify=sub.add_parser('evaluate');verify.add_argument('bundle_id');verify.add_argument('--dataset',default='test');verify.add_argument('--baseline')
    promote=sub.add_parser('promote');promote.add_argument('bundle_id');promote.add_argument('--expected-active',required=True)
    cancel=sub.add_parser('cancel');cancel.add_argument('run_id')
    serve=sub.add_parser('serve');serve.add_argument('--host',default='127.0.0.1');serve.add_argument('--port',type=int,default=8000)
    sub.add_parser('worker')
    args=ap.parse_args(argv)
    cfg=load_settings(args.config)
    if args.command=='serve':
        import uvicorn
        from .api import create_app
        uvicorn.run(create_app(cfg),host=args.host,port=args.port);return 0
    if args.command=='worker':
        from .api import worker
        worker(cfg);return 0
    s=Supervisor(cfg)
    try:
        if args.command=='seed':result={'bundle_id':s.seed().sha256,'activated':False}
        elif args.command=='run':
            req=GoalRequest.model_validate_json(args.request.read_bytes())
            bundle=s.store.bundle(args.bundle) if args.bundle else None
            result=s.run(s.submit(req,bundle))
            if args.output:args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_bytes(canonical(result))
        elif args.command=='inspect':result={**s.store.get(args.run_id),'operations':s.store.operations(args.run_id),'events':s.store.events(args.run_id)}
        elif args.command=='evaluate':result=EvaluationManager.from_config(s).verify(s.store.bundle(args.bundle_id),args.dataset,s.store.bundle(args.baseline) if args.baseline else None)
        elif args.command=='promote':s.promote(args.bundle_id,None if args.expected_active=='none' else args.expected_active);result={'active':s.store.active()}
        else:s.store.cancel(args.run_id);result={'cancelled':args.run_id}
        print(json.dumps(result,ensure_ascii=False,indent=2));return 2 if result.get('status') in ('failed','unresolved') or result.get('passed') is False else 0
    except Exception as e:
        print(json.dumps({'status':'failed','error':type(e).__name__,'detail':str(e)},ensure_ascii=False),file=sys.stderr);return 2
    finally:s.close()

if __name__=='__main__':raise SystemExit(main())
