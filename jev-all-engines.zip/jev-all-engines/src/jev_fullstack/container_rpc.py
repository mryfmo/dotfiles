"""Execute upstream engines in per-engine environments or restricted OCI workers."""
from __future__ import annotations
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import threading
import time
from .contracts import EngineResponse, NativeRequest, canonical

class NativeRunner:
    def __init__(self,root,settings):self.root=Path(root).absolute();self.settings=copy.deepcopy(settings)
    def is_isolated(self,engine):
        c=self.settings['engines'].get(engine,{})
        return bool(c.get('execution')=='container' and c.get('image') and shutil.which('docker'))
    def _identity(self,name,c):
        source=Path(c.get('source',self.root/'native_envs/sources'/name)).absolute()
        if c.get('source_snapshot'):
            snapshot=c['source_snapshot']
            if snapshot.get('revision')!=c.get('revision') or not snapshot.get('files'):
                raise ValueError('snapshot identity differs from locked source')
            declared=set(snapshot['files'])
            actual={x.relative_to(source).as_posix() for x in source.rglob('*.py')}
            if actual!={x for x in declared if x.endswith('.py')}:
                raise ValueError('source snapshot Python file set changed')
            for rel,blob in snapshot['files'].items():
                file=source/rel
                if Path(rel).is_absolute() or '..' in Path(rel).parts or file.is_symlink() or not file.is_file():
                    raise ValueError('invalid snapshot file')
                content=file.read_bytes()
                computed=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
                if computed!=blob:raise ValueError('upstream Git blob mismatch: '+rel)
            return source,{'repo':c.get('repo'),'revision':c.get('revision'),
                'scope':'verified upstream source module subset, not full repository',
                'files':snapshot['files'],'operations':snapshot['operations']}
        if c.get('wheel'):
            wheel=Path(c['wheel'])
            if not wheel.is_absolute():wheel=self.root/wheel
            if not wheel.is_file() or hashlib.sha256(wheel.read_bytes()).hexdigest()!=c.get('wheel_sha256'):
                raise ValueError('approved upstream wheel missing or changed: '+name)
            return source,{'repo':c.get('repo'),'revision':c.get('revision'),'distribution':c.get('distribution'),
                           'version':c.get('version'),'wheel':str(wheel),'wheel_sha256':c['wheel_sha256']}
        if c.get('revision') and name not in ('xgrammar',):
            if not (source/'.git').exists():raise FileNotFoundError('pinned upstream source absent: '+name)
            r=subprocess.run(['git','rev-parse','HEAD'],cwd=source,capture_output=True,text=True,timeout=10,check=True)
            if r.stdout.strip()!=c['revision']:raise ValueError('upstream commit mismatch: '+name)
            r=subprocess.run(['git','status','--porcelain','--untracked-files=normal'],cwd=source,capture_output=True,text=True,timeout=10,check=True)
            if r.stdout.strip():raise ValueError('upstream source contains unrecorded modifications: '+name)
        return source,{'repo':c.get('repo'),'revision':c.get('revision'),'distribution':c.get('distribution'),'version':c.get('version')}
    def call(self,request:NativeRequest,*,timeout=120,cancelled=lambda:False):
        c=self.settings['engines'][request.engine];ctx=copy.deepcopy(request.context)
        work=Path(ctx['workspace']).absolute();work.mkdir(parents=True,exist_ok=True)
        if os.name!='nt':work.chmod(0o700)
        p=None;container_name=None
        try:
            source,identity=self._identity(request.engine,c)
            if identity.get('operations') and request.operation not in identity['operations']:
                raise FileNotFoundError('this original-source snapshot does not contain the requested upstream operation')
            ctx.update(upstream_root=str(source),source_identity=identity,models=self.settings.get('models',{}),device=c.get('device','cpu'),units=c.get('units',1))
            # Each process sees only its own upstream source paths. Never mix AFlow's
            # top-level scripts package into the supervisor interpreter.
            paths=[str(self.root/'src')]+[str(source/p) for p in c.get('source_paths',[])]+list(c.get('extra_python_paths',[]))
            env={k:v for k,v in os.environ.items() if k in ('PATH','SYSTEMROOT','WINDIR','TMPDIR','LANG','LC_ALL','LD_LIBRARY_PATH')}
            env.update(PYTHONPATH=os.pathsep.join(paths),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',TOKENIZERS_PARALLELISM='false',
                       HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_HUB_DISABLE_TELEMETRY='1',DO_NOT_TRACK='1',
                       HOME=str(work),XDG_CACHE_HOME=str(work/'cache'))
            if c.get('execution','process')=='container':
                if not self.is_isolated(request.engine):raise FileNotFoundError('configured OCI runtime/image missing for '+request.engine)
                container_name='jev-'+request.request_id
                cmd=['docker','run','--rm','--name',container_name,'-i','--network','none','--read-only','--cap-drop','ALL',
                     '--security-opt','no-new-privileges','--pids-limit','128','--memory',c.get('memory','4g'),'--cpus',str(c.get('cpus',2)),
                     '--tmpfs','/tmp:rw,noexec,nosuid,size=128m','--mount',f'type=bind,src={self.root / "src"},dst=/app/src,readonly',
                     '--mount',f'type=bind,src={source},dst=/engine,readonly','--mount',f'type=bind,src={work},dst=/work',
                     '--mount',f'type=bind,src={ctx["gateway_unix_socket"]},dst=/gateway.sock',
                     '-e','PYTHONPATH=/app/src:/engine:/engine/src','-e','PYTHONDONTWRITEBYTECODE=1','-e','PYTHONUTF8=1','-e','HOME=/work',
                     '-w','/work']
                if os.name!='nt':cmd+=['--user',f'{os.getuid()}:{os.getgid()}']
                ctx.update(workspace='/work',upstream_root='/engine',gateway_unix_socket='/gateway.sock',sandbox_enforced=True)
                for kind in ('approved_workflows','approved_skill_snapshots'):
                    mounts={}
                    for alias,path in ctx.get(kind,{}).items():
                        target=f'/approved/{kind}/{hashlib.sha256(alias.encode()).hexdigest()[:16]}'
                        cmd+=['--mount',f'type=bind,src={Path(path).absolute()},dst={target},readonly'];mounts[alias]=target
                    ctx[kind]=mounts
                ctx['models']={}
                cmd+=[c['image'],'python','-m','jev_fullstack.native.container_entry']
                cwd=work
            else:
                if request.engine=='aflow':raise PermissionError('AFlow cannot run in a non-isolated process')
                py=c.get('python')
                if not py or not Path(py).is_file():raise FileNotFoundError('native virtualenv Python absent: '+request.engine)
                # Preserve virtualenv symlink path. Resolving it selects system Python.
                cmd=[str(Path(py).absolute()),'-m','jev_fullstack.native.worker'];cwd=source if source.is_dir() else work
                ctx['sandbox_enforced']=False
            wire=request.model_copy(update={'context':ctx})
            p=subprocess.Popen(cmd,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,cwd=cwd,env=env,
                               start_new_session=(os.name!='nt'))
            stdout=bytearray();stderr=bytearray();overflow=threading.Event()
            def read(stream,target,limit):
                while True:
                    chunk=stream.read(4096)
                    if not chunk:break
                    if len(target)+len(chunk)>limit:overflow.set();break
                    target.extend(chunk)
                stream.close()
            threads=[threading.Thread(target=read,args=(p.stdout,stdout,2000000),daemon=True),threading.Thread(target=read,args=(p.stderr,stderr,1000000),daemon=True)]
            for t in threads:t.start()
            p.stdin.write(canonical(wire));p.stdin.close();start=time.monotonic()
            while p.poll() is None:
                if overflow.is_set():raise ValueError('native process output limit exceeded')
                if cancelled():raise InterruptedError('native invocation cancelled')
                if time.monotonic()-start>timeout:raise TimeoutError('native invocation deadline')
                time.sleep(.05)
            for t in threads:t.join(timeout=3)
            if overflow.is_set():raise ValueError('native process output limit exceeded')
            (work/'native.stderr.log').write_bytes(stderr)
            out=EngineResponse.model_validate_json(bytes(stdout))
            if out.request_id!=request.request_id or out.engine!=request.engine:raise ValueError('worker identity mismatch')
            if p.returncode and out.status=='ok':raise ValueError('worker exit status contradicts response')
            return out.model_copy(update={'provenance':{**out.provenance,'source_identity':identity,'process_returncode':p.returncode}})
        except Exception as e:
            if p is not None and p.poll() is None:
                if os.name!='nt':os.killpg(p.pid,signal.SIGKILL)
                else:p.kill()
                p.wait(timeout=5)
            if container_name:
                subprocess.run(['docker','rm','-f',container_name],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=10)
            out=EngineResponse(request_id=request.request_id,engine=request.engine,
                               status='cancelled' if isinstance(e,InterruptedError) else 'blocked' if isinstance(e,FileNotFoundError) else 'error',
                               error_code=type(e).__name__,error=str(e)[:1000])
            (work/'runner-error.json').write_bytes(canonical(out))
            return out
