"""Versioned contracts shared by the supervisor and upstream engine adapters."""
from __future__ import annotations
import hashlib
import json
import math
from enum import Enum
from typing import Any, Literal
import jsonschema
from pydantic import BaseModel, ConfigDict, Field, model_validator

REQUIRED_ENGINES = frozenset({'ldp','aviary','openfugu','router_r1','roma','autoskill','aflow','trace','xgrammar','gepa','gliner2'})


def canonical(value: Any) -> bytes:
    """Serialize without NaN, ambiguous key order, or non-JSON representations."""
    if isinstance(value, BaseModel):
        value = value.model_dump(mode='python')
    def check(item):
        if item is None or isinstance(item,(str,bool,int)):return
        if isinstance(item,float):
            if not math.isfinite(item):raise ValueError('nonfinite numbers are not JSON values')
            return
        if isinstance(item,(list,tuple)):
            for child in item:check(child)
            return
        if isinstance(item,dict):
            for key,child in item.items():
                if not isinstance(key,str):raise ValueError('JSON object keys must be strings')
                check(child)
            return
        raise ValueError('non-JSON value: '+type(item).__name__)
    check(value)
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')


def digest(value: Any) -> str:
    return hashlib.sha256(canonical(value)).hexdigest()


class ContractModel(BaseModel):
    model_config = ConfigDict(extra='forbid', frozen=True)

    @model_validator(mode='after')
    def reject_non_json_values(self):
        # Inspect Python-mode values before a serializer can turn infinity into null.
        canonical(self)
        return self


class Classification(str, Enum):
    public = 'public'
    internal = 'internal'
    restricted = 'restricted'


class InputDocument(ContractModel):
    id: str = Field(min_length=1, max_length=120, pattern=r'^[A-Za-z0-9_.-]+$')
    content: Any
    classification: Classification = Classification.public


class Constraints(ContractModel):
    max_actions: int = Field(default=80, ge=1, le=10000)
    max_units: int = Field(default=10000, ge=1, le=100000000)
    deadline_seconds: float = Field(default=180, gt=0, le=86400, allow_inf_nan=False)
    max_depth: int = Field(default=3, ge=0, le=10)
    allow_external: bool = False
    allow_effects: bool = False
    allowed_capabilities: tuple[str, ...] | None = None


class GoalRequest(ContractModel):
    goal: str = Field(min_length=1, max_length=20000)
    inputs: tuple[InputDocument, ...] = ()
    requirements: tuple[str, ...] = ()
    constraints: Constraints = Field(default_factory=Constraints)

    @model_validator(mode='after')
    def validate_request(self):
        ids=[x.id for x in self.inputs]
        if len(ids)!=len(set(ids)):
            raise ValueError('input identifiers must be unique')
        if len(canonical(self)) > 1000000:
            raise ValueError('request exceeds the input byte limit')
        return self


def validate_schema(schema: dict) -> None:
    """Validate schemas and forbid remote resolution and pathological sizes."""
    if not isinstance(schema,dict) or len(canonical(schema)) > 60000:
        raise ValueError('schema must be a bounded JSON object')
    def visit(value,depth=0):
        if depth > 24:
            raise ValueError('schema nesting limit exceeded')
        if isinstance(value,dict):
            for k,v in value.items():
                if k in ('$ref','$dynamicRef') and (not isinstance(v,str) or not v.startswith('#')):
                    raise ValueError('remote schema references are forbidden')
                visit(v,depth+1)
        elif isinstance(value,list):
            for v in value:visit(v,depth+1)
    visit(schema)
    jsonschema.Draft202012Validator.check_schema(schema)


class GoalContract(ContractModel):
    request_sha256: str = Field(pattern=r'^[0-9a-f]{64}$')
    goal: str
    requirements: tuple[str, ...]
    output_schema: dict
    requirement_map: dict[str, str]
    unknowns: tuple[str, ...] = ()

    @model_validator(mode='after')
    def schema_is_valid(self):
        validate_schema(self.output_schema)
        return self

    def bind(self,request:GoalRequest) -> None:
        if (self.request_sha256 != digest(request) or self.goal != request.goal or self.requirements != request.requirements):
            raise ValueError('generated contract altered the immutable request')
        expected={f'R{i+1}' for i in range(len(request.requirements))}
        if set(self.requirement_map)!=expected or any(not s.strip() for s in self.requirement_map.values()):
            raise ValueError('requirements are not completely traceable')


class Action(ContractModel):
    capability: str = Field(min_length=1, max_length=120)
    arguments: dict[str, Any]
    input_refs: tuple[str, ...] = ()
    purpose: str = ''


class Decision(ContractModel):
    kind: Literal['act','finish','unresolved']
    action: Action | None = None
    output: Any = None
    evidence: tuple[str, ...] = ()

    @model_validator(mode='after')
    def consistent(self):
        if (self.kind=='act') != (self.action is not None):
            raise ValueError('act requires an action; final decisions forbid one')
        return self


class Capability(ContractModel):
    id: str
    engine: str
    operation: str
    description: str
    arguments_schema: dict
    estimated_units: int = Field(default=1, ge=1)
    external: bool = False
    effectful: bool = False
    phase: Literal['execute','improve','both'] = 'execute'
    requires_sandbox: bool = False


class Observation(ContractModel):
    action_id: str
    capability: str
    status: Literal['ok','missing','unknown','partial','error','outcome_unknown']
    value: Any = None
    error_code: str | None = None
    provenance: dict[str, Any] = Field(default_factory=dict)
    units: int = Field(default=0, ge=0)


class NativeRequest(ContractModel):
    request_id: str
    engine: str
    operation: str
    payload: dict[str, Any]
    context: dict[str, Any] = Field(default_factory=dict)


class EngineResponse(ContractModel):
    request_id: str
    engine: str
    status: Literal['ok','blocked','error','cancelled']
    value: Any = None
    error_code: str | None = None
    error: str | None = None
    provenance: dict[str, Any] = Field(default_factory=dict)
    events: list[dict] = Field(default_factory=list)
    units: int = Field(default=0, ge=0)


class Bundle(ContractModel):
    version: str
    parent: str | None = None
    engines: dict[str, str]
    prompts: dict[str, str]
    model_bindings: dict[str, Any]
    artifacts: dict[str, str] = Field(default_factory=dict)
    evaluator_version: str = 'exact-json-v1'
    dataset_lineage: tuple[str, ...] = ()

    @model_validator(mode='after')
    def mandatory_scope(self):
        if set(self.engines)!=REQUIRED_ENGINES:
            raise ValueError('all eleven upstream engines are mandatory')
        return self

    @property
    def sha256(self) -> str:
        return digest(self)
