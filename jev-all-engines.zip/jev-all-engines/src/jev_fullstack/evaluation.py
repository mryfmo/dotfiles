"""Independent exact-JSON evaluation of whole goal-driven executions.

Reference answers are host-only. Optimizers get requests and measured feedback,
never test datasets. No optimizer-supplied metric or acceptance rule is trusted.
"""
from __future__ import annotations
import copy
import json
from pathlib import Path
import secrets
from .contracts import Bundle,GoalRequest,canonical,digest

class EvaluationManager:
    def __init__(self,supervisor,datasets):
        self.s=supervisor;self.datasets=copy.deepcopy(datasets);self.s.evaluator=self
        self._validate_datasets()
    @classmethod
    def from_config(cls,supervisor):
        data={k:json.loads(Path(v).read_text()) if isinstance(v,str) else v for k,v in supervisor.settings.get('datasets',{}).items()}
        return cls(supervisor,data)
    def _validate_datasets(self):
        seen={};ids=set();groups={}
        for name,dataset in self.datasets.items():
            split=dataset.get('split',name)
            if split not in ('train','validation','test','post_promotion'):raise ValueError('unknown split')
            if not dataset.get('examples'):raise ValueError('dataset is empty')
            for ex in dataset['examples']:
                req=GoalRequest.model_validate(ex['request'])
                if ex['id'] in ids:raise ValueError('duplicate example ID')
                ids.add(ex['id']);fp=self.s.store.register_eval_input(req,'dataset',split)
                if fp in seen:raise ValueError('duplicate or leaked request')
                seen[fp]=name
                group=ex.get('group',ex['id'])
                if group in groups and groups[group]!=split:raise ValueError('group leakage')
                groups[group]=split
                if 'expected' not in ex:raise ValueError('host-side reference output required')
    def examples(self,dataset_id):
        ds=self.datasets[dataset_id]
        if ds.get('split',dataset_id) not in ('train','validation'):raise PermissionError('optimizer cannot access holdout')
        return [{k:v for k,v in ex.items() if k in ('id','request')} for ex in ds['examples']]
    def _candidate(self,base,candidate):
        if set(candidate)!=set(base.prompts) or any(not isinstance(v,str) or not v.strip() or len(v)>40000 for v in candidate.values()):
            raise ValueError('optimizer changed fixed component structure')
        b=base.model_copy(update={'version':'candidate-'+secrets.token_hex(8),'parent':base.sha256,'prompts':dict(candidate)})
        self.s.store.add_bundle(b);return b
    def _score(self,ex,output):
        if isinstance(output,str):
            try:output=json.loads(output)
            except ValueError:return 0.0
        try:return 1.0 if canonical(output)==canonical(ex['expected']) else 0.0
        except (ValueError,TypeError):return 0.0
    def _run(self,ex,bundle,parent=None):
        request=GoalRequest.model_validate(ex['request']);rid=self.s.submit(request,bundle,parent_id=parent)
        result=self.s.run(rid)
        score=self._score(ex,result['state'].get('output')) if result['status']=='succeeded' else 0.0
        return {'id':ex['id'],'run_id':rid,'status':result['status'],'score':score,'output':result['state'].get('output'),
                'units':result['units'],'operations':result['operations'],'events':result['events'],'request':ex['request']}
    def evaluate_candidate(self,payload,scope):
        dataset_id=payload['dataset_id'];examples=self.examples(dataset_id)
        wanted=set(payload.get('example_ids',[x['id'] for x in examples]))
        if not wanted or not wanted<={x['id'] for x in examples}:raise ValueError('invalid evaluation subset')
        base=Bundle.model_validate(self.s.store.get(scope.run_id)['state']['bundle']);candidate=self._candidate(base,payload['candidate'])
        actual=[ex for ex in self.datasets[dataset_id]['examples'] if ex['id'] in wanted]
        docs=[d for ex in actual for d in GoalRequest.model_validate(ex['request']).inputs]
        rank={'public':0,'internal':1,'restricted':2}
        label=max([d.classification.value for d in docs] or ['public'],key=rank.__getitem__)
        self.s.store.record_lineage(scope.run_id,[digest(d.content) for d in docs],label)
        items=[self._run(ex,candidate,scope.run_id) for ex in actual]
        return {'score':sum(x['score'] for x in items)/len(items),'items':items,'candidate_hash':candidate.sha256,'oracle':'exact-json-v1'}
    def score_native(self,payload,scope):
        dataset_id=payload['dataset_id'];self.examples(dataset_id)
        refs={x['id']:x for x in self.datasets[dataset_id]['examples']};outs=payload['outputs']
        if {x['id'] for x in outs}!=set(refs) or len(outs)!=len(refs):raise ValueError('missing/duplicate scoring output')
        items=[{'id':x['id'],'score':self._score(refs[x['id']],x['output'])} for x in outs]
        return {'score':sum(x['score'] for x in items)/len(items),'items':items,'oracle':'exact-json-v1'}
    def verify(self,bundle,dataset_id,baseline=None):
        ds=self.datasets[dataset_id]
        if ds.get('split',dataset_id)!='test':raise ValueError('release verification requires independent test')
        exs=ds['examples'];eid=secrets.token_hex(16)
        fps=[self.s.store.register_eval_input(GoalRequest.model_validate(x['request']),bundle.sha256,'test') for x in exs]
        self.s.store.consume_test(fps,eid)
        rows=[self._run(x,bundle) for x in exs];old=[self._run(x,baseline) for x in exs] if baseline else []
        accuracy=sum(r['score'] for r in rows)/len(rows)
        passed=all(r['score']==1 and r['status']=='succeeded' for r in rows)
        if old and accuracy<sum(r['score'] for r in old)/len(old):passed=False
        report={'split':'test','passed':passed,'accuracy':accuracy,'candidate':rows,'baseline':old,
                'run_ids':[r['run_id'] for r in rows],'dataset_sha256':digest(ds),'oracle':'exact-json-v1'}
        rid=self.s.store.record_evaluation(bundle.sha256,baseline.sha256 if baseline else None,report)
        if passed:self.s.store.attest(bundle.sha256,rid)
        return {**report,'evaluation_id':rid}
