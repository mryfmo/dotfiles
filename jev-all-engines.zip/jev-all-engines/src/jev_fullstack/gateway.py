"""Revocable, invocation-scoped gateway shared by native engine processes."""
from __future__ import annotations
from dataclasses import dataclass, field
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import secrets
import socketserver
import threading
import tempfile
import shutil
import time
from typing import Any

@dataclass(frozen=True)
class Scope:
    run_id:str
    owner:str
    fence:int
    depth:int
    phase:str
    capabilities:frozenset[str]
    deadline:float
    engine:str='supervisor'
    invocation_id:str=''
    expected_action:dict | None=None

if hasattr(socketserver,'UnixStreamServer'):
    class _UnixServer(socketserver.ThreadingMixIn,socketserver.UnixStreamServer):
        daemon_threads=True
else:
    _UnixServer=None

class Gateway:
    def __init__(self,callback,*,socket_path=None):
        self.callback=callback;self._tokens={};self._lock=threading.RLock();self.socket_path=None;self._socket_directory=None
        outer=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args):pass
            def do_POST(self):
                code=200
                try:
                    if self.headers.get('Transfer-Encoding'):raise ValueError('chunked requests are not accepted')
                    length=int(self.headers.get('Content-Length','0'))
                    if not 0<length<=1000000:raise ValueError('invalid request size')
                    auth=self.headers.get('Authorization','')
                    if not auth.startswith('Bearer '):raise PermissionError('authorization required')
                    with outer._lock:scope=outer._tokens.get(auth[7:])
                    if scope is None or scope.deadline<=time.time():raise PermissionError('expired or revoked invocation')
                    self.connection.settimeout(max(.1,min(120,scope.deadline-time.time())))
                    data=json.loads(self.rfile.read(length))
                    if not isinstance(data,dict):raise ValueError('JSON object required')
                    result=outer.callback(scope,self.path,data)
                except PermissionError as e:code=403;result={'error':{'type':'authorization','message':str(e)}}
                except (ValueError,KeyError) as e:code=400;result={'error':{'type':'contract','message':str(e)[:400]}}
                except Exception as e:code=500;result={'error':{'type':type(e).__name__,'message':'native gateway execution failed'}}
                body=json.dumps(result,ensure_ascii=False,allow_nan=False).encode()
                if len(body)>2000000:code=500;body=b'{"error":{"type":"ResponseLimit"}}'
                self.send_response(code);self.send_header('Content-Type','application/json; charset=utf-8')
                self.send_header('Content-Length',str(len(body)));self.end_headers()
                try:self.wfile.write(body)
                except (BrokenPipeError,ConnectionResetError):pass
        self.http=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.url=f'http://127.0.0.1:{self.http.server_port}'
        self.servers=[self.http];self.threads=[]
        if socket_path is not None and os.name!='nt':
            self.socket_path=str(Path(socket_path).absolute())
            if len(os.fsencode(self.socket_path))>=100:
                self._socket_directory=tempfile.mkdtemp(prefix='jev-uds-')
                os.chmod(self._socket_directory,0o700)
                self.socket_path=str(Path(self._socket_directory)/'gateway.sock')
            Path(self.socket_path).parent.mkdir(parents=True,exist_ok=True)
            if Path(self.socket_path).exists():raise FileExistsError('gateway socket already exists')
            server=_UnixServer(self.socket_path,Handler);os.chmod(self.socket_path,0o600);self.servers.append(server)
        for server in self.servers:
            thread=threading.Thread(target=lambda server=server:server.serve_forever(poll_interval=0.05),daemon=True);thread.start();self.threads.append(thread)

    def issue(self,scope):
        token=secrets.token_urlsafe(32)
        with self._lock:self._tokens[token]=scope
        return token
    def revoke(self,token):
        with self._lock:self._tokens.pop(token,None)
    def close(self):
        with self._lock:self._tokens.clear()
        for s in self.servers:s.shutdown();s.server_close()
        for t in self.threads:t.join(timeout=2)
        if self.socket_path:Path(self.socket_path).unlink(missing_ok=True)
        if self._socket_directory:shutil.rmtree(self._socket_directory,ignore_errors=True)
