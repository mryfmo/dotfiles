"""Explicit deterministic utilities; never labelled as an upstream AI engine."""
import math
class MissingValue(ValueError):pass

def execute(operation,args,request,observations=()):
    input_id=args['input_id']
    doc=next((d for d in request.inputs if d.id==input_id),None)
    if doc is not None:
        data=doc.content
    else:
        recorded=next((o for o in observations if o.get('action_id')==input_id and o.get('status')=='ok'),None)
        value=recorded.get('value') if recorded else None
        if not isinstance(value,dict) or not isinstance(value.get('rows'),list):
            raise KeyError('input is neither an original document nor a successful table observation in this run')
        data=value['rows']
    if operation=='read':return {'input_id':input_id,'content':data}
    if not isinstance(data,list) or any(not isinstance(r,dict) for r in data):
        raise ValueError('table input must be a list of objects')
    op=args['operation'];col=args.get('column')
    if op=='count':return {'value':len(data),'input_id':input_id}
    if not col:raise ValueError('column is required')
    def field(row):
        if col not in row or row[col] is None:raise MissingValue('missing is not zero')
        return row[col]
    def number(row):
        n=field(row)
        if isinstance(n,bool) or not isinstance(n,(int,float)) or not math.isfinite(n):
            raise ValueError('finite numeric values required')
        return n
    if op in ('sum','mean'):
        vals=[number(r) for r in data]
        if op=='mean' and not vals:raise MissingValue('mean of empty data is unknown')
        return {'value':sum(vals) if op=='sum' else sum(vals)/len(vals),'input_id':input_id}
    if op=='group_sum':
        g=args.get('group_by');out={}
        if not g:raise ValueError('group_by required')
        for row in data:
            if g not in row or row[g] is None:raise MissingValue('missing group key')
            key=str(row[g]);out[key]=out.get(key,0)+number(row)
        return {'value':out,'input_id':input_id}
    if op=='filter':return {'rows':[r for r in data if field(r)==args.get('equals')],'input_id':input_id}
    if op=='sort':return {'rows':sorted(data,key=field,reverse=args.get('descending',False)),'input_id':input_id}
    raise ValueError('unknown table operation')
