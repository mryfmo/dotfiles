"""Native adapters. No upstream implementation is replaced."""
