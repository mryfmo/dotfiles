"""AFlow native structure search; only the task-specific evaluator is adapted."""
from __future__ import annotations
import json
import os
import shutil
from pathlib import Path
import sys
from .common import Bridge,workspace,compact


def execute(engine,operation,payload,ctx):
    if operation not in ('optimize','execute'):raise ValueError('unsupported AFlow operation')
    if not ctx.get('sandbox_enforced'):
        raise PermissionError('AFlow generated code requires an isolated sandbox')
    if operation=='optimize' and ctx.get('phase')!='improve':
        raise PermissionError('AFlow search requires improvement context')
    from scripts.optimizer import Optimizer
    from scripts.async_llm import LLMConfig
    bridge=Bridge(ctx);work=workspace(ctx);dataset='JFS'
    os.chdir(work);sys.path.insert(0,str(work))
    os.environ['JFS_AFLOW_CONTEXT']=compact(ctx)
    llm=LLMConfig({'model':ctx.get('reflection_model','controller'),'key':ctx['gateway_token'],
                  'base_url':ctx['gateway_url'].rstrip('/')+'/v1','temperature':0})
    if operation=='execute':
        from scripts.optimizer_utils.graph_utils import GraphUtils
        approved=ctx.get('approved_workflows',{})
        if payload['workflow_snapshot'] not in approved:raise PermissionError('workflow is not in the execution bundle')
        source=Path(approved[payload['workflow_snapshot']]).resolve()
        # Copy into isolated scratch space; keep the approved artifact immutable.
        shutil.copytree(source,work/'workspace',dirs_exist_ok=True)
        metadata=json.loads((work/'workspace'/'JFS_ARTIFACT.json').read_text())
        round_id=metadata['selected_round']
        if type(round_id)!=int or round_id<1:raise ValueError('invalid selected workflow round')
        graph=GraphUtils('workspace/JFS').load_graph(round_id,'workspace/JFS/workflows')
        instance=graph(name='accepted-aflow',llm_config=llm,dataset=dataset)
        import asyncio
        result,cost=asyncio.run(instance(payload['goal']))
        return {'text':result,'native_reported_cost':cost,'round':round_id,
                'workflow_snapshot':payload['workflow_snapshot']}
    root=work/'workspace'/dataset/'workflows'
    for d in [work/'workspace',work/'workspace'/dataset,root,root/'template',root/'round_1']:
        d.mkdir(parents=True,exist_ok=True);(d/'__init__.py').write_text('')
    # Native AFlow generates workflows around this registered operator. The operator
    # invokes the same supervisor rather than executing a substitute task engine.
    operator_code='''from jev_fullstack.native.common import Bridge
import json, os
class NativeTask:
    def __init__(self, llm):
        self.bridge=Bridge(json.loads(os.environ["JFS_AFLOW_CONTEXT"]))
    async def __call__(self, problem, instruction="", capability="llm.reason"):
        result=self.bridge.post("/internal/subtask",{"goal":problem,"context":instruction,"capability":capability})
        if result.get("status")!="ok":
            raise RuntimeError("native task failed: "+str(result.get("error_code")))
        value=result.get("value")
        return {"response":value["text"] if isinstance(value,dict) and isinstance(value.get("text"),str) else json.dumps(value,ensure_ascii=False)}
'''
    (root/'template'/'operator.py').write_text(operator_code,encoding='utf-8')
    (root/'template'/'operator.json').write_text(compact({'NativeTask':{
        'description':'Execute a subgoal under fixed constraints using an authorized capability. Allowed targets: '+', '.join(c for c in ctx.get('allowed_capabilities',[]) if c in ('llm.reason','jev.judge','gliner2.extract','source.read','compute.table','xgrammar.validate','xgrammar.generate')),
        'interface':'await self.native(problem: str, instruction: str = "", capability: str = "llm.reason") -> {response: str}'}}),encoding='utf-8')
    seed='''from scripts.async_llm import create_llm_instance
import workspace.JFS.workflows.template.operator as operator
class Workflow:
    def __init__(self,name,llm_config,dataset):
        self.name=name;self.llm=create_llm_instance(llm_config);self.native=operator.NativeTask(self.llm)
    async def __call__(self,problem):
        result=await self.native(problem)
        return result["response"],0.0
'''
    (root/'round_1'/'graph.py').write_text(seed,encoding='utf-8')
    (root/'round_1'/'prompt.py').write_text('',encoding='utf-8')
    os.environ['JFS_AFLOW_CONTEXT']=compact(ctx)
    llm=LLMConfig({'model':ctx.get('reflection_model','controller'),'key':ctx['gateway_token'],
                  'base_url':ctx['gateway_url'].rstrip('/')+'/v1','temperature':0})
    optimizer=Optimizer(dataset=dataset,question_type='qa',opt_llm_config=llm,
        exec_llm_config=llm,operators=['NativeTask'],sample=1,check_convergence=False,
        optimized_path='workspace',initial_round=1,max_rounds=payload.get('rounds',1),validation_rounds=1)
    records=[]
    class IndependentEvaluation:
        async def evaluate_graph(self,opt,directory,validation_n,data,initial=False):
            examples=bridge.dataset(payload['dataset_id'])
            outputs=[]
            graph=opt.graph(name='native-aflow',llm_config=llm,dataset=dataset)
            for ex in examples:
                # The worker receives requests, never reference answers.
                prediction,_=await graph(compact(ex['request']))
                outputs.append({'id':ex['id'],'output':prediction})
            scored=bridge.post('/internal/score',{'dataset_id':payload['dataset_id'],'outputs':outputs})
            round_id=opt.round if initial else opt.round+1
            record=opt.data_utils.create_result_data(round_id,float(scored['score']),0.0,0.0)
            data.append(record)
            target=opt.data_utils.get_results_file_path(str(root))
            opt.data_utils.save_results(target,data)
            records.append({'round':round_id,'evaluation':scored,'outputs':outputs})
            return float(scored['score'])
    # AFlow's search, graph parsing/writing, parent sampling and experience update
    # remain the published implementations. The evaluator is necessarily task-specific.
    optimizer.evaluation_utils=IndependentEvaluation()
    optimizer.optimize(mode='Graph')
    candidates=sorted(root.glob('round_*/graph.py'))
    if len(candidates)<2 or len(records)<2:
        raise RuntimeError('AFlow did not generate and evaluate a new native workflow')
    best=max(records,key=lambda r:r['evaluation']['score'])
    (work/'workspace'/'JFS_ARTIFACT.json').write_text(compact({'selected_round':best['round'],
        'dataset':'JFS','native_engine':'AFlow','requires_independent_holdout':True}),encoding='utf-8')
    return {'workflow_files':[str(p) for p in candidates],'evaluations':records,
            'candidate_root':str(work/'workspace'),
            'status':'candidate_not_promoted','cost_note':'shared gateway usage is authoritative; AFlow zero-price defaults are not billing evidence'}
