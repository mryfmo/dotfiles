"""Native AutoSkill lifecycle in isolated candidate or approved snapshot stores."""
from __future__ import annotations
import dataclasses
import shutil
from pathlib import Path
from .common import Bridge,workspace,NativeBlocked


def execute(engine,operation,payload,ctx):
    from autoskill import AutoSkill,AutoSkillConfig
    from autoskill.llm.base import LLM
    from autoskill.llm.factory import register_llm_connector
    bridge=Bridge(ctx)
    class GatewayLLM(LLM):
        def complete(self,*,system,user,temperature=0.0):
            messages=([{'role':'system','content':system}] if system else [])+[{'role':'user','content':user}]
            return bridge.text(messages,temperature=temperature,max_tokens=4096)
    register_llm_connector('jfs_gateway',lambda cfg:GatewayLLM(),override=True)
    work=workspace(ctx)
    if operation=='search':
        snapshot=payload['skill_snapshot']
        approved=ctx.get('approved_skill_snapshots',{})
        if snapshot not in approved:raise PermissionError('skill snapshot is not approved')
        source=Path(approved[snapshot]).resolve()
        if not source.is_dir():raise NativeBlocked('approved skill snapshot is absent')
        # The SDK maintains usage counters; never mutate the approved snapshot.
        store=work/'skillbank_read_copy'
        shutil.copytree(source,store,dirs_exist_ok=True)
    elif operation=='ingest':
        if ctx.get('phase')!='improve':raise PermissionError('skill updates require improvement context')
        store=work/'candidate_skillbank'
    else:raise ValueError('unsupported AutoSkill operation')
    sdk=AutoSkill(AutoSkillConfig(llm={'provider':'jfs_gateway'},
        embeddings={'provider':'hashing','dims':384},store={'provider':'local','path':str(store)}))
    user_id=ctx.get('tenant','default')
    if operation=='ingest':
        if not(payload.get('messages') or payload.get('events')):raise ValueError('empty training trajectory')
        skills=sdk.ingest(user_id=user_id,messages=payload.get('messages'),events=payload.get('events'),
                         hint=payload.get('hint'),metadata={'run_id':ctx['run_id'],'split':'train'})
        return {'skills':[dataclasses.asdict(s) for s in skills],'candidate_store':str(store),
                'status':'candidate_requires_independent_validation'}
    hits=sdk.search(payload['query'],user_id=user_id,limit=5)
    return {'hits':[{'skill':dataclasses.asdict(h.skill),'score':float(h.score)} for h in hits]}
