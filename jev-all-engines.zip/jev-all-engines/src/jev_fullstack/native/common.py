"""Standard-library-only native worker bridge; provider keys stay with the host."""
from __future__ import annotations
import hashlib
import http.client
import json
from pathlib import Path
import socket
from urllib.parse import urlsplit

class NativeBlocked(RuntimeError):pass

def compact(value):return json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)

def json_object(text):
    out=json.loads(text)
    if not isinstance(out,dict):raise ValueError('expected a JSON object')
    return out

def workspace(ctx):
    p=Path(ctx['workspace']).absolute();p.mkdir(parents=True,exist_ok=True);return p

def model_directory(ctx,name):
    spec=ctx.get('models',{}).get(name,{})
    raw=spec.get('path')
    if not raw:raise NativeBlocked(name+' checkpoint path is not configured')
    path=Path(raw)
    if not path.is_dir():raise NativeBlocked(name+' checkpoint directory is absent')
    manifest=spec.get('files')
    if not manifest or not isinstance(manifest,dict):raise NativeBlocked(name+' checkpoint file hashes are required')
    actual=set()
    for candidate in path.rglob('*'):
        if candidate.is_symlink():raise NativeBlocked('symlink in checkpoint directory')
        if candidate.is_file():actual.add(candidate.relative_to(path).as_posix())
    if actual!=set(manifest):raise NativeBlocked(name+' checkpoint file set differs from pinned manifest')
    for rel,sha in manifest.items():
        file=path/rel
        if Path(rel).is_absolute() or '..' in Path(rel).parts or file.is_symlink() or not file.is_file():raise NativeBlocked('unsafe or missing checkpoint file')
        if not file.resolve().is_relative_to(path.resolve()):raise NativeBlocked('checkpoint path escape')
        h=hashlib.sha256()
        with file.open('rb') as f:
            for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
        if h.hexdigest()!=sha:raise NativeBlocked(name+' checkpoint checksum mismatch')
    return str(path.absolute())

class UnixHTTPConnection(http.client.HTTPConnection):
    def __init__(self,path,timeout=120):super().__init__('localhost',timeout=timeout);self.path=path
    def connect(self):
        self.sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM);self.sock.settimeout(self.timeout);self.sock.connect(self.path)

class Bridge:
    def __init__(self,ctx):self.ctx=ctx;self.model=ctx.get('llm_model','controller')
    def post(self,path,payload):
        timeout=max(.1,float(self.ctx.get('timeout',120)))
        if self.ctx.get('gateway_unix_socket'):
            conn=UnixHTTPConnection(self.ctx['gateway_unix_socket'],timeout)
        else:
            u=urlsplit(self.ctx['gateway_url'])
            if u.scheme!='http' or u.hostname not in ('127.0.0.1','localhost'):raise PermissionError('worker bridge must be local')
            conn=http.client.HTTPConnection(u.hostname,u.port,timeout=timeout)
        try:
            body=compact(payload).encode();conn.request('POST',path,body,{'Authorization':'Bearer '+self.ctx['gateway_token'],'Content-Type':'application/json'})
            resp=conn.getresponse();raw=resp.read(2000001)
            if len(raw)>2000000:raise ValueError('gateway response too large')
            result=json.loads(raw)
            if resp.status==403:raise PermissionError(result.get('error',{}).get('message','gateway denied'))
            if resp.status>=400:raise RuntimeError('gateway rejected request: '+str(result.get('error',{})))
            return result
        finally:conn.close()
    def chat(self,messages,**kw):
        return self.post('/v1/chat/completions',{'model':kw.pop('model',self.model),'messages':messages,**kw})
    def text(self,messages,**kw):
        out=self.chat(messages,**kw)['choices'][0]['message']['content']
        if not isinstance(out,str):raise ValueError('text completion missing')
        return out
    def invoke(self,capability,arguments):return self.post('/internal/invoke',{'capability':capability,'arguments':arguments})
    def dataset(self,dataset_id):return self.post('/internal/dataset',{'dataset_id':dataset_id})['examples']
    def evaluate(self,dataset_id,candidate,**kw):return self.post('/internal/evaluate',{'dataset_id':dataset_id,'candidate':candidate,**kw})
