"""Start a local gateway proxy before executing an isolated native invocation."""
import contextlib
import importlib
import json
import sys
import traceback
from .common import compact
from .uds_proxy import Proxy
from .worker import MODULES

def main():
    req=json.loads(sys.stdin.buffer.read(2000001));proxy=Proxy(req['context']['gateway_unix_socket'])
    req['context']['gateway_url']=proxy.url
    out={'request_id':req['request_id'],'engine':req['engine']}
    try:
        with contextlib.redirect_stdout(sys.stderr):
            value=importlib.import_module('jev_fullstack.native.'+MODULES[req['engine']]).execute(req['engine'],req['operation'],req['payload'],req['context'])
        out.update(status='ok',value=value,provenance={'kind':'upstream_native_isolated'},units=1)
    except Exception as e:
        traceback.print_exc(file=sys.stderr);out.update(status='error',error_code=type(e).__name__,error=str(e)[:1200])
    finally:proxy.close()
    print(compact(out));return 0 if out['status']=='ok' else 2
if __name__=='__main__':raise SystemExit(main())
