"""GEPA's native engine optimizes entire executions, with explicit trajectory reflection."""
from __future__ import annotations
from .common import Bridge


def execute(engine,operation,payload,ctx):
    if operation!='optimize':raise ValueError('unsupported GEPA operation')
    if ctx.get('phase')!='improve':raise PermissionError('optimization outside improvement context')
    import gepa
    from gepa.core.adapter import GEPAAdapter,EvaluationBatch
    bridge=Bridge(ctx)
    keys=set(payload['candidate'])
    train=[{**ex,'dataset_id':payload['train_id']} for ex in bridge.dataset(payload['train_id'])]
    validation=[{**ex,'dataset_id':payload['validation_id']} for ex in bridge.dataset(payload['validation_id'])]
    if {x['id'] for x in train}&{x['id'] for x in validation}:raise ValueError('train/validation overlap')
    class FullSystemAdapter(GEPAAdapter):
        def evaluate(self,batch,candidate,capture_traces=False):
            if set(candidate)!=keys or any(not isinstance(v,str) for v in candidate.values()):
                raise ValueError('candidate changed protected contract')
            outputs=[];scores=[];traces=[]
            for ex in batch:
                result=bridge.evaluate(ex['dataset_id'],candidate,example_ids=[ex['id']],capture_traces=True)
                outputs.append(result['items'][0]['output']);scores.append(float(result['items'][0]['score']));traces.append(result['items'][0])
            return EvaluationBatch(outputs=outputs,scores=scores,trajectories=traces if capture_traces else None)
        def make_reflective_dataset(self,candidate,eval_batch,components_to_update):
            records=[]
            for i,out in enumerate(eval_batch.outputs):
                records.append({'output':out,'score':eval_batch.scores[i],
                    'trajectory':eval_batch.trajectories[i] if eval_batch.trajectories else {},
                    'fixed_constraints':'Do not change requirements, authorization, hard limits, evaluation labels or test split.'})
            return {key:records for key in components_to_update}
    def reflect(messages):
        return bridge.text(messages,model=ctx.get('reflection_model',bridge.model),max_tokens=4096)
    result=gepa.optimize(seed_candidate=payload['candidate'],trainset=train,valset=validation,
        adapter=FullSystemAdapter(),reflection_lm=reflect,max_metric_calls=payload.get('max_metric_calls',32),
        skip_perfect_score=False,reflection_minibatch_size=min(2,len(train)),
        display_progress_bar=False,raise_on_exception=True,seed=20260920,
        run_dir=ctx['workspace']+'/gepa')
    candidate=result.best_candidate
    return {'candidate':candidate,'status':'candidate_not_promoted',
            'candidates':len(result.candidates),'validation_scores':list(result.val_aggregate_scores)}
