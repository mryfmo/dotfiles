"""GLiNER2 model inference with exact source-span verification."""
from __future__ import annotations
import hashlib
from .common import model_directory


def execute(engine,operation,payload,ctx):
    if operation!='extract':raise ValueError('unsupported GLiNER2 operation')
    from gliner2 import AutoExtractor
    path=model_directory(ctx,'gliner2')
    model=AutoExtractor.from_pretrained(path,local_files_only=True)
    if hasattr(model,'to'):model=model.to(ctx.get('device','cpu'))
    text=payload['text']
    result=model.extract_entities(text,payload['labels'],threshold=payload.get('threshold',0.5),
                                  include_spans=True,include_confidence=True)
    for label,entities in result.get('entities',{}).items():
        for entity in entities:
            if not isinstance(entity,dict):raise ValueError('GLiNER2 did not return requested spans')
            start,end=entity.get('start'),entity.get('end')
            if type(start)!=int or type(end)!=int or not (0<=start<end<=len(text)):
                raise ValueError('invalid source span')
            if text[start:end]!=entity.get('text'):raise ValueError('extraction/source mismatch')
    return {'extraction':result,'source_sha256':hashlib.sha256(text.encode()).hexdigest(),
            'empty_means':'not_detected_not_proof_of_absence','model_path':path}
