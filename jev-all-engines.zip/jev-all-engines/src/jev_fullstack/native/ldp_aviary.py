"""Native LDP stochastic graph and Aviary Environment boundaries."""
from __future__ import annotations
import asyncio
import json
from .common import Bridge,compact,json_object


def execute(engine,operation,payload,ctx):
    bridge=Bridge(ctx)
    if engine=='ldp' and operation=='decide':
        from ldp.agent import Agent
        from ldp.graph import FxnOp,compute_graph
        class GoalAgent(Agent):
            def __init__(self):
                self.decision_op=FxnOp(self.choose)
            async def init_state(self,tools):
                return {'tools':tools,'messages':[]}
            async def choose(self,messages,tools):
                return json_object(bridge.text(messages,response_format={'type':'json_object'},max_tokens=2048))
            @compute_graph()
            async def get_asv(self,state,observations):
                nxt={'tools':state['tools'],'messages':state['messages']+observations}
                result=await self.decision_op(nxt['messages'],nxt['tools'])
                return result,nxt,0.0
        async def run():
            agent=GoalAgent()
            state=await agent.init_state(payload['tools'])
            result,state,value=await agent.get_asv(state,payload['messages'])
            return {'decision':result.value,'call_id':str(result.call_id),'value_estimate':value}
        return asyncio.run(run())
    if engine=='aviary' and operation=='execute':
        from aviary.core import Message,Tool,ToolCall,ToolRequestMessage
        from aviary.env import Environment
        action=payload['action']
        def execute_capability(capability: str, arguments: dict) -> str:
            """Execute an authorized capability through the common supervisor.

            Args:
                capability: Capability identifier chosen from the permitted catalog.
                arguments: Arguments validated against that capability's schema.
            """
            return compact(bridge.invoke(capability,arguments))
        class GoalEnvironment(Environment):
            def __init__(self):
                self.tools=[Tool.from_function(execute_capability)]
            async def reset(self):
                return [Message(content=compact({'goal':ctx.get('goal','')}))],self.tools
            async def step(self,action):
                observations=await self.exec_tool_calls(action,concurrency=False,
                    handle_tool_exc=False,handle_invalid_tool_calls=False,exec_timeout=ctx.get('timeout',120))
                return observations,0.0,False,False
        async def run():
            env=GoalEnvironment();await env.reset()
            req=ToolRequestMessage(tool_calls=[ToolCall.from_name('execute_capability',
                capability=action['capability'],arguments=action['arguments'])])
            obs,reward,done,truncated=await env.step(req)
            return {'observations':[o.model_dump(mode='json') for o in obs],
                    'result':json.loads(obs[0].content),'reward':reward,'done':done,'truncated':truncated}
        return asyncio.run(run())
    raise ValueError('unsupported LDP/Aviary operation')
