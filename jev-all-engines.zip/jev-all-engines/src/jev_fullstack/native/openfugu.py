"""Invoke OpenFugu's real ConductorExecutor and checkpoint-backed FuguRouter."""
from __future__ import annotations
import dataclasses
import math
from .common import Bridge,model_directory


def execute(engine,operation,payload,ctx):
    if operation=='route':
        from openfugu.mini import FuguRouter
        from pathlib import Path
        import hashlib
        model=model_directory(ctx,'openfugu_backbone')
        vector=ctx.get('models',{}).get('openfugu_vector',{})
        path=Path(vector.get('path',''))
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=vector.get('sha256'):
            from .common import NativeBlocked
            raise NativeBlocked('OpenFugu routing vector missing or hash mismatch')
        mask=payload['mask']
        if len(mask)!=7 or not any(mask) or any(type(x)!=bool for x in mask):
            raise ValueError('the released FuguRouter needs seven slots and a nonempty boolean mask')
        router=FuguRouter(model,str(path),device=ctx.get('device','cpu'))
        result=router.route(payload['messages'],agent_mask=mask,sample=False)
        for key in ('agent_logits','role_logits'):
            result[key]=[float(v) if math.isfinite(float(v)) else None for v in result[key]]
        if not mask[result['agent_id']]:raise ValueError('router selected a masked slot')
        return result
    if operation=='compose':
        from openfugu.ultra import ConductorExecutor,conductor_prompt,parse_workflow,visible_indices
        bridge=Bridge(ctx);slots=payload['slots']
        if not 1<=len(slots)<=32:raise ValueError('invalid worker pool')
        allowed=set(ctx.get('allowed_capabilities',[]))
        for slot in slots:
            if slot['capability'] not in allowed:raise PermissionError('worker slot is not authorized')
        labels=[s.get('description',s['capability']) for s in slots]
        text=bridge.text(conductor_prompt(payload['goal'],labels),max_tokens=2048)
        mids,subtasks,access=parse_workflow(text)
        # Upstream truncates oversized plans and applies modulo to model IDs. Reject
        # them before any execution rather than silently changing the generated plan.
        if not (len(mids)==len(subtasks)==len(access)) or not 1<=len(mids)<=5:
            raise ValueError('Conductor emitted an invalid or oversized DAG')
        for i,mid in enumerate(mids):
            if type(mid)!=int or not 0<=mid<len(slots):raise ValueError('invalid worker index')
            if not isinstance(subtasks[i],str) or not subtasks[i].strip():raise ValueError('empty or invalid subtask')
            view=access[i]
            if isinstance(view,str) and view.strip().lower()=='all':pass
            elif not isinstance(view,list) or any(type(x)!=int or not 0<=x<i for x in view):
                raise ValueError('access list must contain only earlier nonnegative integer indices')
            visible_indices(access,i)
        def worker(subtask,messages,agent_id):
            slot=slots[agent_id]
            result=bridge.post('/internal/subtask',{'capability':slot['capability'],
                'goal':subtask,'context':messages})
            from .common import compact
            return compact(result)
        result=ConductorExecutor(worker,slot_labels=labels,max_steps=5).execute(mids,subtasks,access)
        return dataclasses.asdict(result)
    raise ValueError('unsupported OpenFugu operation')
