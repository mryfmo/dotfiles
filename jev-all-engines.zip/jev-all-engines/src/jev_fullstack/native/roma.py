"""ROMA's RecursiveSolver, with all LLM traffic sent through the common gateway."""
from __future__ import annotations
import asyncio
import dataclasses
from .common import NativeBlocked


def execute(engine,operation,payload,ctx):
    if operation!='solve':raise ValueError('unsupported ROMA operation')
    from roma_dspy.config import load_config
    from roma_dspy.config.schemas.base import LLMConfig
    from roma_dspy.config.schemas.agents import AgentConfig
    from roma_dspy.core.engine.solve import RecursiveSolver
    config=load_config(profile='general')
    visited=set()
    def patch(value):
        if id(value) in visited:return
        visited.add(id(value))
        if isinstance(value,LLMConfig):
            value.model='openai/'+ctx.get('llm_model','controller')
            value.base_url=ctx['gateway_url'].rstrip('/')+'/v1'
            value.api_key=ctx['gateway_token'];value.cache=False;value.num_retries=0
            value.timeout=int(ctx.get('timeout',120));value.max_tokens=2048
        if isinstance(value,AgentConfig):
            # Side-effectful toolkits are not inherited from an unrelated upstream
            # demo profile. ROMA solves/decomposes; the supervisor executes tools.
            value.toolkits=[]
        if dataclasses.is_dataclass(value):
            for f in dataclasses.fields(value):patch(getattr(value,f.name))
        elif isinstance(value,dict):
            for x in value.values():patch(x)
        elif isinstance(value,(list,tuple)):
            for x in value:patch(x)
    patch(config)
    if hasattr(config,'runtime') and hasattr(config.runtime,'cache'):
        config.runtime.cache.enabled=False
    if hasattr(config,'storage'):
        for n in ('postgres','s3'):
            target=getattr(config.storage,n,None)
            if target is not None and hasattr(target,'enabled'):target.enabled=False
    if hasattr(config,'observability'):
        for n in ('mlflow',):
            target=getattr(config.observability,n,None)
            if target is not None and hasattr(target,'enabled'):target.enabled=False
    solver=RecursiveSolver(config=config,max_depth=int(ctx.get('max_depth',2)),
                           enable_checkpoints=False,enable_logging=False)
    result=asyncio.run(solver.async_solve(payload['goal']))
    status=getattr(result.status,'value',str(result.status))
    if str(status).lower() not in ('completed','complete'):
        raise RuntimeError('ROMA did not complete: '+str(status))
    nodes=[]
    if solver.last_dag:
        for n in solver.last_dag.get_all_tasks(include_subgraphs=True):
            nodes.append({'task_id':str(n.task_id),'goal':n.goal,'result':n.result,
                'status':getattr(n.status,'value',str(n.status)),'depth':n.depth})
    return {'result':result.result,'status':status,'nodes':nodes,
            'input_tokens':solver.get_total_input_tokens(),'output_tokens':solver.get_total_output_tokens()}
