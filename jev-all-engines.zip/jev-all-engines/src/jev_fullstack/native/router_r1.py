"""Run the published Router-R1 vLLM inference program, not a replacement router."""
from __future__ import annotations
import contextlib
import io
from pathlib import Path
import runpy
import sys
from .common import model_directory,NativeBlocked


def execute(engine,operation,payload,ctx):
    if operation!='solve':raise ValueError('unsupported Router-R1 operation')
    model=model_directory(ctx,'router_r1')
    import torch
    import vllm  # real vLLM dependency; never mocked in the product runtime
    if not torch.cuda.is_available():
        raise NativeBlocked('the pinned Router-R1 infer_vllm.py requires CUDA')
    source=Path(ctx['upstream_root'])/'infer_vllm.py'
    if not source.is_file():raise NativeBlocked('published Router-R1 inference program is absent')
    before=list(sys.argv)
    sys.argv=[str(source),'--question',payload['goal'],'--model_path',model,
              '--api_base',ctx['gateway_url'].rstrip('/')+'/v1','--api_key',ctx['gateway_token']]
    try:
        # Upstream reasoning/routing loop, stop conditions, parsing and pool calls
        # execute unchanged. The host gateway maps allowed pool model IDs to workers.
        values=runpy.run_path(str(source),run_name='__main__')
    finally:
        sys.argv=before
    output=values.get('all_output')
    if not isinstance(output,str) or not output:raise RuntimeError('Router-R1 did not produce a trajectory')
    return {'output':output,'rounds':values.get('cnt'),'model_path':model,
            'published_inference_program':str(source)}
