"""Native Trace graph propagation and OptoPrime update over whole-system policies."""
from __future__ import annotations
import json
from types import SimpleNamespace
from .common import Bridge,compact


def execute(engine,operation,payload,ctx):
    if operation!='optimize':raise ValueError('unsupported Trace operation')
    if ctx.get('phase')!='improve':raise PermissionError('optimization outside improvement context')
    from opto.trace import node,bundle
    from opto.optimizers import OptoPrime
    bridge=Bridge(ctx)
    class GatewayModel:
        def __call__(self,messages,**kwargs):
            result=bridge.chat(messages,**kwargs)
            return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(
                content=result['choices'][0]['message']['content']))])
    parameter=node(compact(payload['candidate']),name='policy',trainable=True,
        constraint='A JSON object with exactly the original policy keys and string values. Do not modify permissions, budget or evaluator.')
    evaluations=[]
    @bundle()
    def evaluate_policy(serialized):
        candidate=json.loads(serialized)
        if set(candidate)!=set(payload['candidate']) or any(not isinstance(v,str) for v in candidate.values()):
            raise ValueError('invalid policy mutation')
        result=bridge.evaluate(payload['dataset_id'],candidate)
        evaluations.append(result)
        return float(result['score'])
    measured=evaluate_policy(parameter)
    optimizer=OptoPrime([parameter],llm=GatewayModel(),ignore_extraction_error=False,log=True)
    optimizer.zero_feedback()
    optimizer.backward(measured,compact({'objective':'Preserve whole-system correctness first, then reduce measured execution units under fixed constraints. Units are not currency.',
                                        'evaluation':evaluations[-1]}))
    optimizer.step()
    candidate=json.loads(parameter.data)
    if set(candidate)!=set(payload['candidate']):raise ValueError('optimizer changed protected policy structure')
    after=bridge.evaluate(payload['dataset_id'],candidate)
    return {'candidate':candidate,'before':evaluations[0],'after':after,
            'optimizer':'opto.optimizers.OptoPrime','status':'candidate_not_promoted'}
