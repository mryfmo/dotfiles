"""Expose a mounted host Unix-domain gateway to SDKs inside network-none OCI."""
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import threading
from .common import UnixHTTPConnection

class Proxy:
    def __init__(self,socket_path):
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*a):pass
            def do_POST(self):
                n=int(self.headers.get('Content-Length','0'))
                if not 0<n<=1000000:self.send_error(413);return
                conn=UnixHTTPConnection(socket_path)
                try:
                    conn.request('POST',self.path,self.rfile.read(n),{'Content-Type':'application/json','Authorization':self.headers.get('Authorization','')})
                    r=conn.getresponse();b=r.read(2000001)
                    if len(b)>2000000:raise ValueError('gateway response limit')
                    self.send_response(r.status);self.send_header('Content-Type','application/json');self.send_header('Content-Length',str(len(b)));self.end_headers();self.wfile.write(b)
                finally:conn.close()
        self.server=ThreadingHTTPServer(('127.0.0.1',0),Handler)
        self.url=f'http://127.0.0.1:{self.server.server_port}'
        threading.Thread(target=self.server.serve_forever,daemon=True).start()
    def close(self):self.server.shutdown();self.server.server_close()
