"""One invocation of a real, explicitly selected upstream implementation.

Stdout contains one response. Native logging goes to stderr. No dependency stub,
mock module injection, or algorithm substitution is performed here.
"""
from __future__ import annotations
import contextlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import traceback
from .common import NativeBlocked,compact,workspace

MODULES={'ldp':'ldp_aviary','aviary':'ldp_aviary','openfugu':'openfugu','router_r1':'router_r1','roma':'roma','autoskill':'autoskill','aflow':'aflow','trace':'trace','xgrammar':'xgrammar','gepa':'gepa','gliner2':'gliner2'}

def main():
    request={};out=None
    try:
        raw=sys.stdin.buffer.read(2_000_001)
        if len(raw)>2_000_000:raise ValueError('worker request limit')
        request=json.loads(raw);engine=request['engine'];ctx=request['context'];workspace(ctx)
        if engine not in MODULES:raise ValueError('unregistered engine')
        identity=ctx.get('source_identity',{})
        if identity.get('distribution'):
            distribution=importlib.metadata.distribution(identity['distribution'])
            if distribution.version != identity.get('version'):
                raise NativeBlocked('installed upstream version differs from pinned identity')
        if identity.get('wheel'):
            import zipfile,hashlib
            with zipfile.ZipFile(identity['wheel']) as wheel:
                count=0
                for name in wheel.namelist():
                    if name.endswith('/') or '.dist-info/' in name:continue
                    file=distribution.locate_file(name)
                    if not file.is_file() or hashlib.sha256(file.read_bytes()).digest()!=hashlib.sha256(wheel.read(name)).digest():
                        raise NativeBlocked('installed upstream code differs from original wheel: '+name)
                    count+=1
                identity['verified_files']=count
        module=importlib.import_module('.'+MODULES[engine],__package__)
        with contextlib.redirect_stdout(sys.stderr):
            value=module.execute(engine,request['operation'],request['payload'],ctx)
        provenance={'kind':'upstream_native_call','entrypoint':module.__name__+'.execute','source_identity':ctx.get('source_identity',{})}
        out={'request_id':request['request_id'],'engine':engine,'status':'ok','value':value,'provenance':provenance,'units':ctx.get('units',1),'events':[]}
    except Exception as e:
        traceback.print_exc(file=sys.stderr)
        out={'request_id':request.get('request_id','unknown'),'engine':request.get('engine','unknown'),
             'status':'blocked' if isinstance(e,(ModuleNotFoundError,NativeBlocked,FileNotFoundError)) else 'error',
             'value':None,'error_code':type(e).__name__,'error':str(e)[:1200],
             'provenance':{'kind':'failed_native_invocation'},'units':0,'events':[]}
    try:sys.stdout.write(compact(out)+'\n');sys.stdout.flush()
    except Exception:
        sys.stdout.write(compact({'request_id':request.get('request_id','unknown'),'engine':request.get('engine','unknown'),'status':'error','error_code':'NonSerializableNativeResult'})+'\n')
    return 0 if out['status']=='ok' else 2

if __name__=='__main__':raise SystemExit(main())
