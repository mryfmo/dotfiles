"""Native XGrammar compilation, token masks, and constrained model generation."""
from __future__ import annotations
import json
from .common import model_directory


def execute(engine,operation,payload,ctx):
    import xgrammar as xgr
    import torch
    schema=payload['schema']
    if operation=='validate':
        # Byte vocabulary exercises the actual C++ compiler, matcher and CPU mask
        # kernel without presenting it as a pretrained language model.
        vocab=[bytes([i]) for i in range(256)]+[b'<eos>']
        info=xgr.TokenizerInfo(vocab,vocab_type=xgr.VocabType.RAW,vocab_size=257,stop_token_ids=[256])
        compiler=xgr.GrammarCompiler(info,max_threads=1)
        grammar=compiler.compile_json_schema(schema,any_order=True)
        matcher=xgr.GrammarMatcher(grammar)
        accepted=matcher.accept_string(payload['text'])
        mask=xgr.allocate_token_bitmask(1,257)
        matcher.fill_next_token_bitmask(mask)
        logits=torch.zeros((1,257),dtype=torch.float32)
        xgr.apply_token_bitmask_inplace(logits,mask,vocab_size=257,backend='cpu')
        eos_allowed=bool(torch.isfinite(logits[0,256]).item())
        terminated=False
        if accepted and eos_allowed:
            terminated=bool(matcher.accept_token(256) and matcher.is_terminated())
        return {'valid':bool(accepted and terminated),'eos_allowed':eos_allowed,
                'native_mask_shape':list(mask.shape),'scope':'native_compiler_matcher_and_mask_not_semantic_quality'}
    if operation=='generate':
        from transformers import AutoModelForCausalLM,AutoTokenizer
        from xgrammar.contrib.hf import LogitsProcessor
        model_path=model_directory(ctx,'structured_llm')
        tok=AutoTokenizer.from_pretrained(model_path,local_files_only=True,trust_remote_code=False,
                                         use_fast=bool(ctx.get('use_fast_tokenizer',True)))
        model=AutoModelForCausalLM.from_pretrained(model_path,local_files_only=True,trust_remote_code=False)
        model=model.to(ctx.get('device','cpu')).eval()
        info=xgr.TokenizerInfo.from_huggingface(tok,vocab_size=model.config.vocab_size)
        compiler=xgr.GrammarCompiler(info,max_threads=1)
        grammar=compiler.compile_json_schema(schema,any_order=True)
        processor=LogitsProcessor(grammar)
        inputs=tok(payload['prompt'],return_tensors='pt').to(model.device)
        with torch.no_grad():
            output=model.generate(**inputs,max_new_tokens=payload.get('max_new_tokens',512),
                logits_processor=[processor],do_sample=False,pad_token_id=tok.eos_token_id)
        generated=tok.decode(output[0,inputs['input_ids'].shape[1]:],skip_special_tokens=True)
        value=json.loads(generated)
        return {'text':generated,'value':value,'model_path':model_path,
                'generated_tokens':int(output.shape[1]-inputs['input_ids'].shape[1])}
    raise ValueError('unsupported XGrammar operation')
