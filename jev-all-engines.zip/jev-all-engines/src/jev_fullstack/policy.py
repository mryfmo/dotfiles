"""Host-controlled authorization independent of generated text and optimizers."""
from dataclasses import dataclass
import jsonschema
from .contracts import Classification

@dataclass(frozen=True)
class Authority:
    allow_external: bool=False
    allow_effects: bool=False
    max_actions: int=500
    max_units: int=100000
    max_depth: int=3
    sandbox_enforced: bool=False


def authorize(cap,action,request,authority,phase,depth):
    if phase not in ('execute','improve'):
        raise PermissionError('unknown execution phase')
    if cap.phase not in (phase,'both'):
        raise PermissionError('capability is not permitted in this phase')
    if depth>min(request.constraints.max_depth,authority.max_depth):
        raise PermissionError('delegation limit exceeded')
    allow=request.constraints.allowed_capabilities
    if allow is not None and cap.id not in allow and cap.id not in ('ldp.decide','aviary.execute'):
        raise PermissionError('capability not authorized by request')
    if cap.external:
        if not(authority.allow_external and request.constraints.allow_external):
            raise PermissionError('external transmission not authorized')
        if any(d.classification!=Classification.public for d in request.inputs):
            raise PermissionError('only explicitly public data may leave this workspace')
    if cap.effectful and not(authority.allow_effects and request.constraints.allow_effects):
        raise PermissionError('side effect not authorized')
    if cap.requires_sandbox and not authority.sandbox_enforced:
        raise PermissionError('generated code requires an OS-enforced sandbox')
    if action is not None:
        refs={d.id for d in request.inputs}
        if set(action.input_refs)-refs:
            raise PermissionError('unknown input reference')
        jsonschema.Draft202012Validator(cap.arguments_schema,format_checker=jsonschema.FormatChecker()).validate(action.arguments)


def permitted(capabilities,request,authority,phase,depth):
    for cap in capabilities:
        try:authorize(cap,None,request,authority,phase,depth)
        except PermissionError:continue
        yield cap
