"""Capability contracts, not alternative implementations of the registered OSS."""
from .contracts import Capability

def obj(properties,required=None):
    return {'type':'object','properties':properties,'required':list(properties) if required is None else required,'additionalProperties':False}
S={'type':'string','minLength':1};O={'type':'object'};A={'type':'array'}
def cap(cid,engine,op,props,description,required=None,**kwargs):
    kwargs.setdefault('phase', 'both')
    return Capability(id=cid,engine=engine,operation=op,description=description,arguments_schema=obj(props,required),**kwargs)

_CAPS=[
 cap('ldp.decide','ldp','decide',{'messages':A,'tools':A},'LDP stochastic computation graph: next decision'),
 cap('aviary.execute','aviary','execute',{'action':O},'Aviary environment: authorized capability execution'),
 cap('openfugu.compose','openfugu','compose',{'goal':S,'slots':{'type':'array','minItems':1,'maxItems':32,'items':obj({'capability':S,'description':S},['capability'])}},'OpenFugu Conductor workflow generation and DAG execution'),
 cap('openfugu.route','openfugu','route',{'messages':A,'mask':{'type':'array','items':{'type':'boolean'},'minItems':7,'maxItems':7}},'OpenFugu checkpoint-backed worker and role routing'),
 cap('router_r1.solve','router_r1','solve',{'goal':S},'Router-R1 original multiround vLLM routing program'),
 cap('roma.solve','roma','solve',{'goal':S},'ROMA recursive planning, execution and aggregation'),
 cap('autoskill.ingest','autoskill','ingest',{'messages':A,'events':A,'hint':S},'AutoSkill formation, maintenance and versioning',required=[],phase='improve'),
 cap('autoskill.search','autoskill','search',{'query':S,'skill_snapshot':S},'AutoSkill retrieval from evaluated immutable skill snapshot'),
 cap('aflow.optimize','aflow','optimize',{'dataset_id':S,'rounds':{'type':'integer','minimum':1,'maximum':10}},'AFlow native workflow structure search',['dataset_id'],phase='improve',requires_sandbox=True),
 cap('aflow.execute','aflow','execute',{'goal':S,'workflow_snapshot':S},'Execute an approved AFlow-generated workflow',requires_sandbox=True),
 cap('trace.optimize','trace','optimize',{'candidate':O,'dataset_id':S},'Trace OptoPrime feedback propagation and program optimization',phase='improve'),
 cap('gepa.optimize','gepa','optimize',{'candidate':O,'train_id':S,'validation_id':S,'max_metric_calls':{'type':'integer','minimum':4,'maximum':10000}},'GEPA full-system reflective optimization',['candidate','train_id','validation_id'],phase='improve'),
 cap('xgrammar.validate','xgrammar','validate',{'schema':O,'text':{'type':'string'}},'XGrammar native grammar compiler, matcher and CPU token mask'),
 cap('xgrammar.generate','xgrammar','generate',{'schema':O,'prompt':S,'max_new_tokens':{'type':'integer','minimum':1,'maximum':4096}},'XGrammar constrained token generation with local model',['schema','prompt']),
 cap('gliner2.extract','gliner2','extract',{'text':S,'labels':{'oneOf':[{'type':'array','items':S,'minItems':1},O]},'threshold':{'type':'number','minimum':0,'maximum':1}},'GLiNER2 extraction with source-verified spans',['text','labels']),
 cap('llm.reason','llm','reason',{'prompt':S,'model':S},'Configured model inference through controlled gateway',['prompt'],external=True,estimated_units=8),
 cap('jev.judge','jev','judge',{'state':{},'questions':O},'Jev typed choice, score, and noul judgments',external=True,estimated_units=2),
 cap('source.read','host','read',{'input_id':S},'Read original authorized input'),
 cap('compute.table','host','compute',{'input_id':S,'operation':{'enum':['sum','mean','count','group_sum','filter','sort']},'column':S,'group_by':S,'equals':{},'descending':{'type':'boolean'}},'Deterministic tabular calculation. input_id may name an original input or the action_id of an earlier successful rows observation in this run.',['input_id','operation']),
]
CAPABILITIES={c.id:c for c in _CAPS}
