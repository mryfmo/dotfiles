"""Bounded model-service requests with no implicit replacement or fallback."""
from __future__ import annotations
import json
import os
import time
import httpx
from .contracts import canonical

class ProviderFailure(RuntimeError):
    def __init__(self,code,detail='',retryable=False):
        super().__init__(detail or code);self.code=code;self.retryable=retryable

class ModelServices:
    def __init__(self,settings):self.settings=settings;self.client=httpx.Client(trust_env=False,follow_redirects=False)
    def close(self):self.client.close()
    def _post(self,name,body,timeout,headers=None,config=None):
        cfg=config if config is not None else self.settings.get('services',{}).get(name,{})
        if not cfg.get('endpoint') or not cfg.get('model'):raise ProviderFailure('unconfigured_'+name)
        key=os.environ.get(cfg.get('api_key_env',''),'')
        if cfg.get('requires_key',True) and not key:raise ProviderFailure('credential_missing_'+name)
        wire=canonical(body)
        if len(wire)>1_000_000:raise ProviderFailure('request_too_large')
        hdr={'Content-Type':'application/json','Authorization':'Bearer '+key};hdr.update(headers or {})
        try:
            with self.client.stream('POST',cfg['endpoint'],content=wire,headers=hdr,timeout=max(.1,float(timeout))) as r:
                if r.status_code!=200:raise ProviderFailure('http_'+str(r.status_code),'provider rejected bounded request',r.status_code in (429,500,502,503,504,529))
                data=bytearray()
                for b in r.iter_bytes():
                    data.extend(b)
                    if len(data)>2_000_000:raise ProviderFailure('response_too_large')
            result=json.loads(data)
            if not isinstance(result,dict):raise ValueError('object response required')
            return result
        except (httpx.TransportError,httpx.TimeoutException) as e:raise ProviderFailure('transport','provider transport failed',True) from e
        except (ValueError,UnicodeError) as e:raise ProviderFailure('invalid_json','provider returned invalid JSON') from e
    def binding(self,requested='controller'):
        base=self.settings.get('services',{}).get('llm',{})
        if requested in ('controller',base.get('model')):
            return dict(base)
        routes=base.get('routes',{})
        if not isinstance(requested,str) or requested not in routes:
            raise ProviderFailure('unregistered_model','the selected model alias is not operator-registered')
        cfg={**base,**routes[requested]}
        cfg.pop('routes',None)
        if not cfg.get('model'):
            raise ProviderFailure('unconfigured_model')
        return cfg
    def chat(self,body,timeout=120):
        cfg=self.binding(body.get('model','controller'))
        allowed={'messages','temperature','max_tokens','response_format','tools','tool_choice','seed','top_p'}
        data={k:v for k,v in body.items() if k in allowed}
        data['model']=cfg.get('model');data['max_tokens']=min(int(data.get('max_tokens',2048)),int(cfg.get('max_output_tokens',4096)))
        protocol=cfg.get('protocol','chat_completions')
        if protocol=='anthropic':
            system='\n'.join(m['content'] for m in data.get('messages',[]) if m['role']=='system')
            data={'model':cfg.get('model'),'messages':[m for m in data.get('messages',[]) if m['role']!='system'],
                  'system':system,'max_tokens':data['max_tokens']}
            key=os.environ.get(cfg.get('api_key_env',''),'')
            raw=self._post('llm',data,timeout,{'x-api-key':key,'anthropic-version':'2023-06-01'},config=cfg)
            if raw.get('stop_reason')!='end_turn':raise ProviderFailure('truncated_or_tool_response')
            text=''.join(b['text'] for b in raw['content'] if b.get('type')=='text')
            result={'model':raw.get('model'),'choices':[{'message':{'role':'assistant','content':text},'finish_reason':'stop'}],'usage':raw.get('usage',{})}
        elif protocol=='chat_completions':result=self._post('llm',data,timeout,config=cfg)
        else:raise ProviderFailure('unsupported_protocol')
        try:
            choice=result['choices'][0]
            if choice.get('finish_reason') not in (None,'stop'):raise ValueError('completion not finished')
            if not isinstance(choice['message']['content'],str):raise ValueError('completion text missing')
            if cfg.get('require_response_model',False) and result.get('model')!=cfg.get('model'):raise ValueError('model binding changed')
        except (KeyError,IndexError,TypeError,ValueError) as e:raise ProviderFailure('llm_contract','invalid model response envelope') from e
        return result
    def jev(self,args,timeout=120):
        from jev_gepa.models import TaskSpec
        from jev_gepa.providers import decode_jev
        from jev_gepa.errors import ProviderError
        cfg=self.settings.get('services',{}).get('jev',{})
        try:
            spec=TaskSpec(id='dynamic-judgment',title='Runtime-constructed atomic judgment',model=cfg.get('model','jev-1.13.0'),questions=args['questions'])
            body={'model':spec.model,'state':args['state'],'questions':{k:q.wire() for k,q in spec.questions.items()}}
            start=time.monotonic();raw=self._post('jev',body,timeout)
            checked=decode_jev(spec,raw,(time.monotonic()-start)*1000)
            return {**raw,'validated_disposition':checked.disposition,'authorization_to_act':False}
        except ProviderError as e:raise ProviderFailure('jev_contract','Jev response contract validation failed') from e
