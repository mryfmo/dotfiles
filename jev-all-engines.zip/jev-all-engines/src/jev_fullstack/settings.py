"""Resolve deployment paths without dereferencing a virtualenv Python symlink."""
from __future__ import annotations
import copy
import json
import os
from pathlib import Path
from urllib.parse import urlsplit
from .contracts import REQUIRED_ENGINES

def _path(value,base):
    p=Path(os.path.expandvars(os.path.expanduser(str(value))))
    return str(p.absolute() if p.is_absolute() else (base/p).absolute())

def load_settings(path):
    path=Path(path).absolute();cfg=json.loads(path.read_text(encoding='utf-8'))
    base=path.parent;root=Path(_path(cfg.get('project_root','..'),base))
    cfg['project_root']=str(root);cfg['workspace']=_path(cfg.get('workspace','workspace'),root)
    if set(cfg.get('engines',{}))!=REQUIRED_ENGINES:raise ValueError('all eleven native engines are required')
    for name,e in cfg['engines'].items():
        if not e.get('revision') and not e.get('version'):raise ValueError('unpinned engine: '+name)
        e['python']=_path(e.get('python',f'native_envs/envs/{name}/bin/python'),root)
        e['source']=_path(e.get('source',f'native_envs/sources/{name}'),root)
        if e.get('execution','process') not in ('process','container'):raise ValueError('unknown isolation mode')
        if name=='aflow' and e.get('execution')!='container':raise ValueError('AFlow must use container isolation')
        e['extra_python_paths']=[_path(p,root) for p in e.get('extra_python_paths',[])]
    if set(cfg.get('services',{}))!={'llm','jev'}:raise ValueError('both Jev and LLM services are required')
    bindings=[]
    for name,s in cfg['services'].items():
        bindings.append((name,s))
        for alias,route in s.get('routes',{}).items():
            if not isinstance(alias,str) or not alias or not isinstance(route,dict):
                raise ValueError('invalid model route binding')
            bindings.append((name+':'+alias,{**s,**route}))
    for name,s in bindings:
        if 'api_key' in s:raise ValueError('use an environment-variable name, not embedded credentials')
        endpoint=s.get('endpoint','')
        if endpoint:
            u=urlsplit(endpoint)
            if u.username or u.password or u.fragment:raise ValueError('endpoint contains unsafe URL components')
            if u.scheme!='https' and not (u.scheme=='http' and u.hostname in ('127.0.0.1','localhost','::1')):
                raise ValueError('remote provider endpoints require TLS')
            if not s.get('external',True) and u.hostname not in ('127.0.0.1','localhost','::1'):
                raise ValueError('nonlocal endpoint cannot be marked internal')
    for spec in cfg.get('models',{}).values():
        if spec.get('path'):spec['path']=_path(spec['path'],root)
    cfg['datasets']={k:_path(v,root) if isinstance(v,str) else v for k,v in cfg.get('datasets',{}).items()}
    return cfg
