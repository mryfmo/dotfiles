"""Fenced, encrypted, single-host SQLite execution and release state.

The store has one commit authority. Nested calls debit every ancestor budget in
one transaction. A process crash never turns an indeterminate operation into an
unconditional retry. This module does not promise exactly-once external APIs.
"""
from __future__ import annotations
from contextlib import contextmanager
import hashlib
import hmac
import json
import os
from pathlib import Path
import secrets
import sqlite3
import time
from cryptography.fernet import Fernet
from .contracts import Bundle, GoalRequest, canonical, digest

class Conflict(RuntimeError):pass
class BudgetExceeded(RuntimeError):pass

@contextmanager
def _file_lock(path):
    """Serialize initialization across processes on POSIX or Windows."""
    path.parent.mkdir(parents=True,exist_ok=True)
    f=path.open('a+b')
    try:
        if os.name=='nt':
            import msvcrt
            if f.tell()==0:f.write(b'0');f.flush()
            f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_LOCK,1)
        else:
            import fcntl
            fcntl.flock(f,fcntl.LOCK_EX)
        yield
    finally:
        if os.name=='nt':
            import msvcrt
            f.seek(0);msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
        else:
            import fcntl
            fcntl.flock(f,fcntl.LOCK_UN)
        f.close()


class Store:
    def __init__(self,root):
        self.root=Path(root).absolute();self.root.mkdir(parents=True,exist_ok=True)
        if os.name!='nt':self.root.chmod(0o700)
        self.path=self.root/'state.sqlite3'
        with _file_lock(self.root/'.initialize.lock'):
            kp=self.root/'master.key'
            if not kp.exists():
                fd=os.open(kp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
                with os.fdopen(fd,'wb') as f:f.write(Fernet.generate_key());f.flush();os.fsync(f.fileno())
            self.key=kp.read_bytes();self.cipher=Fernet(self.key)
            with self._read() as c:
                c.execute('PRAGMA journal_mode=WAL')
                c.executescript('''
                CREATE TABLE IF NOT EXISTS bundles(id TEXT PRIMARY KEY,data BLOB NOT NULL,revoked INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS active(singleton INTEGER PRIMARY KEY CHECK(singleton=1),bundle_id TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS runs(id TEXT PRIMARY KEY,parent_id TEXT,state BLOB NOT NULL,bundle_hash TEXT NOT NULL,
                  status TEXT NOT NULL,owner TEXT,fence INTEGER NOT NULL DEFAULT 0,lease_until REAL NOT NULL DEFAULT 0,
                  revision INTEGER NOT NULL DEFAULT 0,deadline REAL NOT NULL,max_calls INTEGER NOT NULL,max_units INTEGER NOT NULL,
                  calls INTEGER NOT NULL DEFAULT 0,units INTEGER NOT NULL DEFAULT 0,classification TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS operations(id TEXT PRIMARY KEY,run_id TEXT NOT NULL,status TEXT NOT NULL,
                  request BLOB NOT NULL,response BLOB,reserved INTEGER NOT NULL,FOREIGN KEY(run_id) REFERENCES runs(id));
                CREATE TABLE IF NOT EXISTS events(run_id TEXT NOT NULL,seq INTEGER NOT NULL,type TEXT NOT NULL,
                  data BLOB NOT NULL,chain TEXT NOT NULL,PRIMARY KEY(run_id,seq));
                CREATE TABLE IF NOT EXISTS lineage(run_id TEXT NOT NULL,fingerprint TEXT NOT NULL,PRIMARY KEY(run_id,fingerprint));
                CREATE TABLE IF NOT EXISTS revoked_inputs(fingerprint TEXT PRIMARY KEY);
                CREATE TABLE IF NOT EXISTS evaluations(id TEXT PRIMARY KEY,bundle_id TEXT NOT NULL,baseline TEXT,data BLOB NOT NULL);
                CREATE TABLE IF NOT EXISTS attestations(bundle_id TEXT NOT NULL,evaluation_id TEXT NOT NULL,PRIMARY KEY(bundle_id,evaluation_id));
                CREATE TABLE IF NOT EXISTS dataset_inputs(fingerprint TEXT PRIMARY KEY,split TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS used_tests(fingerprint TEXT PRIMARY KEY,evaluation_id TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS native_attestations(bundle_id TEXT PRIMARY KEY,data BLOB NOT NULL);
                ''')

    @contextmanager
    def _read(self):
        c = self._connect()
        try:
            yield c
        finally:
            c.close()

    def _connect(self):
        c=sqlite3.connect(self.path,timeout=30,isolation_level=None)
        c.row_factory=sqlite3.Row;c.execute('PRAGMA busy_timeout=30000');c.execute('PRAGMA foreign_keys=ON')
        return c

    @contextmanager
    def _tx(self):
        c=self._connect()
        try:
            c.execute('BEGIN IMMEDIATE');yield c;c.commit()
        except BaseException:c.rollback();raise
        finally:c.close()

    def _pack(self,v):return self.cipher.encrypt(canonical(v))
    def _unpack(self,v):return json.loads(self.cipher.decrypt(bytes(v)))

    def _event(self,c,rid,kind,data):
        r=c.execute('SELECT seq,chain FROM events WHERE run_id=? ORDER BY seq DESC LIMIT 1',(rid,)).fetchone()
        seq=(r['seq']+1) if r else 1;prev=r['chain'] if r else ''
        message=canonical({'run_id':rid,'seq':seq,'type':kind,'data':data,'previous':prev})
        chain=hmac.new(self.key,message,hashlib.sha256).hexdigest()
        c.execute('INSERT INTO events VALUES(?,?,?,?,?)',(rid,seq,kind,self._pack(data),chain))

    def add_bundle(self,bundle):
        bundle=Bundle.model_validate(bundle)
        with self._tx() as c:c.execute('INSERT OR IGNORE INTO bundles(id,data) VALUES(?,?)',(bundle.sha256,self._pack(bundle)))
        return bundle.sha256

    def bundle(self,bid=None):
        bid=bid or self.active()
        if bid is None:raise ValueError('no approved active bundle; seed/evaluate/promote before serving requests')
        with self._read() as c:r=c.execute('SELECT data FROM bundles WHERE id=?',(bid,)).fetchone()
        if r is None:raise KeyError('bundle not found')
        b=Bundle.model_validate(self._unpack(r['data']))
        if b.sha256!=bid:raise ValueError('bundle integrity failure')
        return b

    def active(self):
        with self._read() as c:r=c.execute('SELECT bundle_id FROM active WHERE singleton=1').fetchone()
        return r[0] if r else None

    def is_revoked(self,bid):
        with self._read() as c:r=c.execute('SELECT revoked FROM bundles WHERE id=?',(bid,)).fetchone()
        return bool(r and r['revoked'])

    def create(self,request,bundle,parent_id=None,queued=False,context_classification='public'):
        request=GoalRequest.model_validate(request);bid=self.add_bundle(bundle);rid=secrets.token_hex(16)
        rank={'public':0,'internal':1,'restricted':2}
        label=max([context_classification]+[d.classification.value for d in request.inputs],key=rank.__getitem__)
        state={'request':request.model_dump(mode='json'),'bundle':bundle.model_dump(mode='json'),
               'bundle_sha256':bid,'contract':None,'observations':[],'output':None}
        with self._tx() as c:
            deadline=time.time()+request.constraints.deadline_seconds
            if parent_id:
                p=c.execute('SELECT * FROM runs WHERE id=?',(parent_id,)).fetchone()
                if p is None or p['status']!='running':raise Conflict('parent is not running')
                deadline=min(deadline,p['deadline']);label=max(label,p['classification'],key=rank.__getitem__)
            for doc in request.inputs:
                if c.execute('SELECT 1 FROM revoked_inputs WHERE fingerprint=?',(digest(doc.content),)).fetchone():
                    raise PermissionError('source was revoked')
            c.execute('INSERT INTO runs(id,parent_id,state,bundle_hash,status,deadline,max_calls,max_units,classification) VALUES(?,?,?,?,?,?,?,?,?)',
                      (rid,parent_id,self._pack(state),bid,'queued' if queued else 'ready',deadline,request.constraints.max_actions,request.constraints.max_units,label))
            for doc in request.inputs:c.execute('INSERT OR IGNORE INTO lineage VALUES(?,?)',(rid,digest(doc.content)))
            if parent_id:
                c.execute('INSERT OR IGNORE INTO lineage SELECT ?,fingerprint FROM lineage WHERE run_id=?',(rid,parent_id))
            self._event(c,rid,'created',{'bundle_hash':bid,'request_hash':digest(request)})
        return rid

    def get(self,rid):
        with self._read() as c:r=c.execute('SELECT * FROM runs WHERE id=?',(rid,)).fetchone()
        if r is None:raise KeyError('run not found')
        out=dict(r);out['state']=self._unpack(out['state']);return out

    def _owned(self,c,rid,owner,fence):
        r=c.execute('SELECT * FROM runs WHERE id=?',(rid,)).fetchone()
        if r is None or r['status']!='running' or r['owner']!=owner or r['fence']!=fence or r['lease_until']<time.time():
            raise Conflict('stale execution lease')
        return r

    def claim(self,rid,owner,lease_seconds=60):
        with self._tx() as c:
            r=c.execute('SELECT * FROM runs WHERE id=?',(rid,)).fetchone()
            if r is None:raise KeyError('run not found')
            if r['status'] not in ('ready','queued','running'):raise Conflict('run is not claimable')
            if r['status']=='running' and r['lease_until']>time.time():raise Conflict('another worker owns the run')
            if r['deadline']<=time.time():raise BudgetExceeded('deadline expired')
            fence=r['fence']+1
            c.execute('UPDATE runs SET owner=?,fence=?,lease_until=?,status=? WHERE id=?',(owner,fence,time.time()+lease_seconds,'running',rid))
            self._event(c,rid,'claimed',{'owner':owner,'fence':fence})
            return fence

    def renew(self,rid,owner,fence,lease_seconds=60):
        with self._tx() as c:
            self._owned(c,rid,owner,fence)
            c.execute('UPDATE runs SET lease_until=? WHERE id=?',(time.time()+lease_seconds,rid))

    def execution_current(self,rid,owner,fence):
        try:
            with self._read() as c:self._owned(c,rid,owner,fence)
            return self.get(rid)['deadline']>time.time()
        except (Conflict,KeyError):return False

    def save(self,rid,owner,fence,revision,state,status='running'):
        if status not in ('running','succeeded','failed','cancelled','unresolved'):raise ValueError('invalid run status')
        with self._tx() as c:
            row=self._owned(c,rid,owner,fence)
            if row['revision']!=revision:raise Conflict('state revision conflict')
            before=self._unpack(row['state'])
            for field in ('request','bundle','bundle_sha256'):
                if canonical(before[field])!=canonical(state[field]):raise ValueError('immutable execution binding changed')
            c.execute('UPDATE runs SET state=?,revision=revision+1,status=? WHERE id=?',(self._pack(state),status,rid))
            self._event(c,rid,'state_saved',{'revision':revision+1,'state_hash':digest(state),'status':status})
            return revision+1

    def reserve(self,rid,owner,fence,request,units):
        if type(units)!=int or units<1:raise ValueError('positive integral quota required')
        oid=secrets.token_hex(16)
        with self._tx() as c:
            row=self._owned(c,rid,owner,fence);ancestors=[];seen=set()
            while row:
                if row['id'] in seen:raise Conflict('run hierarchy cycle')
                seen.add(row['id']);ancestors.append(row['id'])
                if row['status']!='running' or row['deadline']<=time.time():raise BudgetExceeded('ancestor inactive or expired')
                if row['calls']+1>row['max_calls'] or row['units']+units>row['max_units']:raise BudgetExceeded('shared root or local quota exhausted')
                row=c.execute('SELECT * FROM runs WHERE id=?',(row['parent_id'],)).fetchone() if row['parent_id'] else None
            for aid in ancestors:c.execute('UPDATE runs SET calls=calls+1,units=units+? WHERE id=?',(units,aid))
            c.execute('INSERT INTO operations(id,run_id,status,request,reserved) VALUES(?,?,?,?,?)',(oid,rid,'pending',self._pack(request),units))
            self._event(c,rid,'operation_reserved',{'id':oid,'request_hash':digest(request),'units':units})
        return oid

    def complete_operation(self,oid,rid,owner,fence,response):
        with self._tx() as c:
            self._owned(c,rid,owner,fence)
            result=c.execute('UPDATE operations SET status=?,response=? WHERE id=? AND run_id=? AND status=?',('complete',self._pack(response),oid,rid,'pending'))
            if result.rowcount!=1:raise Conflict('operation is absent or already complete')
            self._event(c,rid,'operation_completed',{'id':oid,'response_hash':digest(response)})

    def abort_pending(self,rid,owner,fence):
        with self._tx() as c:
            self._owned(c,rid,owner,fence)
            rows=c.execute('SELECT id FROM operations WHERE run_id=? AND status=?',(rid,'pending')).fetchall()
            for r in rows:
                c.execute('UPDATE operations SET status=?,response=? WHERE id=?',('outcome_unknown',self._pack({'status':'outcome_unknown','automatic_retry':False}),r['id']))
                self._event(c,rid,'operation_outcome_unknown',{'id':r['id']})
            return len(rows)

    def cancel(self,rid):
        with self._tx() as c:
            if not c.execute('SELECT 1 FROM runs WHERE id=?',(rid,)).fetchone():
                raise KeyError('run not found')
            todo=[rid]
            while todo:
                current=todo.pop();todo.extend(r[0] for r in c.execute('SELECT id FROM runs WHERE parent_id=?',(current,)))
                c.execute("UPDATE runs SET status='cancelled',fence=fence+1 WHERE id=? AND status IN ('ready','queued','running')",(current,))
                self._event(c,current,'cancelled',{})

    def operations(self,rid):
        with self._read() as c:rows=c.execute('SELECT * FROM operations WHERE run_id=? ORDER BY rowid',(rid,)).fetchall()
        return [{'id':r['id'],'request':self._unpack(r['request']),'response':self._unpack(r['response']) if r['response'] else None,'status':r['status'],'reserved':r['reserved']} for r in rows]

    def events(self,rid):
        with self._read() as c:rows=c.execute('SELECT * FROM events WHERE run_id=? ORDER BY seq',(rid,)).fetchall()
        out=[];prev=''
        for i,r in enumerate(rows,1):
            data=self._unpack(r['data'])
            expected=hmac.new(self.key,canonical({'run_id':rid,'seq':i,'type':r['type'],'data':data,'previous':prev}),hashlib.sha256).hexdigest()
            if r['seq']!=i or not hmac.compare_digest(expected,r['chain']):raise ValueError('event-chain integrity failure')
            out.append({'seq':i,'type':r['type'],'data':data,'chain':r['chain']});prev=r['chain']
        return out

    def record_lineage(self,rid,fingerprints,classification='public'):
        rank={'public':0,'internal':1,'restricted':2}
        with self._tx() as c:
            current=rid
            while current:
                row=c.execute('SELECT * FROM runs WHERE id=?',(current,)).fetchone()
                if row is None:raise KeyError('lineage run absent')
                for fp in fingerprints:
                    if c.execute('SELECT 1 FROM revoked_inputs WHERE fingerprint=?',(fp,)).fetchone():raise PermissionError('revoked source in evaluation')
                    c.execute('INSERT OR IGNORE INTO lineage VALUES(?,?)',(current,fp))
                new=max(row['classification'],classification,key=rank.__getitem__)
                c.execute('UPDATE runs SET classification=? WHERE id=?',(new,current));current=row['parent_id']

    def lineage(self,rid):
        with self._read() as c:return [r[0] for r in c.execute('SELECT fingerprint FROM lineage WHERE run_id=? ORDER BY fingerprint',(rid,))]
    def context_classification(self,rid):return self.get(rid)['classification']

    def invalidate_lineage(self,fingerprint,artifact_ids=()):
        with self._tx() as c:
            c.execute('INSERT OR IGNORE INTO revoked_inputs VALUES(?)',(fingerprint,))
            rids=[r[0] for r in c.execute('SELECT run_id FROM lineage WHERE fingerprint=?',(fingerprint,))]
            bids=[]
            for row in c.execute('SELECT id,data FROM bundles').fetchall():
                b=Bundle.model_validate(self._unpack(row['data']))
                if set(b.dataset_lineage)&set(rids) or set(b.artifacts.values())&set(artifact_ids):
                    bids.append(row['id']);c.execute('UPDATE bundles SET revoked=1 WHERE id=?',(row['id'],))
            for rid in rids:
                c.execute("UPDATE runs SET status='cancelled',fence=fence+1 WHERE id=? AND status IN ('running','queued','ready')",(rid,))
            return {'affected_runs':rids,'revoked_bundles':bids,'physical_erasure':False}

    def register_eval_input(self,request,bundle_id,split):
        fp=digest({'goal':request.goal.strip(),'requirements':list(request.requirements),
                   'inputs':[{'content':d.content,'classification':d.classification.value} for d in request.inputs]})
        if split not in ('train','validation','test','post_promotion'):raise ValueError('unknown dataset split')
        with self._tx() as c:
            r=c.execute('SELECT split FROM dataset_inputs WHERE fingerprint=?',(fp,)).fetchone()
            if r and r['split']!=split:raise ValueError('data split leakage')
            c.execute('INSERT OR IGNORE INTO dataset_inputs VALUES(?,?)',(fp,split))
        return fp

    def consume_test(self,fingerprints,evaluation_id):
        with self._tx() as c:
            for fp in fingerprints:
                if c.execute('SELECT 1 FROM used_tests WHERE fingerprint=?',(fp,)).fetchone():raise ValueError('independent test input already used')
            c.executemany('INSERT INTO used_tests VALUES(?,?)',[(fp,evaluation_id) for fp in fingerprints])

    def record_evaluation(self,bid,baseline,report):
        eid=secrets.token_hex(16)
        with self._tx() as c:c.execute('INSERT INTO evaluations VALUES(?,?,?,?)',(eid,bid,baseline,self._pack(report)))
        return eid

    def attest(self,bid,eid):
        with self._tx() as c:
            row=c.execute('SELECT * FROM evaluations WHERE id=? AND bundle_id=?',(eid,bid)).fetchone()
            if row is None:raise ValueError('evaluation evidence not found')
            report=self._unpack(row['data'])
            if report.get('split')!='test' or report.get('passed') is not True or not report.get('run_ids'):
                raise ValueError('independent successful executions required')
            for rid in report['run_ids']:
                r=c.execute('SELECT status,bundle_hash FROM runs WHERE id=?',(rid,)).fetchone()
                if not r or r['status']!='succeeded' or r['bundle_hash']!=bid:raise ValueError('evidence not bound to candidate executions')
            c.execute('INSERT OR IGNORE INTO attestations VALUES(?,?)',(bid,eid))

    def attest_native(self,bid,results):
        """Bind native functional evidence to source/model identities and saved runs.

        Only the trusted acceptance driver calls this method. Agent callbacks cannot.
        """
        from .acceptance import REQUIRED_NATIVE_CASES,functional_checks
        target=self.bundle(bid)
        if len(results)!=len(REQUIRED_NATIVE_CASES) or {r.get('case') for r in results}!=REQUIRED_NATIVE_CASES:
            raise ValueError('all native cases, including dependent reuse cases, are required')
        with self._tx() as c:
            for result in results:
                response=result.get('response',{})
                if result.get('passed') is not True or response.get('status')!='ok':
                    raise ValueError('native functional evidence contains failure')
                kind=response.get('provenance',{}).get('kind')
                required={'provider_response'} if result['case'] in ('jev','llm') else {'upstream_native_call','upstream_native_isolated'}
                if kind not in required:raise ValueError('native acceptance cannot use contract fixture evidence')
                if not all(functional_checks(result['case'],response).values()):
                    raise ValueError('native result failed host functional checks')
                row=c.execute('SELECT state,status FROM runs WHERE id=?',(result.get('run_id'),)).fetchone()
                if row is None or row['status']!='succeeded':raise ValueError('native probe execution is not successful')
                state=self._unpack(row['state'])
                if canonical(state.get('output'))!=canonical(response):raise ValueError('probe result was not saved by the execution')
                if state['bundle']['engines']!=target.engines or canonical(state['bundle']['model_bindings'])!=canonical(target.model_bindings):
                    raise ValueError('native evidence belongs to different engine/model identities')
            c.execute('INSERT OR REPLACE INTO native_attestations VALUES(?,?)',(bid,self._pack({'results':results})))

    def promote(self,bid,expected_active):
        with self._tx() as c:
            r=c.execute('SELECT bundle_id FROM active WHERE singleton=1').fetchone()
            if (r[0] if r else None)!=expected_active:raise Conflict('active release changed')
            b=c.execute('SELECT revoked FROM bundles WHERE id=?',(bid,)).fetchone()
            if not b or b['revoked']:raise PermissionError('missing or revoked candidate')
            if not c.execute('SELECT 1 FROM attestations WHERE bundle_id=?',(bid,)).fetchone():raise PermissionError('no independent acceptance evidence')
            if not c.execute('SELECT 1 FROM native_attestations WHERE bundle_id=?',(bid,)).fetchone():raise PermissionError('all-engine native acceptance evidence is required')
            c.execute('INSERT INTO active VALUES(1,?) ON CONFLICT(singleton) DO UPDATE SET bundle_id=excluded.bundle_id',(bid,))

    def queued(self):
        with self._read() as c:return [r[0] for r in c.execute("SELECT id FROM runs WHERE status='queued' OR (status='running' AND lease_until<?) ORDER BY rowid",(time.time(),))]
