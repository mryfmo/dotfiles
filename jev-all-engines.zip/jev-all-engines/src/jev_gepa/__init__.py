"""Jev + GEPA: typed decisions, immutable versions and governed optimization."""

__version__ = "1.0.0"
