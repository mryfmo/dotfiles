"""Authenticated FastAPI control plane and decision API; heavy work stays in the worker."""

import hashlib
import hmac
import threading
import time
from collections import defaultdict, deque
from typing import Annotated, Any, Callable

from fastapi import Depends, FastAPI, Header, HTTPException, Query, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from . import __version__
from .config import Settings
from .errors import DomainError
from .models import (
    ActivateRequest, CandidateRequest, Dataset, JobRequest, PredictRequest,
    RollbackRequest, TaskSpec,
)
from .service import Service


class BodyLimitMiddleware:
    """Enforce a byte limit even for chunked requests before JSON is parsed."""

    def __init__(self, app: Any, max_bytes: int = 9 * 1024 * 1024) -> None:
        self.app, self.max_bytes = app, max_bytes

    async def __call__(self, scope: Any, receive: Any, send: Any) -> None:
        """Buffer at most the configured bound; never trust only Content-Length."""
        if scope["type"] != "http" or scope["method"] not in {"POST", "PUT", "PATCH"}:
            await self.app(scope, receive, send)
            return
        chunks = bytearray()
        while True:
            message = await receive()
            if message["type"] == "http.disconnect":
                return
            chunks.extend(message.get("body", b""))
            if len(chunks) > self.max_bytes:
                response = JSONResponse({"error": {"code": "request_too_large", "message": "Body exceeds 9 MiB."}}, 413)
                await response(scope, receive, send)
                return
            if not message.get("more_body", False):
                break
        consumed = False

        async def replay() -> dict[str, Any]:
            nonlocal consumed
            if not consumed:
                consumed = True
                return {"type": "http.request", "body": bytes(chunks), "more_body": False}
            return await receive()

        await self.app(scope, replay, send)


class RateLimiter:
    """A bounded, per-credential sliding window for this single API process."""

    def __init__(self, limit: int) -> None:
        self.limit = limit
        self.records: dict[str, deque[float]] = defaultdict(deque)
        self.lock = threading.Lock()

    def check(self, principal: str) -> None:
        """The number of authenticated principals is fixed by server configuration."""
        with self.lock:
            ts = time.monotonic()
            records = self.records[principal]
            while records and records[0] <= ts - 60:
                records.popleft()
            if len(records) >= self.limit:
                raise HTTPException(429, "Credential request limit exceeded.", headers={"Retry-After": "60"})
            records.append(ts)


def create_app(settings: Settings | None = None, service: Service | None = None) -> FastAPI:
    """Create an app with explicit dependency injection for repeatable offline contract tests."""
    settings = settings or Settings()
    service = service or Service(settings)
    app = FastAPI(
        title="Jev + GEPA Decision System", version=__version__,
        description="Typed decisions, official GEPA optimization, independent release evaluation and approval. "
                    "Accepted decisions never authorize external actions.",
    )
    app.state.service = service
    app.add_middleware(BodyLimitMiddleware)
    bearer = HTTPBearer(auto_error=False)
    limiter = RateLimiter(settings.requests_per_minute)
    secrets = {
        "runtime": settings.runtime_token.get_secret_value(),
        "editor": settings.editor_token.get_secret_value(),
        "approver": settings.approver_token.get_secret_value(),
    }

    def access(*roles: str) -> Callable[..., str]:
        def authorize(credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(bearer)]) -> str:
            if credentials is None or credentials.scheme.lower() != "bearer":
                raise HTTPException(401, "Bearer credential required.", headers={"WWW-Authenticate": "Bearer"})
            matched = None
            # Check each configured role; do not compare credentials with ordinary equality.
            for role, secret in secrets.items():
                if hmac.compare_digest(credentials.credentials.encode("utf-8"), secret.encode("utf-8")):
                    matched = role
            if matched is None:
                raise HTTPException(401, "Invalid credential.", headers={"WWW-Authenticate": "Bearer"})
            if matched not in roles:
                raise HTTPException(403, "This credential cannot perform the requested operation.")
            actor = matched + ":" + hashlib.sha256(credentials.credentials.encode()).hexdigest()[:12]
            limiter.check(actor)
            return actor
        return authorize

    reader = access("runtime", "editor", "approver")
    editor = access("editor")
    reviewer = access("approver")
    inspector = access("editor", "approver")

    @app.exception_handler(DomainError)
    async def domain_error(request: Request, exc: DomainError) -> JSONResponse:
        return JSONResponse({"error": {"code": exc.code, "message": exc.message}}, status_code=exc.status)

    @app.exception_handler(RequestValidationError)
    async def validation_error(request: Request, exc: RequestValidationError) -> JSONResponse:
        # Never echo complete body/inputs or context objects in validation responses.
        issues = [{"location": list(e["loc"]), "type": e["type"]} for e in exc.errors()]
        return JSONResponse({"error": {"code": "validation", "issues": issues}}, status_code=422)

    @app.exception_handler(ValueError)
    async def value_error(request: Request, exc: ValueError) -> JSONResponse:
        return JSONResponse({"error": {"code": "invalid_contract", "message": "Request violates an immutable contract."}}, 422)

    @app.middleware("http")
    async def response_headers(request: Request, call_next: Any) -> Any:
        response = await call_next(request)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        return response

    @app.get("/healthz", tags=["operations"])
    def health() -> dict[str, Any]:
        """Liveness only, not a claim that external models are available."""
        return {"status": "ok", "version": __version__, "backend": settings.backend,
                "external_api_verified": False}

    @app.get("/v1/tasks", tags=["tasks"])
    def tasks(actor: Annotated[str, Depends(reader)]) -> list[dict[str, Any]]:
        return service.store.tasks()

    @app.post("/v1/tasks", status_code=201, tags=["tasks"])
    def create_task(spec: TaskSpec, actor: Annotated[str, Depends(editor)]) -> dict[str, Any]:
        return service.store.create_task(spec, actor)

    @app.get("/v1/tasks/{task_id}", tags=["tasks"])
    def task(task_id: str, actor: Annotated[str, Depends(inspector)]) -> dict[str, Any]:
        spec, active = service.store.task(task_id)
        return {"spec": spec.model_dump(), "active": active}

    @app.get("/v1/tasks/{task_id}/versions", tags=["versions"])
    def versions(task_id: str, actor: Annotated[str, Depends(inspector)]) -> list[dict[str, Any]]:
        return service.store.versions(task_id)

    @app.get("/v1/tasks/{task_id}/versions/{version_id}", tags=["versions"])
    def version(task_id: str, version_id: str, actor: Annotated[str, Depends(inspector)]) -> dict[str, Any]:
        return service.store.version(task_id, version_id)

    @app.post("/v1/tasks/{task_id}/versions", status_code=201, tags=["versions"])
    def candidate(task_id: str, body: CandidateRequest, actor: Annotated[str, Depends(editor)]) -> dict[str, Any]:
        version_id = service.store.add_version(task_id, body.parent_version, body.components, actor, "manual")
        service.store.audit(actor, "candidate.reason", {"task_id": task_id, "version_id": version_id, "reason": body.reason})
        return {"task_id": task_id, "version_id": version_id, "active_changed": False}

    @app.post("/v1/datasets", status_code=201, tags=["datasets"])
    def dataset(body: Dataset, actor: Annotated[str, Depends(editor)]) -> dict[str, Any]:
        return service.store.add_dataset(body, actor)

    @app.get("/v1/tasks/{task_id}/datasets", tags=["datasets"])
    def datasets(task_id: str, actor: Annotated[str, Depends(inspector)]) -> list[dict[str, Any]]:
        return service.store.datasets(task_id)

    @app.post("/v1/tasks/{task_id}/jobs", status_code=202, tags=["jobs"])
    def enqueue(
        task_id: str, body: JobRequest, actor: Annotated[str, Depends(editor)],
        idempotency_key: Annotated[str, Header(alias="Idempotency-Key", pattern=r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$")],
    ) -> dict[str, Any]:
        return service.enqueue(task_id, body, idempotency_key, actor)

    @app.get("/v1/jobs", tags=["jobs"])
    def jobs(actor: Annotated[str, Depends(inspector)], limit: Annotated[int, Query(ge=1, le=100)] = 100) -> list[dict[str, Any]]:
        return service.store.jobs(limit)

    @app.get("/v1/jobs/{job_id}", tags=["jobs"])
    def job(job_id: str, actor: Annotated[str, Depends(inspector)]) -> dict[str, Any]:
        return service.store.job(job_id)

    @app.post("/v1/jobs/{job_id}/cancel", tags=["jobs"])
    def cancel(job_id: str, actor: Annotated[str, Depends(editor)]) -> dict[str, Any]:
        return service.store.cancel(job_id, actor)

    @app.get("/v1/tasks/{task_id}/evaluations/{evaluation_id}", tags=["evaluations"])
    def evaluation(task_id: str, evaluation_id: str, actor: Annotated[str, Depends(inspector)]) -> dict[str, Any]:
        return service.store.evaluation(task_id, evaluation_id)

    @app.post("/v1/tasks/{task_id}/activate", tags=["release"])
    def activate(task_id: str, body: ActivateRequest, actor: Annotated[str, Depends(reviewer)]) -> dict[str, Any]:
        spec, _ = service.store.task(task_id)
        return service.store.activate(task_id, body.version_id, body.evaluation_id, body.expected_active,
                                      actor, body.reason, settings.provider_fingerprint(spec.model))

    @app.post("/v1/tasks/{task_id}/rollback", tags=["release"])
    def rollback(task_id: str, body: RollbackRequest, actor: Annotated[str, Depends(reviewer)]) -> dict[str, Any]:
        spec, _ = service.store.task(task_id)
        return service.store.rollback(task_id, body.version_id, body.expected_active, actor,
                                      body.reason, settings.provider_fingerprint(spec.model))

    @app.post("/v1/tasks/{task_id}/predict", tags=["inference"])
    def predict(task_id: str, body: PredictRequest, actor: Annotated[str, Depends(reader)]) -> dict[str, Any]:
        return service.predict(task_id, body.state, actor)

    @app.get("/v1/audit/verify", tags=["audit"])
    def audit_verify(actor: Annotated[str, Depends(reviewer)]) -> dict[str, Any]:
        return service.store.verify_audit()

    @app.get("/v1/audit", tags=["audit"])
    def audit(actor: Annotated[str, Depends(reviewer)], limit: Annotated[int, Query(ge=1, le=100)] = 100) -> list[dict[str, Any]]:
        return service.store.audit_events(limit)

    return app
