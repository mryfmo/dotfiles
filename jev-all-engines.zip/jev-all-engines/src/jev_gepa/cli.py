"""Cross-platform uv-friendly CLI: no shell interpolation and no dependency on MCP."""

from __future__ import annotations

import argparse
import json
import os
import secrets
import sys
import tempfile
import time
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any

import httpx

from .client import Client
from .config import ClientSettings, Settings
from .errors import DomainError
from .store import new_id


def read_json(path: str) -> Any:
    """Read bounded UTF-8 JSON; never evaluate Python/YAML tags from input files."""
    file = Path(path)
    if file.stat().st_size > 9 * 1024 * 1024:
        raise ValueError("input file exceeds 9 MiB")
    return json.loads(file.read_text(encoding="utf-8-sig"))


def emit(value: Any) -> None:
    """Emit machine-readable UTF-8 JSON on all supported operating systems."""
    print(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))


def initialize(directory: Path) -> dict[str, str]:
    """Create distinct random keys in a non-overwriting, owner-only .env file."""
    root = directory.resolve()
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    path = root / ".env"
    lines = [f"JG_DATA_DIR={json.dumps(str(root / 'workspace'))}", "JG_BACKEND=demo"]
    for name in ("RUNTIME_TOKEN", "EDITOR_TOKEN", "APPROVER_TOKEN", "AUDIT_KEY"):
        lines.append(f"JG_{name}={secrets.token_urlsafe(36)}")
    lines += ["JG_ALLOW_EXTERNAL_DATA=false", "JG_TYPESAFE_API_KEY=", "JG_REFLECTION_MODEL=", "JG_REFLECTION_API_KEY="]
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as stream:
        stream.write("\n".join(lines) + "\n")
    return {"environment_file": str(path), "backend": "demo", "secrets_printed": "false"}


def parser() -> argparse.ArgumentParser:
    """Define stable commands without requiring optional CLI frameworks."""
    p = argparse.ArgumentParser(prog="jg", description="Jev + GEPA governed decision system")
    p.add_argument("--url", default="http://127.0.0.1:8000", help="platform API URL")
    sub = p.add_subparsers(dest="command", required=True)
    init = sub.add_parser("init"); init.add_argument("--directory", default=".")
    sub.add_parser("doctor")
    demo = sub.add_parser("demo"); demo.add_argument("--output"); demo.add_argument("--optimize", action="store_true")
    serve = sub.add_parser("serve"); serve.add_argument("--host", default="127.0.0.1"); serve.add_argument("--port", type=int, default=8000)
    worker = sub.add_parser("worker"); worker.add_argument("--once", action="store_true")
    recover = sub.add_parser("recover"); recover.add_argument("job_id"); recover.add_argument("--worker-stopped", action="store_true", required=True)
    for name in ("task-add", "dataset-add"):
        command = sub.add_parser(name); command.add_argument("file")
    sub.add_parser("tasks"); sub.add_parser("jobs"); sub.add_parser("audit")
    job = sub.add_parser("job"); job.add_argument("job_id")
    cancel = sub.add_parser("cancel"); cancel.add_argument("job_id")
    for name in ("task", "versions", "datasets"):
        command = sub.add_parser(name); command.add_argument("task_id")
    candidate = sub.add_parser("candidate"); candidate.add_argument("task_id"); candidate.add_argument("file")
    prediction = sub.add_parser("predict"); prediction.add_argument("task_id"); prediction.add_argument("file", help="JSON state file, not a request envelope")
    for name in ("optimize", "evaluate"):
        command = sub.add_parser(name); command.add_argument("task_id")
        command.add_argument("--version", required=True); command.add_argument("--dataset", required=True)
        command.add_argument("--key", default=None)
        command.add_argument("--metric-calls", type=int, default=200)
        command.add_argument("--jev-requests", type=int, default=500)
        command.add_argument("--reflection-requests", type=int, default=20)
        command.add_argument("--seconds", type=int, default=900)
    for name in ("approve", "rollback"):
        command = sub.add_parser(name); command.add_argument("task_id")
        command.add_argument("--version", required=True)
        command.add_argument("--expected-active", required=True, help="literal none only for initial approval")
        command.add_argument("--reason", required=True)
        if name == "approve":
            command.add_argument("--evaluation", required=True)
    request = sub.add_parser("request"); request.add_argument("method"); request.add_argument("path")
    request.add_argument("--file"); request.add_argument("--role", choices=["runtime", "editor", "approver"], default="runtime")
    request.add_argument("--key")
    return p


def main(argv: list[str] | None = None) -> int:
    """Return nonzero for failures; never print credentials or upstream exception bodies."""
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    args = parser().parse_args(argv)
    try:
        if args.command == "init":
            emit(initialize(Path(args.directory))); return 0
        if args.command == "doctor":
            packages = {}
            for name in ("fastapi", "httpx", "pydantic", "uvicorn", "gepa"):
                try:
                    packages[name] = version(name)
                except PackageNotFoundError:
                    packages[name] = "not installed"
            emit({"python": sys.version.split()[0], "packages": packages,
                  "live_api_verified": False, "official_gepa_available": packages["gepa"] == "0.1.4"})
            return 0
        if args.command == "demo":
            from .demo import run_demo
            with tempfile.TemporaryDirectory(prefix="jev-gepa-demo-") as directory:
                result = run_demo(Path(directory), args.optimize)
            if args.output:
                Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
                emit({"report": str(Path(args.output).resolve()), "backend": "demo"})
            else:
                emit(result)
            return 0
        settings = Settings() if args.command in {"serve", "worker", "recover"} else ClientSettings()
        if args.command == "serve":
            import uvicorn
            from .api import create_app
            uvicorn.run(create_app(settings), host=args.host, port=args.port, access_log=False)
            return 0
        if args.command in {"worker", "recover"}:
            from .service import Service
            service = Service(settings)
            if args.command == "recover":
                service.store.interrupt(args.job_id, "local-operator")
                emit(service.store.job(args.job_id)); return 0
            while True:
                result = service.work_once()
                if result is not None:
                    emit({"job_id": result["id"], "status": result["status"], "error_code": result["error_code"]})
                if args.once:
                    return 1 if result and result["status"] in {"failed", "interrupted"} else 0
                if result is None:
                    time.sleep(1)
        role = "approver" if args.command in {"approve", "rollback", "audit"} else "runtime" if args.command in {"predict", "tasks"} else "editor"
        if args.command == "request":
            role = args.role
        token = getattr(settings, role + "_token").get_secret_value()
        if not token:
            raise ValueError("the selected role credential is required")
        client = Client(args.url, token)
        method, path, body, key = "GET", "", None, None
        if args.command in {"task-add", "dataset-add"}:
            method, path, body = "POST", "/v1/tasks" if args.command == "task-add" else "/v1/datasets", read_json(args.file)
        elif args.command in {"tasks", "jobs"}:
            path = "/v1/" + args.command
        elif args.command in {"task", "versions", "datasets"}:
            path = f"/v1/tasks/{args.task_id}" + ("" if args.command == "task" else "/" + args.command)
        elif args.command in {"job", "cancel"}:
            path = f"/v1/jobs/{args.job_id}" + ("/cancel" if args.command == "cancel" else "")
            method = "POST" if args.command == "cancel" else "GET"
        elif args.command == "candidate":
            method, path, body = "POST", f"/v1/tasks/{args.task_id}/versions", read_json(args.file)
        elif args.command == "predict":
            emit(client.predict(args.task_id, read_json(args.file))); return 0
        elif args.command in {"optimize", "evaluate"}:
            method, path = "POST", f"/v1/tasks/{args.task_id}/jobs"
            key = args.key or new_id("cli")
            body = {"kind": args.command, "version_id": args.version, "dataset_id": args.dataset,
                    "max_metric_calls": args.metric_calls, "max_jev_requests": args.jev_requests,
                    "max_reflection_requests": args.reflection_requests, "max_seconds": args.seconds}
        elif args.command in {"approve", "rollback"}:
            method, path = "POST", f"/v1/tasks/{args.task_id}/" + ("activate" if args.command == "approve" else "rollback")
            body = {"version_id": args.version,
                    "expected_active": None if args.expected_active == "none" else args.expected_active,
                    "reason": args.reason}
            if args.command == "approve":
                body["evaluation_id"] = args.evaluation
        elif args.command == "audit":
            path = "/v1/audit/verify"
        elif args.command == "request":
            method, path, key = args.method.upper(), args.path, args.key
            body = read_json(args.file) if args.file else None
        emit(client.request(method, path, body, key)); return 0
    except DomainError as exc:
        emit({"error": {"code": exc.code, "message": exc.message, "status": exc.status}})
        return 1
    except (ValueError, OSError, RuntimeError, httpx.HTTPError) as exc:
        # argparse paths may be user-supplied; report a class, not unsafe exception content.
        emit({"error": {"code": "local_error", "type": type(exc).__name__,
                        "message": "Check configuration, JSON files and the verification report."}})
        return 1
    except KeyboardInterrupt:
        return 130


if __name__ == "__main__":
    raise SystemExit(main())
