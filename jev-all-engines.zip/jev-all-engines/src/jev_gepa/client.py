"""Small Python client for embedding the platform into an existing application."""

from __future__ import annotations

from typing import Any
from urllib.parse import urlsplit

import httpx

from .errors import DomainError


class Client:
    """Only the server calls Jev/GEPA. Client applications need a scoped platform token."""

    def __init__(self, base_url: str, token: str, timeout: float = 60) -> None:
        url = urlsplit(base_url)
        if (not url.hostname or url.username or url.password or url.query or url.fragment
            or url.scheme not in {"https", "http"}
            or (url.scheme == "http" and url.hostname not in {"localhost", "127.0.0.1", "::1"})):
            raise ValueError("client requires HTTPS except for loopback and rejects credentials/query/fragment")
        if not token or timeout <= 0:
            raise ValueError("a scoped token and positive timeout are required")
        self.base_url, self.token, self.timeout = base_url.rstrip("/"), token, timeout

    def request(
        self, method: str, path: str, body: Any = None, idempotency_key: str | None = None,
    ) -> Any:
        """Issue one platform request; do not automatically retry potentially billable work."""
        if not path.startswith("/v1/"):
            raise ValueError("client path must be a platform /v1/ path")
        headers = {"Authorization": "Bearer " + self.token}
        if idempotency_key is not None:
            headers["Idempotency-Key"] = idempotency_key
        with httpx.Client(timeout=self.timeout, trust_env=False, follow_redirects=False) as client:
            response = client.request(method, self.base_url + path, headers=headers, json=body)
        if response.is_error:
            try:
                payload = response.json()
                error = payload.get("error", {})
                message = error.get("message", "Platform request was rejected.")
                code = error.get("code", "http_error")
            except (ValueError, AttributeError):
                message, code = "Platform request was rejected.", "http_error"
            raise DomainError(code, message, response.status_code)
        return response.json()

    def predict(self, task_id: str, state: Any) -> dict[str, Any]:
        """Return structured answers and disposition. No external action is authorized."""
        return self.request("POST", f"/v1/tasks/{task_id}/predict", {"state": state})
