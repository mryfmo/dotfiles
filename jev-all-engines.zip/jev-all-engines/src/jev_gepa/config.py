"""Process-owned settings: endpoint addresses and API credentials are never task inputs."""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Literal, Self
from urllib.parse import urlsplit

from pydantic import Field, SecretStr, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Separate credentials for inference, editing and human release approval."""

    model_config = SettingsConfigDict(env_prefix="JG_", env_file=".env", extra="ignore")
    data_dir: Path = Path("workspace")
    backend: Literal["demo", "live"] = "demo"
    runtime_token: SecretStr = SecretStr("")
    editor_token: SecretStr = SecretStr("")
    approver_token: SecretStr = SecretStr("")
    audit_key: SecretStr = SecretStr("")
    typesafe_api_key: SecretStr = SecretStr("")
    jev_endpoint: str = "https://api.typesafe.ai/v1/systemone"
    reflection_protocol: Literal["anthropic", "chat_completions"] = "anthropic"
    reflection_endpoint: str = "https://api.anthropic.com/v1/messages"
    reflection_model: str = ""
    reflection_api_key: SecretStr = SecretStr("")
    allow_external_data: bool = False
    allow_loopback_upstream: bool = False
    timeout_seconds: float = Field(default=30, ge=1, le=300)
    max_attempts: int = Field(default=3, ge=1, le=5)
    requests_per_minute: int = Field(default=120, ge=1, le=100000)

    @model_validator(mode="after")
    def safe_configuration(self) -> Self:
        tokens = [self.runtime_token, self.editor_token, self.approver_token, self.audit_key]
        values = [x.get_secret_value() for x in tokens]
        if any(len(x) < 32 for x in values) or len(set(values)) != 4:
            raise ValueError("four distinct secrets of at least 32 characters are required; run jg init")
        for endpoint in (self.jev_endpoint, self.reflection_endpoint):
            url = urlsplit(endpoint)
            local = url.hostname in {"localhost", "127.0.0.1", "::1"}
            if not url.hostname or url.username or url.password or url.query or url.fragment:
                raise ValueError("upstream must be an absolute URL without credentials/query/fragment")
            if url.scheme != "https" and not (
                url.scheme == "http" and local and self.allow_loopback_upstream
            ):
                raise ValueError("upstream requires HTTPS; explicit loopback opt-in permits local HTTP")
        if self.backend == "live" and not self.typesafe_api_key.get_secret_value():
            raise ValueError("live backend requires JG_TYPESAFE_API_KEY")
        return self

    def provider_fingerprint(self, model: str) -> str:
        """Bind evidence and active versions to a concrete runtime backend and model."""
        raw = f"{self.backend}|{self.jev_endpoint}|{model}|jev-gepa-system/1.0.0"
        return hashlib.sha256(raw.encode()).hexdigest()


class ClientSettings(BaseSettings):
    """A CLI client needs only its own role credential, not all server secrets."""

    model_config = SettingsConfigDict(env_prefix="JG_", env_file=".env", extra="ignore")
    runtime_token: SecretStr = SecretStr("")
    editor_token: SecretStr = SecretStr("")
    approver_token: SecretStr = SecretStr("")
