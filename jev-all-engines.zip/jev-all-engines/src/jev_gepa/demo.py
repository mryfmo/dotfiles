"""Self-contained offline lifecycle demonstration; no Jev/LLM accuracy claims."""

from __future__ import annotations

import json
import secrets
from pathlib import Path
from typing import Any

from .config import Settings
from .models import Dataset, Example, JobRequest, TaskSpec, canonical
from .service import Service


def demo_settings(directory: Path) -> Settings:
    """Create ephemeral scoped secrets without reading the user's .env or sending data."""
    return Settings(_env_file=None, data_dir=directory, backend="demo",
                    runtime_token=secrets.token_urlsafe(36), editor_token=secrets.token_urlsafe(36),
                    approver_token=secrets.token_urlsafe(36), audit_key=secrets.token_urlsafe(36))


def support_task() -> TaskSpec:
    """A mixed-primitive sample with unchanged default release controls."""
    return TaskSpec.model_validate({
        "id": "support-routing", "title": "問い合わせの分類・緊急性・文面の強さ",
        "description": "サンプル定義。受付後の業務処理・契約変更は実行しない。",
        "questions": {
            "route": {"type": "choice", "instructions": "問い合わせを担当部署に分類する。",
                "criteria": {"billing": "請求、支払い、返金", "technical": "不具合、障害、連携", "sales": "見積、価格、新規契約"}},
            "urgency": {"type": "noul", "instructions": "明確な期限または至急の対応を求めているか。",
                "criteria": {"true": "明確に至急の対応が必要", "false": "緊急性は示されていない"}},
            "intensity": {"type": "score", "instructions": "文面の強い感情表現を評価する。",
                "criteria": ["落ち着いた文面", "強めの表現", "非常に強い表現"]},
        },
    })


def support_dataset(test_generation: int = 1) -> Dataset:
    """Synthetic fixtures intentionally exercise plumbing, not generalization or efficacy."""
    splits = {}
    labels = ["billing", "technical", "sales"]
    for split, n in (("train", 12), ("validation", 6), ("test", 36)):
        generation = test_generation if split == "test" else 1
        rows = []
        for i in range(n):
            label = labels[i % 3]
            urgent = bool(i % 2)
            intensity = i % 3
            state = {"text": f"{label} の問い合わせ {split}-{generation}-{i} "
                              + ("至急 urgent " if urgent else "通常のご相談 ") + "!" * intensity}
            rows.append(Example(id=f"{split}-{generation}-{i}", group=f"g-{split}-{generation}-{i}",
                state=state, expected={"route": label, "urgency": urgent, "intensity": float(intensity)},
                critical=i % 6 == 1))
        splits[split] = rows
    return Dataset(id=f"support-data-{test_generation}", task_id="support-routing", synthetic=True, **splits)


def run_demo(directory: Path, include_gepa: bool = False) -> dict[str, Any]:
    """Run registration→evaluation→approval→inference→candidate→re-evaluation→rollback."""
    settings = demo_settings(directory)
    service = Service(settings)
    task = support_task()
    seed = service.store.create_task(task, "demo-editor")["version_id"]
    service.store.add_dataset(support_dataset(1), "demo-editor")
    service.enqueue(task.id, JobRequest(kind="evaluate", version_id=seed, dataset_id="support-data-1"),
                    "demo-eval-1", "demo-editor")
    first = service.work_once()
    if first is None or first["status"] != "succeeded":
        raise RuntimeError("demo evaluation failed")
    first_eval = first["result"]["evaluation_id"]
    service.store.activate(task.id, seed, first_eval, None, "demo-approver",
                           "Offline fixture approval; not production evidence", settings.provider_fingerprint(task.model))
    prediction = service.predict(task.id, {"text": "technical 障害です 至急 urgent !!"}, "demo-runtime")
    review = service.predict(task.id, {"text": "担当部署が判別できないご相談"}, "demo-runtime")
    components = service.store.version(task.id, seed)["components"]
    question = json.loads(components["route"])
    question["instructions"] += " 請求問題と技術的障害を区別し、書かれた内容だけを用いる。"
    components["route"] = canonical(question)
    changed = service.store.add_version(task.id, seed, components, "demo-editor", "manual-demo")
    service.store.add_dataset(support_dataset(2), "demo-editor")
    service.enqueue(task.id, JobRequest(kind="evaluate", version_id=changed, dataset_id="support-data-2"),
                    "demo-eval-2", "demo-editor")
    second = service.work_once()
    if second is None or second["status"] != "succeeded":
        raise RuntimeError("demo paired evaluation failed")
    service.store.activate(task.id, changed, second["result"]["evaluation_id"], seed, "demo-approver",
                           "Approve changed offline fixture after paired validation", settings.provider_fingerprint(task.model))
    rollback = service.store.rollback(task.id, seed, changed, "demo-approver",
                                      "Exercise rollback to previously approved version", settings.provider_fingerprint(task.model))
    optimization = {"executed": False, "reason": "Use --optimize with official GEPA installed; no substitute engine is used."}
    if include_gepa:
        service.enqueue(task.id, JobRequest(kind="optimize", version_id=seed, dataset_id="support-data-1",
                                           max_metric_calls=24), "demo-optimize", "demo-editor")
        job = service.work_once()
        optimization = {"executed": True, "job": job}
        if job is None or job["status"] != "succeeded":
            raise RuntimeError("official GEPA demo failed")
    return {
        "backend": "demo", "uses_real_jev": False, "uses_real_reflection_model": False,
        "demonstrates": ["register", "evaluate", "approve", "predict", "review", "paired_evaluation", "rollback", "audit"],
        "first_evaluation": first["result"]["report"], "paired_evaluation": second["result"]["report"],
        "prediction": prediction, "uncertain_prediction": review,
        "rollback": rollback, "audit": service.store.verify_audit(), "optimization": optimization,
        "warning": "Synthetic rule-based fixture results are NOT Jev/GEPA quality or cost measurements.",
    }
