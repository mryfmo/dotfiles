"""Safe domain errors: messages must never contain state, credentials or upstream bodies."""


class DomainError(Exception):
    """An error safe to expose through the public API."""

    def __init__(self, code: str, message: str, status: int = 400) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status = status


class ProviderError(DomainError):
    """An unavailable, malformed or unauthorized upstream; never a valid decision."""

    def __init__(self, code: str, message: str, retryable: bool = False) -> None:
        super().__init__(code, message, 502)
        self.retryable = retryable


class BudgetExceeded(DomainError):
    """A request budget or cooperative execution deadline stopped the operation."""

    def __init__(self, message: str = "The configured execution budget was exhausted.") -> None:
        super().__init__("budget_exceeded", message, 409)


class Cancelled(DomainError):
    """Cancellation was observed between bounded external operations."""

    def __init__(self) -> None:
        super().__init__("cancelled", "The operation was cancelled.", 409)
