"""Independent metrics, uncertainty intervals and immutable release criteria."""

from __future__ import annotations

import math
from collections import Counter
from statistics import mean
from typing import Any

from .models import Example, Prediction, TaskSpec


def score_example(spec: TaskSpec, row: Example, prediction: Prediction) -> dict[str, Any]:
    """Use accuracy + proper scores for classification, normalized MAE for ordinal scores.

    Confidence is not optimized. Review/abstention cannot inflate training reward.
    A case is correct only if every question satisfies its fixed correctness rule.
    """
    metrics: dict[str, Any] = {}
    total, weights = 0.0, 0.0
    for qid, q in spec.questions.items():
        truth = row.expected[qid]
        answer = prediction.answers[qid]
        brier: float | None = None
        if q.type == "choice":
            correct = answer.value == truth
            probs = answer.probabilities or {}
            brier = sum((p - float(k == truth)) ** 2 for k, p in probs.items()) / 2
            quality = 0.5 * float(correct) + 0.5 * (1 - brier)
            label = str(truth)
        elif q.type == "noul":
            p = float(answer.value)
            correct = (p >= 0.5) == truth
            brier = (p - float(truth)) ** 2
            quality = 0.5 * float(correct) + 0.5 * (1 - brier)
            label = "true" if truth else "false"
        else:
            scale = len(q.criteria or []) - 1
            error = abs(float(answer.value) - float(truth)) / scale
            correct = error <= q.score_tolerance + 1e-12
            quality = max(0.0, 1 - error)
            # Exact ground-truth levels are reported; no rounding creates fake class support.
            label = str(float(truth))
        metrics[qid] = {
            "correct": bool(correct), "quality": quality, "brier": brier,
            "label": label, "predicted": answer.value,
        }
        total += quality * q.weight
        weights += q.weight
    return {
        "id": row.id, "critical": row.critical, "quality": total / weights,
        "correct": all(x["correct"] for x in metrics.values()),
        "accepted": prediction.disposition == "accepted", "questions": metrics,
        "latency_ms": prediction.latency_ms, "provider_error": False,
    }


def failed_example(spec: TaskSpec, row: Example, code: str) -> dict[str, Any]:
    """Missing predictions are failures, never silently removed from a denominator."""
    return {
        "id": row.id, "critical": row.critical, "quality": 0.0, "correct": False,
        "accepted": False, "latency_ms": 0.0, "provider_error": True, "error_code": code,
        "questions": {
            qid: {"correct": False, "quality": 0.0, "brier": None,
                  "label": ("true" if row.expected[qid] else "false") if q.type == "noul"
                  else str(float(row.expected[qid])) if q.type == "score" else str(row.expected[qid]),
                  "predicted": None}
            for qid, q in spec.questions.items()
        },
    }


def wilson(successes: int, n: int) -> tuple[float, float]:
    """Two-sided 95% Wilson interval; no samples means the fully uncertain [0,1]."""
    if n == 0:
        return 0.0, 1.0
    z = 1.959963984540054
    p = successes / n
    denominator = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denominator
    radius = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denominator
    return max(0.0, center - radius), min(1.0, center + radius)


def aggregate(spec: TaskSpec, rows: list[dict[str, Any]]) -> dict[str, Any]:
    """Summarize ALL test cases, accepted cases, slices, critical cases and Brier scores."""
    if not rows:
        raise ValueError("cannot evaluate an empty set")
    accepted = [r for r in rows if r["accepted"]]
    errors = sum(not r["correct"] for r in accepted)
    correct = sum(r["correct"] for r in rows)
    qmetrics = {}
    for qid in spec.questions:
        values = [r["questions"][qid] for r in rows]
        supports = Counter(v["label"] for v in values)
        briers = [v["brier"] for v in values if v["brier"] is not None]
        qmetrics[qid] = {
            "quality": mean(v["quality"] for v in values),
            "accuracy": mean(float(v["correct"]) for v in values),
            "label_support": dict(supports),
            "label_recall": {
                label: sum(v["correct"] for v in values if v["label"] == label) / n
                for label, n in supports.items()
            },
            "mean_brier": mean(briers) if briers else None,
            "brier_sample_count": len(briers),
        }
    latencies = sorted(r["latency_ms"] for r in rows if not r["provider_error"])
    return {
        "n": len(rows), "quality": mean(r["quality"] for r in rows),
        "accuracy": correct / len(rows), "accuracy_ci95": list(wilson(correct, len(rows))),
        "coverage": len(accepted) / len(rows), "auto_cases": len(accepted),
        "auto_errors": errors, "auto_error_rate": errors / len(accepted) if accepted else None,
        "auto_error_upper_95": wilson(errors, len(accepted))[1],
        "critical_errors": sum(r["critical"] and not r["correct"] for r in rows),
        "provider_errors": sum(r["provider_error"] for r in rows),
        "latency_p95_ms": latencies[math.ceil(0.95 * len(latencies)) - 1] if latencies else None,
        "questions": qmetrics,
    }


def release_gate(
    spec: TaskSpec, candidate: dict[str, Any], baseline: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Fail closed: inadequate support, missing classes and outages block release."""
    g = spec.gate
    failures: list[str] = []
    checks = [
        (candidate["n"] >= g.min_test_cases, "insufficient_test_cases"),
        (candidate["quality"] >= g.min_quality, "quality_below_minimum"),
        (candidate["coverage"] >= g.min_coverage, "coverage_below_minimum"),
        (candidate["auto_cases"] >= g.min_auto_cases, "insufficient_auto_cases"),
        (candidate["auto_error_rate"] is not None and candidate["auto_error_rate"] <= g.max_auto_error_rate,
         "auto_error_rate_exceeded"),
        (candidate["auto_error_upper_95"] <= g.max_auto_error_upper_95, "auto_error_uncertainty_exceeded"),
        (candidate["critical_errors"] <= g.max_critical_errors, "critical_errors_exceeded"),
        (candidate["provider_errors"] == 0, "provider_errors_present"),
    ]
    failures.extend(name for ok, name in checks if not ok)
    for qid, q in spec.questions.items():
        m = candidate["questions"][qid]
        if m["quality"] < g.min_question_quality:
            failures.append(f"{qid}:question_quality_below_minimum")
        if q.type == "choice":
            labels = list(q.criteria or {})
        elif q.type == "noul":
            labels = ["true", "false"]
        else:
            # Score is ordinal regression; require rubric-level support for release validation.
            labels = [str(float(i)) for i in range(len(q.criteria or []))]
        for label in labels:
            if m["label_support"].get(label, 0) < g.min_label_support:
                failures.append(f"{qid}:label_support:{label}")
            if m["label_recall"].get(label, 0.0) < g.min_label_recall:
                failures.append(f"{qid}:label_recall:{label}")
        if baseline is not None:
            if m["quality"] + g.max_regression < baseline["questions"][qid]["quality"]:
                failures.append(f"{qid}:question_regression")
    if baseline is not None and candidate["quality"] + g.max_regression < baseline["quality"]:
        failures.append("overall_regression")
    return {"passed": not failures, "failures": failures, "policy": g.model_dump()}
