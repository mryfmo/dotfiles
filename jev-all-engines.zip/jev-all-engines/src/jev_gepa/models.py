"""Strict, portable contracts for tasks, candidates, data, jobs and decisions."""

from __future__ import annotations

import hashlib
import json
import re
import unicodedata
from typing import Annotated, Any, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, JsonValue, field_validator, model_validator

Id = Annotated[str, Field(pattern=r"^[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}$")]
Probability = Annotated[float, Field(ge=0, le=1, allow_inf_nan=False)]
Text = Annotated[str, Field(min_length=1, max_length=12000)]


def canonical(value: Any) -> str:
    """Serialize finite JSON consistently for identity, persistence and audit."""
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value: Any) -> str:
    """Return the SHA-256 of a JSON value, not of a Python representation."""
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def normalized_state(value: Any) -> Any:
    """Normalize text for exact/near-format leakage checks without changing inference input."""
    if isinstance(value, str):
        return re.sub(r"\s+", " ", unicodedata.normalize("NFKC", value)).strip().casefold()
    if isinstance(value, dict):
        return {k: normalized_state(v) for k, v in value.items()}
    if isinstance(value, list):
        return [normalized_state(v) for v in value]
    return value


def state_fingerprint(value: Any) -> str:
    """Fingerprint normalized inputs; labels and record IDs are excluded."""
    return digest(normalized_state(value))


def validate_state(value: JsonValue) -> JsonValue:
    """Bound text/JSON state and disallow scalar, empty and excessively nested inputs."""
    if not isinstance(value, (str, dict, list)) or not value:
        raise ValueError("state must be a nonempty string, object or array")
    if isinstance(value, str) and not value.strip():
        raise ValueError("state cannot be blank")
    if len(canonical(value).encode("utf-8")) > 65536:
        raise ValueError("state exceeds the 64 KiB application limit (not a token limit)")

    def depth(obj: Any, level: int = 0) -> None:
        if level > 16:
            raise ValueError("state exceeds 16 nesting levels")
        children = obj.values() if isinstance(obj, dict) else obj if isinstance(obj, list) else []
        for child in children:
            depth(child, level + 1)

    depth(value)
    return value


class StrictModel(BaseModel):
    """Reject unknown fields, NaN and infinity at application boundaries."""

    model_config = ConfigDict(extra="forbid", allow_inf_nan=False, validate_assignment=True)


class Question(StrictModel):
    """One atomic question. Only instructions and criteria text may be evolved."""

    type: Literal["choice", "score", "noul"]
    instructions: Text
    criteria: dict[str, str | None] | list[str] | None = None
    weight: Annotated[float, Field(gt=0, le=100, allow_inf_nan=False)] = 1.0
    min_confidence: Probability = 0.75
    noul_false_threshold: Probability = 0.2
    noul_true_threshold: Probability = 0.8
    score_tolerance: Annotated[float, Field(ge=0, le=1)] = 0.15
    review_choices: list[str] = Field(default_factory=list, max_length=100)

    @model_validator(mode="after")
    def validate_question(self) -> Self:
        if not self.instructions.strip():
            raise ValueError("instructions cannot be blank")
        if self.type == "choice":
            if not isinstance(self.criteria, dict) or not 2 <= len(self.criteria) <= 100:
                raise ValueError("choice needs 2..100 options")
            if any(not k.strip() or len(k) > 100 for k in self.criteria):
                raise ValueError("choice labels must be nonempty and at most 100 characters")
            if not set(self.review_choices) <= set(self.criteria):
                raise ValueError("review_choices must be known choice labels")
        elif self.type == "score":
            if not isinstance(self.criteria, list) or not 2 <= len(self.criteria) <= 20:
                raise ValueError("score needs 2..20 ordered levels")
            if any(not x.strip() for x in self.criteria):
                raise ValueError("score levels cannot be blank")
        elif self.criteria is not None:
            if not isinstance(self.criteria, dict) or set(self.criteria) != {"true", "false"}:
                raise ValueError("noul criteria must contain exactly true and false")
            if any(not isinstance(x, str) or not x.strip() for x in self.criteria.values()):
                raise ValueError("noul descriptions must be nonempty strings")
        if self.type != "choice" and self.review_choices:
            raise ValueError("review_choices applies only to Choice")
        values = self.criteria.values() if isinstance(self.criteria, dict) else self.criteria or []
        if any(x is not None and len(x) > 12000 for x in values):
            raise ValueError("criterion exceeds 12000 characters")
        if not self.noul_false_threshold < 0.5 < self.noul_true_threshold:
            raise ValueError("noul thresholds must bracket 0.5 strictly")
        return self

    def wire(self) -> dict[str, Any]:
        """Build only the documented TypeSafe request fields."""
        result: dict[str, Any] = {"type": self.type, "instructions": self.instructions}
        if self.criteria is not None:
            result["criteria"] = self.criteria
        return result


class GatePolicy(StrictModel):
    """Frozen release criteria; these never enter GEPA's mutable candidate."""

    min_test_cases: Annotated[int, Field(ge=1, le=5000)] = 30
    min_quality: Probability = 0.85
    min_question_quality: Probability = 0.8
    min_coverage: Probability = 0.5
    min_auto_cases: Annotated[int, Field(ge=1, le=5000)] = 20
    max_auto_error_rate: Probability = 0.05
    max_auto_error_upper_95: Probability = 0.2
    max_regression: Probability = 0.02
    min_label_recall: Probability = 0.7
    min_label_support: Annotated[int, Field(ge=1, le=1000)] = 3
    max_critical_errors: Annotated[int, Field(ge=0, le=1000)] = 0


class TaskSpec(StrictModel):
    """Immutable task contract; change governed policy by creating a new task ID."""

    id: Id
    title: Annotated[str, Field(min_length=1, max_length=200)]
    description: Annotated[str, Field(max_length=4000)] = ""
    model: Annotated[str, Field(pattern=r"^jev-\d+\.\d+\.\d+$")] = "jev-1.13.0"
    questions: dict[Id, Question] = Field(min_length=1, max_length=24)
    gate: GatePolicy = Field(default_factory=GatePolicy)

    @model_validator(mode="after")
    def bounded(self) -> Self:
        if len(canonical(self.model_dump()).encode("utf-8")) > 98304:
            raise ValueError("task exceeds the 96 KiB application limit")
        return self


def seed_candidate(spec: TaskSpec) -> dict[str, str]:
    """Use one typed question JSON string per GEPA component (no mutable policies)."""
    return {qid: canonical(q.wire()) for qid, q in spec.questions.items()}


def apply_candidate(spec: TaskSpec, candidate: dict[str, str]) -> TaskSpec:
    """Validate a candidate and retain frozen IDs, labels, types, weights and thresholds."""
    if set(candidate) != set(spec.questions):
        raise ValueError("candidate question IDs cannot change")
    result = spec.model_dump()
    for qid, text in candidate.items():
        if not isinstance(text, str) or len(text.encode("utf-8")) > 49152:
            raise ValueError("candidate component is not bounded text")
        data = json.loads(text)
        if not isinstance(data, dict) or set(data) - {"type", "instructions", "criteria"}:
            raise ValueError("candidate includes unknown or governed fields")
        old = spec.questions[qid]
        updated = Question.model_validate({**old.model_dump(), **data})
        if updated.type != old.type:
            raise ValueError("question type cannot change")
        if isinstance(old.criteria, dict):
            if not isinstance(updated.criteria, dict) or set(old.criteria) != set(updated.criteria):
                raise ValueError("choice/noul criterion keys cannot change")
        elif isinstance(old.criteria, list):
            if not isinstance(updated.criteria, list) or len(old.criteria) != len(updated.criteria):
                raise ValueError("score scale cardinality cannot change")
        elif updated.criteria is not None:
            raise ValueError("candidate cannot introduce criterion structure")
        result["questions"][qid] = updated.model_dump()
    return TaskSpec.model_validate(result)


class Example(StrictModel):
    """A labeled case with provenance grouping and an optional critical-error flag."""

    id: Id
    group: Id
    state: JsonValue
    expected: dict[str, Annotated[str, Field(strict=True)] | Annotated[bool, Field(strict=True)] | Annotated[float, Field(strict=True, allow_inf_nan=False)]]
    critical: bool = False
    _state = field_validator("state")(validate_state)


class Dataset(StrictModel):
    """Explicit split assignments; normalized state and group overlap are rejected."""

    id: Id
    task_id: Id
    synthetic: bool = False
    train: list[Example] = Field(min_length=1, max_length=5000)
    validation: list[Example] = Field(min_length=1, max_length=5000)
    test: list[Example] = Field(min_length=1, max_length=5000)

    @model_validator(mode="after")
    def no_leakage(self) -> Self:
        seen_ids: set[str] = set()
        seen_states: set[str] = set()
        seen_groups: dict[str, str] = {}
        total = 0
        for split in ("train", "validation", "test"):
            for row in getattr(self, split):
                total += 1
                fingerprint = state_fingerprint(row.state)
                if row.id in seen_ids or fingerprint in seen_states:
                    raise ValueError("duplicate record ID or normalized state")
                if row.group in seen_groups and seen_groups[row.group] != split:
                    raise ValueError("group leakage across splits")
                seen_ids.add(row.id)
                seen_states.add(fingerprint)
                seen_groups[row.group] = split
        if total > 5000:
            raise ValueError("at most 5000 total cases per dataset")
        if len(canonical(self.model_dump()).encode("utf-8")) > 8 * 1024 * 1024:
            raise ValueError("dataset exceeds 8 MiB")
        return self

    def validate_labels(self, spec: TaskSpec) -> None:
        """Reject unscorable labels instead of silently omitting questions."""
        if self.task_id != spec.id:
            raise ValueError("dataset belongs to a different task")
        for row in self.train + self.validation + self.test:
            if set(row.expected) != set(spec.questions):
                raise ValueError("each case must label every question exactly once")
            for qid, q in spec.questions.items():
                label = row.expected[qid]
                if q.type == "choice" and (
                    not isinstance(label, str) or label not in (q.criteria or {})
                ):
                    raise ValueError("unknown Choice ground-truth label")
                if q.type == "noul" and not isinstance(label, bool):
                    raise ValueError("Noul ground truth must be a JSON boolean")
                if q.type == "score" and (
                    isinstance(label, (bool, str))
                    or not 0 <= label <= len(q.criteria or []) - 1
                ):
                    raise ValueError("Score ground truth must be in the rubric scale")


class Answer(StrictModel):
    """Normalized Jev result. Noul has no fabricated confidence field."""

    type: Literal["choice", "score", "noul"]
    value: str | float
    confidence: Probability | None = None
    probabilities: dict[str, Probability] | None = None


class Prediction(StrictModel):
    """Typed decision data, explicitly not permission to execute an external action."""

    model: str
    answers: dict[str, Answer]
    disposition: Literal["accepted", "review"]
    review_reasons: list[str]
    backend: Literal["demo", "live"]
    latency_ms: Annotated[float, Field(ge=0)]
    input_tokens: Annotated[int, Field(ge=0)] = 0
    output_tokens: Annotated[int, Field(ge=0)] = 0


class PredictRequest(StrictModel):
    """Inference only uses the server's active, approved version."""

    state: JsonValue
    _state = field_validator("state")(validate_state)


class CandidateRequest(StrictModel):
    """Manual reviewable candidate; cannot modify task policy."""

    parent_version: Id
    components: dict[str, str]
    reason: Annotated[str, Field(min_length=8, max_length=2000)]


class JobRequest(StrictModel):
    """Budgeted GEPA optimization or independent final evaluation job."""

    kind: Literal["optimize", "evaluate"]
    version_id: Id
    dataset_id: Id
    max_metric_calls: Annotated[int, Field(ge=1, le=100000)] = 200
    max_jev_requests: Annotated[int, Field(ge=1, le=100000)] = 500
    max_reflection_requests: Annotated[int, Field(ge=1, le=1000)] = 20
    max_seconds: Annotated[int, Field(ge=1, le=86400)] = 900
    seed: Annotated[int, Field(ge=0, le=2147483647)] = 42


class ActivateRequest(StrictModel):
    """Compare-and-swap activation with a successful bound release evaluation."""

    version_id: Id
    evaluation_id: Id
    expected_active: Id | None
    reason: Annotated[str, Field(min_length=8, max_length=2000)]


class RollbackRequest(StrictModel):
    """Only an already activated version may be restored."""

    version_id: Id
    expected_active: Id
    reason: Annotated[str, Field(min_length=8, max_length=2000)]
