"""Official GEPA integration; the engine is never replaced by a look-alike search loop."""

from __future__ import annotations

import importlib
import inspect
from importlib.metadata import PackageNotFoundError, version
from typing import Any, Callable

from .errors import DomainError, ProviderError
from .evaluation import failed_example, score_example
from .models import Example, TaskSpec, apply_candidate
from .providers import Budget, DecisionProvider, ProposalProvider


class SafeLogger:
    """Suppress GEPA's free-form logs, which may contain sensitive prompt material."""

    def __init__(self) -> None:
        self.events = 0

    def log(self, message: str) -> None:
        """Count diagnostic events without persisting their text."""
        self.events += 1


class JevGEPAAdapter:
    """Implement the documented evaluate/reflect/propose integration seam."""

    def __init__(
        self, spec: TaskSpec, decision: DecisionProvider, reflection: ProposalProvider,
        budget: Budget, batch_factory: Callable[..., Any] | None = None,
    ) -> None:
        self.spec, self.decision, self.reflection, self.budget = spec, decision, reflection, budget
        self.batch_factory = batch_factory
        self.metric_calls = 0
        self.rejected_proposals = 0
        self.provider_errors = 0

    def evaluate(
        self, batch: list[Example], candidate: dict[str, str], capture_traces: bool = False,
    ) -> Any:
        """Score every case and return real GEPA EvaluationBatch objects in production."""
        factory = self.batch_factory
        if factory is None:
            factory = importlib.import_module("gepa.core.adapter").EvaluationBatch
        spec = apply_candidate(self.spec, candidate)
        outputs: list[Any] = []
        scores: list[float] = []
        traces: list[dict[str, Any]] = []
        for row in batch:
            self.budget.check()
            self.metric_calls += 1
            try:
                prediction = self.decision.predict(spec, row.state, self.budget)
                metric = score_example(spec, row, prediction)
                output = prediction.model_dump()
            except ProviderError as exc:
                self.provider_errors += 1
                metric = failed_example(spec, row, exc.code)
                output = {"error_code": exc.code}
            outputs.append(output)
            scores.append(metric["quality"])
            if capture_traces:
                traces.append({"state": row.state, "expected": row.expected,
                               "output": output, "metric": metric})
        return factory(outputs=outputs, scores=scores, trajectories=traces if capture_traces else None)

    def make_reflective_dataset(
        self, candidate: dict[str, str], eval_batch: Any, components_to_update: list[str],
    ) -> dict[str, list[dict[str, Any]]]:
        """Forward training traces only; the optimizer never receives held-out test cases."""
        if eval_batch.trajectories is None:
            raise DomainError("reflection_trace", "GEPA did not request the required training traces.", 409)
        return {
            component: [
                {"Inputs": trace["state"], "Generated Outputs": trace["output"],
                 "Feedback": {"expected": trace["expected"][component],
                              "metrics": trace["metric"]["questions"][component]}}
                for trace in eval_batch.trajectories
            ] for component in components_to_update
        }

    def propose_new_texts(
        self, candidate: dict[str, str], reflective_dataset: dict[str, Any],
        components_to_update: list[str],
    ) -> dict[str, str]:
        """Reject structural policy changes without letting a generated program execute."""
        proposal = self.reflection.propose(
            {"candidate": candidate, "components_to_update": components_to_update,
             "feedback": reflective_dataset}, self.budget,
        )
        try:
            if set(proposal) != set(components_to_update):
                raise ValueError("unexpected component keys")
            apply_candidate(self.spec, {**candidate, **proposal})
        except (TypeError, ValueError):
            self.rejected_proposals += 1
            return {key: candidate[key] for key in components_to_update}
        return proposal


class DemoReflection:
    """Identity proposal fixture. Exercises REAL GEPA if installed; claims no improvement."""

    def propose(self, request: dict[str, Any], budget: Budget) -> dict[str, str]:
        """Return unchanged components and count no external LLM tokens."""
        budget.check()
        return {key: request["candidate"][key] for key in request["components_to_update"]}


def require_gepa() -> Any:
    """Reject missing/unreviewed engine versions rather than silently changing algorithms."""
    try:
        installed = version("gepa")
        if installed != "0.1.4":
            raise DomainError("gepa_version", "This release requires reviewed GEPA version 0.1.4.", 409)
        return importlib.import_module("gepa")
    except (PackageNotFoundError, ImportError) as exc:
        raise DomainError("gepa_not_installed", "Install the official engine with: uv sync --extra optimize", 409) from exc


def run_gepa(
    spec: TaskSpec, components: dict[str, str], train: list[Example], validation: list[Example],
    adapter: JevGEPAAdapter, max_metric_calls: int, seed: int,
) -> dict[str, Any]:
    """Execute real GEPA Pareto search; only training and validation splits cross this API."""
    module = require_gepa()
    apply_candidate(spec, components)
    if not train or not validation:
        raise DomainError("data_required", "Independent nonempty training and validation sets are required.", 409)
    if max_metric_calls < len(validation) + 2:
        raise DomainError("metric_budget", "Metric budget must cover baseline validation plus exploration.", 409)
    logger = SafeLogger()
    kwargs: dict[str, Any] = {
        "seed_candidate": components, "trainset": train, "valset": validation,
        "adapter": adapter, "max_metric_calls": max_metric_calls, "seed": seed,
        "raise_on_exception": True, "candidate_selection_strategy": "pareto",
        "reflection_minibatch_size": min(3, len(train)), "module_selector": "round_robin",
        "use_merge": True, "max_merge_invocations": 5,
        "display_progress_bar": False, "cache_evaluation": False,
        "run_dir": None, "use_cloudpickle": False, "logger": logger,
        "stop_callbacks": [lambda _: adapter.budget.check() or False],
    }
    supported = inspect.signature(module.optimize).parameters
    required = {"seed_candidate", "trainset", "valset", "adapter", "max_metric_calls", "seed", "raise_on_exception"}
    if not required <= set(supported):
        raise DomainError("gepa_api_drift", "Installed GEPA has an incompatible optimize signature.", 409)
    # Optional controls vary between release documentation and main; no pickle/run directory is used.
    options = {k: v for k, v in kwargs.items() if k in supported}
    result = module.optimize(**options)
    adapter.budget.check()
    best = result.best_candidate
    apply_candidate(spec, best)
    raw_scores = getattr(result, "val_aggregate_scores", [])
    best_quality = max(raw_scores) if raw_scores else None
    return {
        "engine": "gepa", "engine_version": "0.1.4", "best_candidate": best,
        "metric_calls": adapter.metric_calls,
        "candidates_evaluated": len(getattr(result, "candidates", [])),
        "best_validation_quality": best_quality,
        "rejected_structural_proposals": adapter.rejected_proposals,
        "provider_errors": adapter.provider_errors,
        "seed": seed, "test_split_used": False,
        "enabled_engine_controls": sorted(options), "logged_event_count": logger.events,
        "demonstration": isinstance(adapter.reflection, DemoReflection),
    }
