"""Application orchestration separating inference, optimization, evaluation and promotion."""

from __future__ import annotations

from typing import Any

from .config import Settings
from .errors import Cancelled, DomainError, ProviderError
from .evaluation import aggregate, failed_example, release_gate, score_example
from .models import Example, JobRequest, TaskSpec, apply_candidate, digest
from .optimizer import DemoReflection, JevGEPAAdapter, require_gepa, run_gepa
from .providers import Budget, DecisionProvider, DemoProvider, JevProvider, ReflectionProvider
from .store import Store


class Service:
    """A single-workspace service; provider injection is explicit and used by contract tests."""

    def __init__(self, settings: Settings, decision: DecisionProvider | None = None) -> None:
        self.settings = settings
        self.store = Store(settings.data_dir, settings.audit_key.get_secret_value())
        if not self.store.verify_audit()["valid"]:
            raise DomainError("audit_integrity", "Audit chain verification failed; service cannot start until investigated.", 409)
        self.decision = decision or (DemoProvider() if settings.backend == "demo" else JevProvider(settings))

    def predict(self, task_id: str, state: Any, actor: str) -> dict[str, Any]:
        """Serve only the approved active version for the exact current backend/model."""
        base, active = self.store.task(task_id)
        if active is None:
            raise DomainError("no_active_version", "Evaluate and approve a version before inference.", 409)
        version = self.store.version(task_id, active)
        if version["provider_fingerprint"] != self.settings.provider_fingerprint(base.model):
            raise DomainError("backend_mismatch", "Active version was not approved for this backend/model.", 409)
        spec = apply_candidate(base, version["components"])
        budget = Budget(jev=self.settings.max_attempts, reflection=0, seconds=120)
        try:
            prediction = self.decision.predict(spec, state, budget)
        except DomainError as exc:
            self.store.audit(actor, "inference.failed", {"task_id": task_id, "version_id": active,
                            "state_hmac": self.store.state_hmac(state), "error_code": exc.code})
            raise
        self.store.audit(actor, "inference.completed", {"task_id": task_id, "version_id": active,
                         "state_hmac": self.store.state_hmac(state), "disposition": prediction.disposition,
                         "backend": prediction.backend, "usage": budget.snapshot()})
        return {"task_id": task_id, "version_id": active, **prediction.model_dump(),
                "authorization_to_act": False}

    def enqueue(self, task_id: str, request: JobRequest, key: str, actor: str) -> dict[str, Any]:
        """Validate configuration before accepting work that would consume money or holdout data."""
        base, _ = self.store.task(task_id)
        dataset = self.store.dataset(task_id, request.dataset_id)
        dataset.validate_labels(base)
        if self.settings.backend == "live" and not self.settings.allow_external_data:
            raise DomainError("external_data_disabled", "Enable external data transfer explicitly before submitting live work.", 409)
        if request.kind == "optimize" and self.settings.backend == "live":
            if not self.settings.reflection_model or not self.settings.reflection_api_key.get_secret_value():
                raise DomainError("reflection_unconfigured", "Configure a reflection model and credential before optimization.", 409)
        return self.store.enqueue(task_id, request, key, actor, self.settings.provider_fingerprint(base.model))

    def _evaluate_cases(self, spec: TaskSpec, rows: list[Example], budget: Budget) -> dict[str, Any]:
        metrics = []
        for row in rows:
            budget.check()
            try:
                result = self.decision.predict(spec, row.state, budget)
                metrics.append(score_example(spec, row, result))
            except ProviderError as exc:
                metrics.append(failed_example(spec, row, exc.code))
        return aggregate(spec, metrics)

    def work_once(self) -> dict[str, Any] | None:
        """Claim and execute one durable job in the worker, outside API request processing."""
        job = self.store.claim()
        if job is None:
            return None
        request = JobRequest.model_validate(job["request"])
        budget = Budget(request.max_jev_requests, request.max_reflection_requests,
                        request.max_seconds, lambda: self.store.is_cancelled(job["id"]))
        result: dict[str, Any] = {}
        try:
            base, _ = self.store.task(job["task_id"])
            if job["provider_fingerprint"] != self.settings.provider_fingerprint(base.model):
                raise DomainError("backend_mismatch", "Queued job backend differs from worker configuration.", 409)
            if self.settings.backend == "live" and not self.settings.allow_external_data:
                raise DomainError("external_data_disabled", "External data transfer is disabled.", 409)
            version = self.store.version(base.id, request.version_id)
            spec = apply_candidate(base, version["components"])
            data = self.store.dataset(base.id, request.dataset_id)
            data.validate_labels(base)
            budget.check()
            if request.kind == "optimize":
                require_gepa()  # Fail before any external invocation; never substitute a demo engine.
                reflection = DemoReflection() if self.settings.backend == "demo" else ReflectionProvider(self.settings)
                adapter = JevGEPAAdapter(base, self.decision, reflection, budget)
                result = run_gepa(base, version["components"], data.train, data.validation,
                                  adapter, request.max_metric_calls, request.seed)
                budget.check()
                components = result.pop("best_candidate")
                result["version_id"] = self.store.add_version(base.id, request.version_id, components,
                                                               "worker", job["id"])
                result["active_changed"] = False
            else:
                baseline_spec = None
                if job["baseline_id"] and job["baseline_id"] != request.version_id:
                    baseline_version = self.store.version(base.id, job["baseline_id"])
                    if baseline_version["provider_fingerprint"] != job["provider_fingerprint"]:
                        raise DomainError("baseline_backend", "The active baseline belongs to a different backend.", 409)
                    baseline_spec = apply_candidate(base, baseline_version["components"])
                calls_needed = len(data.test) * (2 if baseline_spec else 1)
                if self.settings.backend == "live" and request.max_jev_requests < calls_needed:
                    raise DomainError("insufficient_budget", "Request budget cannot cover final evaluation before retries.", 409)
                self.store.consume_holdout(base.id, data, job["id"])
                candidate_metrics = self._evaluate_cases(spec, data.test, budget)
                baseline_metrics = self._evaluate_cases(baseline_spec, data.test, budget) if baseline_spec else None
                gate = release_gate(base, candidate_metrics, baseline_metrics)
                if self.settings.backend == "live" and data.synthetic:
                    gate["passed"] = False
                    gate["failures"].append("synthetic_data_cannot_authorize_live_release")
                report = {
                    "task_id": base.id, "version_id": request.version_id,
                    "candidate_digest": version["digest"], "dataset_id": data.id,
                    "dataset_digest": digest(data.model_dump()), "backend": self.settings.backend,
                    "model": base.model, "synthetic": data.synthetic,
                    "candidate": candidate_metrics, "baseline": baseline_metrics,
                    "gate": gate, "usage": budget.snapshot(),
                    "test_usage": "single_use_paired_evaluation",
                    "interpretation": "Gate pass is finite-sample evidence, not a universal accuracy guarantee.",
                }
                budget.check()
                evaluation_id = self.store.save_evaluation(job, report)
                result = {"evaluation_id": evaluation_id, "report": report, "active_changed": False}
            result["usage"] = budget.snapshot()
            self.store.finish(job["id"], "succeeded", result)
        except Cancelled as exc:
            self.store.finish(job["id"], "cancelled", {"usage": budget.snapshot()}, exc.code)
        except DomainError as exc:
            self.store.finish(job["id"], "failed", {"usage": budget.snapshot()}, exc.code)
        except Exception as exc:
            # Unknown exceptions are not exposed; job ID + tests/local debugging isolate the failure.
            self.store.finish(job["id"], "failed", {"usage": budget.snapshot(), "error_type": type(exc).__name__}, "internal_error")
        return self.store.job(job["id"])
