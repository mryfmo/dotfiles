"""SQLite single-workspace registry, durable jobs and HMAC-chained audit records."""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import sqlite3
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterator

from .errors import DomainError
from .models import Dataset, JobRequest, TaskSpec, apply_candidate, canonical, digest, seed_candidate, state_fingerprint

SCHEMA = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tasks(
 id TEXT PRIMARY KEY,spec TEXT NOT NULL,active TEXT,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS versions(
 id TEXT PRIMARY KEY,task_id TEXT NOT NULL REFERENCES tasks(id),components TEXT NOT NULL,
 digest TEXT NOT NULL,parent TEXT REFERENCES versions(id),source TEXT NOT NULL,
 created TEXT NOT NULL,activated INTEGER NOT NULL DEFAULT 0,provider_fingerprint TEXT,
 UNIQUE(task_id,digest));
CREATE TABLE IF NOT EXISTS datasets(
 id TEXT PRIMARY KEY,task_id TEXT NOT NULL REFERENCES tasks(id),digest TEXT NOT NULL,
 payload TEXT NOT NULL,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS split_ledger(
 task_id TEXT NOT NULL REFERENCES tasks(id),fingerprint TEXT NOT NULL,split TEXT NOT NULL,
 PRIMARY KEY(task_id,fingerprint));
CREATE TABLE IF NOT EXISTS holdout_uses(
 task_id TEXT NOT NULL REFERENCES tasks(id),fingerprint TEXT NOT NULL,job_id TEXT NOT NULL,
 PRIMARY KEY(task_id,fingerprint));
CREATE TABLE IF NOT EXISTS jobs(
 id TEXT PRIMARY KEY,task_id TEXT NOT NULL REFERENCES tasks(id),request TEXT NOT NULL,
 idempotency_key TEXT NOT NULL,request_hash TEXT NOT NULL,status TEXT NOT NULL,
 baseline_id TEXT,provider_fingerprint TEXT NOT NULL,creator TEXT NOT NULL,
 created TEXT NOT NULL,started TEXT,finished TEXT,cancel_requested INTEGER NOT NULL DEFAULT 0,
 result TEXT,error_code TEXT,UNIQUE(task_id,idempotency_key));
CREATE UNIQUE INDEX IF NOT EXISTS one_pending_job_per_task
 ON jobs(task_id) WHERE status IN ('queued','running');
CREATE TABLE IF NOT EXISTS evaluations(
 id TEXT PRIMARY KEY,task_id TEXT NOT NULL REFERENCES tasks(id),version_id TEXT NOT NULL REFERENCES versions(id),
 job_id TEXT NOT NULL UNIQUE REFERENCES jobs(id),baseline_id TEXT,provider_fingerprint TEXT NOT NULL,
 report TEXT NOT NULL,passed INTEGER NOT NULL,created TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit(
 seq INTEGER PRIMARY KEY AUTOINCREMENT,at TEXT NOT NULL,actor TEXT NOT NULL,
 event TEXT NOT NULL,payload TEXT NOT NULL,previous TEXT NOT NULL,signature TEXT NOT NULL);
"""


def now() -> str:
    """Return explicit UTC ISO timestamps for all persisted events."""
    return datetime.now(timezone.utc).isoformat()


def new_id(prefix: str) -> str:
    """Generate filesystem-safe identifiers unrelated to user-controlled content."""
    return prefix + "_" + uuid.uuid4().hex


class Store:
    """One SQLite file per trust/workspace boundary; this is not a multi-tenant SaaS database."""

    def __init__(self, directory: Path, audit_key: str) -> None:
        self.directory = Path(directory)
        self.directory.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.path = self.directory / "registry.sqlite3"
        self.audit_key = audit_key.encode()
        with self.connection() as db:
            existing = db.execute("PRAGMA user_version").fetchone()[0]
            if existing not in (0, 1):
                raise DomainError("schema_version", "Unsupported database version; no changes were made.", 409)
            db.executescript(SCHEMA)
            db.execute("PRAGMA user_version=1")
            check = hmac.new(self.audit_key, b"jev-gepa-audit-key-check-v1", hashlib.sha256).hexdigest()
            row = db.execute("SELECT value FROM meta WHERE key='audit_key_check'").fetchone()
            if row and not hmac.compare_digest(row[0], check):
                raise DomainError("audit_key_mismatch", "Audit key differs from this workspace's key.", 409)
            db.execute("INSERT OR IGNORE INTO meta(key,value) VALUES('audit_key_check',?)", (check,))
        if os.name != "nt":
            self.path.chmod(0o600)

    def connect(self) -> sqlite3.Connection:
        """Use fresh connections: API threads and separate worker processes never share cursors."""
        db = sqlite3.connect(self.path, timeout=20, isolation_level=None)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        db.execute("PRAGMA journal_mode=WAL")
        db.execute("PRAGMA synchronous=FULL")
        db.execute("PRAGMA busy_timeout=20000")
        return db

    @contextmanager
    def connection(self) -> Iterator[sqlite3.Connection]:
        """Close read and bootstrap connections deterministically, not via garbage collection."""
        db = self.connect()
        try:
            yield db
        finally:
            db.close()

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        """Make each registry mutation and its audit append a single atomic transaction."""
        db = self.connect()
        try:
            db.execute("BEGIN IMMEDIATE")
            yield db
            db.commit()
        except BaseException:
            db.rollback()
            raise
        finally:
            db.close()

    def _audit(self, db: sqlite3.Connection, actor: str, event: str, payload: dict[str, Any]) -> None:
        previous_row = db.execute("SELECT signature FROM audit ORDER BY seq DESC LIMIT 1").fetchone()
        previous = previous_row[0] if previous_row else "0" * 64
        at, serialized = now(), canonical(payload)
        message = canonical([at, actor, event, serialized, previous]).encode()
        signature = hmac.new(self.audit_key, message, hashlib.sha256).hexdigest()
        db.execute("INSERT INTO audit(at,actor,event,payload,previous,signature) VALUES(?,?,?,?,?,?)",
                   (at, actor, event, serialized, previous, signature))

    def audit(self, actor: str, event: str, payload: dict[str, Any]) -> None:
        """Append metadata only; callers must not pass raw state, labels or credentials."""
        with self.transaction() as db:
            self._audit(db, actor, event, payload)

    def state_hmac(self, state: Any) -> str:
        """Audit input identity without exposing raw text or an unsalted low-entropy hash."""
        return hmac.new(self.audit_key, canonical(state).encode(), hashlib.sha256).hexdigest()

    def verify_audit(self) -> dict[str, Any]:
        """Verify stored records. Tail truncation needs an independently retained external anchor."""
        previous, count = "0" * 64, 0
        with self.connection() as db:
            for row in db.execute("SELECT * FROM audit ORDER BY seq"):
                message = canonical([row["at"], row["actor"], row["event"], row["payload"], previous]).encode()
                expected = hmac.new(self.audit_key, message, hashlib.sha256).hexdigest()
                if row["previous"] != previous or not hmac.compare_digest(row["signature"], expected):
                    return {"valid": False, "first_invalid_seq": row["seq"], "checked": count}
                previous, count = row["signature"], count + 1
        return {"valid": True, "checked": count, "head": previous}

    def audit_events(self, limit: int = 100) -> list[dict[str, Any]]:
        """Return recent metadata; no raw inference inputs are retained in audit."""
        with self.connection() as db:
            return [dict(r) for r in db.execute("SELECT * FROM audit ORDER BY seq DESC LIMIT ?", (limit,))]

    def create_task(self, spec: TaskSpec, actor: str) -> dict[str, Any]:
        """Register an immutable task and inactive seed version; never auto-promote."""
        components = seed_candidate(spec)
        version = "v_" + digest({"spec": spec.model_dump(), "components": components})[:32]
        with self.transaction() as db:
            if db.execute("SELECT 1 FROM tasks WHERE id=?", (spec.id,)).fetchone():
                raise DomainError("task_exists", "Task IDs are immutable; choose a new ID for policy changes.", 409)
            db.execute("INSERT INTO tasks(id,spec,created) VALUES(?,?,?)", (spec.id, canonical(spec.model_dump()), now()))
            db.execute("INSERT INTO versions(id,task_id,components,digest,source,created) VALUES(?,?,?,?,?,?)",
                       (version, spec.id, canonical(components), digest(components), "seed", now()))
            self._audit(db, actor, "task.created", {"task_id": spec.id, "version_id": version})
        return {"task_id": spec.id, "version_id": version, "active": None}

    def task(self, task_id: str) -> tuple[TaskSpec, str | None]:
        """Return a freshly validated immutable task contract and current active pointer."""
        with self.connection() as db:
            row = db.execute("SELECT * FROM tasks WHERE id=?", (task_id,)).fetchone()
        if not row:
            raise DomainError("not_found", "Task not found.", 404)
        return TaskSpec.model_validate_json(row["spec"]), row["active"]

    def tasks(self) -> list[dict[str, Any]]:
        """List workspace task metadata in deterministic order."""
        with self.connection() as db:
            return [{"id": r["id"], "title": json.loads(r["spec"])["title"], "active": r["active"]}
                    for r in db.execute("SELECT * FROM tasks ORDER BY id")]

    def version(self, task_id: str, version_id: str) -> dict[str, Any]:
        """Require task ownership for every version lookup to prevent cross-task references."""
        with self.connection() as db:
            row = db.execute("SELECT * FROM versions WHERE task_id=? AND id=?", (task_id, version_id)).fetchone()
        if not row:
            raise DomainError("not_found", "Version not found for this task.", 404)
        result = dict(row)
        result["components"] = json.loads(result["components"])
        if digest(result["components"]) != result["digest"]:
            raise DomainError("integrity", "Stored version digest does not match.", 409)
        return result

    def versions(self, task_id: str) -> list[dict[str, Any]]:
        """List candidate metadata without duplicating the full task specification."""
        self.task(task_id)
        with self.connection() as db:
            return [dict(r) for r in db.execute(
                "SELECT id,parent,source,created,activated,provider_fingerprint FROM versions WHERE task_id=? ORDER BY created",
                (task_id,))]

    def add_version(
        self, task_id: str, parent: str, components: dict[str, str], actor: str, source: str,
    ) -> str:
        """Persist only structurally valid candidates; identical content reuses its existing ID."""
        spec, _ = self.task(task_id)
        self.version(task_id, parent)
        apply_candidate(spec, components)
        hash_ = digest(components)
        version = "v_" + digest({"task": task_id, "components": components})[:32]
        with self.transaction() as db:
            existing = db.execute("SELECT id FROM versions WHERE task_id=? AND digest=?", (task_id, hash_)).fetchone()
            if existing:
                self._audit(db, actor, "candidate.reused", {"task_id": task_id, "version_id": existing[0], "source": source})
                return existing[0]
            db.execute("INSERT INTO versions(id,task_id,components,digest,parent,source,created) VALUES(?,?,?,?,?,?,?)",
                       (version, task_id, canonical(components), hash_, parent, source, now()))
            self._audit(db, actor, "candidate.created", {"task_id": task_id, "version_id": version, "parent": parent, "source": source})
        return version

    def add_dataset(self, dataset: Dataset, actor: str) -> dict[str, Any]:
        """Enforce split isolation across dataset revisions, not merely within one upload."""
        spec, _ = self.task(dataset.task_id)
        dataset.validate_labels(spec)
        with self.transaction() as db:
            if db.execute("SELECT 1 FROM datasets WHERE id=?", (dataset.id,)).fetchone():
                raise DomainError("dataset_exists", "Dataset IDs are immutable.", 409)
            for split in ("train", "validation", "test"):
                for row in getattr(dataset, split):
                    for fingerprint in ("s:" + state_fingerprint(row.state), "g:" + row.group):
                        existing = db.execute("SELECT split FROM split_ledger WHERE task_id=? AND fingerprint=?",
                                              (dataset.task_id, fingerprint)).fetchone()
                        if existing and existing[0] != split:
                            raise DomainError("split_leakage", "A state or group was previously assigned to another split.", 409)
                        db.execute("INSERT OR IGNORE INTO split_ledger VALUES(?,?,?)", (dataset.task_id, fingerprint, split))
            payload = dataset.model_dump()
            db.execute("INSERT INTO datasets VALUES(?,?,?,?,?)",
                       (dataset.id, dataset.task_id, digest(payload), canonical(payload), now()))
            self._audit(db, actor, "dataset.created", {"dataset_id": dataset.id, "task_id": dataset.task_id,
                        "digest": digest(payload), "synthetic": dataset.synthetic})
        return self.dataset_summary(dataset.id)

    def dataset(self, task_id: str, dataset_id: str) -> Dataset:
        """Read the local original dataset only within the same workspace/task."""
        with self.connection() as db:
            row = db.execute("SELECT * FROM datasets WHERE id=? AND task_id=?", (dataset_id, task_id)).fetchone()
        if not row:
            raise DomainError("not_found", "Dataset not found for this task.", 404)
        data = json.loads(row["payload"])
        if digest(data) != row["digest"]:
            raise DomainError("integrity", "Dataset digest does not match.", 409)
        return Dataset.model_validate(data)

    def dataset_summary(self, dataset_id: str) -> dict[str, Any]:
        """The API only exposes counts and hashes, not held-out labels or case-level outputs."""
        with self.connection() as db:
            row = db.execute("SELECT * FROM datasets WHERE id=?", (dataset_id,)).fetchone()
        if not row:
            raise DomainError("not_found", "Dataset not found.", 404)
        data = json.loads(row["payload"])
        return {"id": row["id"], "task_id": row["task_id"], "digest": row["digest"],
                "synthetic": data["synthetic"], "counts": {s: len(data[s]) for s in ("train", "validation", "test")}}

    def datasets(self, task_id: str) -> list[dict[str, Any]]:
        """List dataset metadata for a task."""
        self.task(task_id)
        with self.connection() as db:
            ids = [r[0] for r in db.execute("SELECT id FROM datasets WHERE task_id=? ORDER BY created", (task_id,))]
        return [self.dataset_summary(id_) for id_ in ids]

    def enqueue(self, task_id: str, request: JobRequest, key: str, actor: str, fingerprint: str) -> dict[str, Any]:
        """Idempotent durable queue insertion with a captured active baseline."""
        self.version(task_id, request.version_id)
        self.dataset(task_id, request.dataset_id)
        body_hash = digest(request.model_dump())
        job_id = new_id("job")
        with self.transaction() as db:
            prior = db.execute("SELECT * FROM jobs WHERE task_id=? AND idempotency_key=?", (task_id, key)).fetchone()
            if prior:
                if prior["request_hash"] != body_hash or prior["provider_fingerprint"] != fingerprint:
                    raise DomainError("idempotency_conflict", "Idempotency key was used for a different request or backend.", 409)
                return self._job_dict(prior)
            if db.execute("SELECT 1 FROM jobs WHERE task_id=? AND status IN ('queued','running')", (task_id,)).fetchone():
                raise DomainError("job_pending", "This task already has a queued/running job.", 409)
            if db.execute("SELECT count(*) FROM jobs WHERE status='queued'").fetchone()[0] >= 100:
                raise DomainError("queue_full", "The local job queue is full.", 429)
            baseline = db.execute("SELECT active FROM tasks WHERE id=?", (task_id,)).fetchone()[0]
            db.execute("""INSERT INTO jobs(id,task_id,request,idempotency_key,request_hash,status,
                       baseline_id,provider_fingerprint,creator,created) VALUES(?,?,?,?,?,'queued',?,?,?,?)""",
                       (job_id, task_id, canonical(request.model_dump()), key, body_hash, baseline, fingerprint, actor, now()))
            self._audit(db, actor, "job.queued", {"job_id": job_id, "task_id": task_id, "kind": request.kind})
        return self.job(job_id)

    @staticmethod
    def _job_dict(row: sqlite3.Row) -> dict[str, Any]:
        result = dict(row)
        result["request"] = json.loads(result["request"])
        result["result"] = json.loads(result["result"]) if result["result"] else None
        return result

    def job(self, job_id: str) -> dict[str, Any]:
        """Read job state, safe error code and aggregate result."""
        with self.connection() as db:
            row = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
        if not row:
            raise DomainError("not_found", "Job not found.", 404)
        return self._job_dict(row)

    def jobs(self, limit: int = 100) -> list[dict[str, Any]]:
        """List recent jobs for the workspace."""
        with self.connection() as db:
            return [self._job_dict(r) for r in db.execute("SELECT * FROM jobs ORDER BY created DESC LIMIT ?", (limit,))]

    def claim(self) -> dict[str, Any] | None:
        """Atomically claim a job once. Crashed jobs are never silently re-executed."""
        with self.transaction() as db:
            row = db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY created LIMIT 1").fetchone()
            if not row:
                return None
            db.execute("UPDATE jobs SET status='running',started=? WHERE id=?", (now(), row["id"]))
            self._audit(db, "worker", "job.started", {"job_id": row["id"]})
        return self.job(row["id"])

    def cancel(self, job_id: str, actor: str) -> dict[str, Any]:
        """Queued jobs cancel immediately; running jobs stop at the next bounded checkpoint."""
        with self.transaction() as db:
            row = db.execute("SELECT status FROM jobs WHERE id=?", (job_id,)).fetchone()
            if not row:
                raise DomainError("not_found", "Job not found.", 404)
            if row[0] == "queued":
                db.execute("UPDATE jobs SET status='cancelled',cancel_requested=1,finished=? WHERE id=?", (now(), job_id))
            elif row[0] == "running":
                db.execute("UPDATE jobs SET cancel_requested=1 WHERE id=?", (job_id,))
            else:
                raise DomainError("job_terminal", "This job has already finished.", 409)
            self._audit(db, actor, "job.cancel_requested", {"job_id": job_id})
        return self.job(job_id)

    def is_cancelled(self, job_id: str) -> bool:
        """Allow a worker to observe cancellation from another process."""
        return bool(self.job(job_id)["cancel_requested"])

    def finish(self, job_id: str, status: str, result: dict[str, Any], error_code: str | None = None) -> None:
        """Terminal transition only from running; interruption cannot be overwritten later."""
        if status not in {"succeeded", "failed", "cancelled"}:
            raise ValueError("invalid terminal status")
        with self.transaction() as db:
            row = db.execute("SELECT status,cancel_requested FROM jobs WHERE id=?", (job_id,)).fetchone()
            if row and row[0] == "interrupted":
                return  # An operator terminal state cannot be overwritten by a late worker.
            if not row or row[0] != "running":
                raise DomainError("job_transition", "Job is not running.", 409)
            if row[1] and status == "succeeded":
                status, error_code = "cancelled", "cancelled"
            db.execute("UPDATE jobs SET status=?,result=?,error_code=?,finished=? WHERE id=?",
                       (status, canonical(result), error_code, now(), job_id))
            self._audit(db, "worker", "job.finished", {"job_id": job_id, "status": status, "error_code": error_code})

    def interrupt(self, job_id: str, actor: str) -> None:
        """Operator recovery AFTER stopping the worker; never automatically requeue billable work."""
        with self.transaction() as db:
            row = db.execute("SELECT status FROM jobs WHERE id=?", (job_id,)).fetchone()
            if not row or row[0] != "running":
                raise DomainError("job_transition", "Only a running job may be marked interrupted.", 409)
            db.execute("UPDATE jobs SET status='interrupted',cancel_requested=1,finished=?,error_code='worker_interrupted' WHERE id=?", (now(), job_id))
            self._audit(db, actor, "job.interrupted", {"job_id": job_id})

    def consume_holdout(self, task_id: str, dataset: Dataset, job_id: str) -> None:
        """Consume states AND groups before evaluation, even if a later call fails.

        Prevents reusing a failed test by renaming/reordering a dataset or replacing
        just one case. Baseline and candidate are evaluated in this same one-time use.
        """
        fingerprints = {f for r in dataset.test for f in ("s:" + state_fingerprint(r.state), "g:" + r.group)}
        with self.transaction() as db:
            for fingerprint in fingerprints:
                if db.execute("SELECT 1 FROM holdout_uses WHERE task_id=? AND fingerprint=?", (task_id, fingerprint)).fetchone():
                    raise DomainError("holdout_consumed", "A held-out state/group has already been used. Supply a fresh independent test set.", 409)
            for fingerprint in fingerprints:
                db.execute("INSERT INTO holdout_uses VALUES(?,?,?)", (task_id, fingerprint, job_id))
            self._audit(db, "worker", "holdout.consumed", {"task_id": task_id, "job_id": job_id, "dataset_id": dataset.id, "cases": len(dataset.test)})

    def save_evaluation(self, job: dict[str, Any], report: dict[str, Any]) -> str:
        """Persist aggregate-only release evidence bound to exact candidate and baseline IDs."""
        evaluation_id = new_id("eval")
        with self.transaction() as db:
            current = db.execute("SELECT status,cancel_requested FROM jobs WHERE id=?", (job["id"],)).fetchone()
            if not current or current[0] != "running" or current[1]:
                raise DomainError("job_transition", "Cancelled/interrupted jobs cannot publish evaluation evidence.", 409)
            db.execute("INSERT INTO evaluations VALUES(?,?,?,?,?,?,?,?,?)",
                       (evaluation_id, job["task_id"], job["request"]["version_id"], job["id"],
                        job["baseline_id"], job["provider_fingerprint"], canonical(report), int(report["gate"]["passed"]), now()))
            self._audit(db, "worker", "evaluation.created", {"evaluation_id": evaluation_id, "job_id": job["id"], "passed": report["gate"]["passed"]})
        return evaluation_id

    def evaluation(self, task_id: str, evaluation_id: str) -> dict[str, Any]:
        """Read immutable aggregate evidence, never per-case held-out ground truth."""
        with self.connection() as db:
            row = db.execute("SELECT * FROM evaluations WHERE task_id=? AND id=?", (task_id, evaluation_id)).fetchone()
        if not row:
            raise DomainError("not_found", "Evaluation not found for this task.", 404)
        result = dict(row)
        result["report"] = json.loads(result["report"])
        return result

    def activate(
        self, task_id: str, version_id: str, evaluation_id: str, expected_active: str | None,
        actor: str, reason: str, fingerprint: str,
    ) -> dict[str, Any]:
        """Compare-and-swap release after all evidence, ownership and backend checks pass."""
        version = self.version(task_id, version_id)
        spec, _ = self.task(task_id)
        apply_candidate(spec, version["components"])
        with self.transaction() as db:
            active = db.execute("SELECT active FROM tasks WHERE id=?", (task_id,)).fetchone()[0]
            if active != expected_active:
                raise DomainError("active_conflict", "Active version changed; refresh before approval.", 409)
            e = db.execute("SELECT * FROM evaluations WHERE id=? AND task_id=? AND version_id=?",
                           (evaluation_id, task_id, version_id)).fetchone()
            if not e or not e["passed"]:
                raise DomainError("release_gate", "A passing evaluation bound to this candidate is required.", 409)
            if e["baseline_id"] != active or e["provider_fingerprint"] != fingerprint:
                raise DomainError("evidence_mismatch", "Evaluation baseline/backend no longer matches.", 409)
            job = db.execute("SELECT status FROM jobs WHERE id=?", (e["job_id"],)).fetchone()
            if not job or job[0] != "succeeded":
                raise DomainError("job_incomplete", "The evaluation job did not complete successfully.", 409)
            db.execute("UPDATE tasks SET active=? WHERE id=?", (version_id, task_id))
            db.execute("UPDATE versions SET activated=1,provider_fingerprint=? WHERE id=?", (fingerprint, version_id))
            self._audit(db, actor, "version.activated", {"task_id": task_id, "previous": active,
                        "version_id": version_id, "evaluation_id": evaluation_id, "reason": reason})
        return {"task_id": task_id, "active": version_id, "previous": active}

    def rollback(
        self, task_id: str, version_id: str, expected_active: str, actor: str,
        reason: str, fingerprint: str,
    ) -> dict[str, Any]:
        """Restore only a previously approved version from the same runtime backend."""
        version = self.version(task_id, version_id)
        if not version["activated"] or version["provider_fingerprint"] != fingerprint:
            raise DomainError("rollback_unapproved", "Rollback target must be previously approved for this backend.", 409)
        with self.transaction() as db:
            active = db.execute("SELECT active FROM tasks WHERE id=?", (task_id,)).fetchone()[0]
            if active != expected_active:
                raise DomainError("active_conflict", "Active version changed; refresh before rollback.", 409)
            db.execute("UPDATE tasks SET active=? WHERE id=?", (version_id, task_id))
            self._audit(db, actor, "version.rolled_back", {"task_id": task_id, "previous": active,
                        "version_id": version_id, "reason": reason})
        return {"task_id": task_id, "active": version_id, "previous": active}
