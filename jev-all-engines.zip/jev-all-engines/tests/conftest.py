"""Test-only fixtures. They are never registered as production engine fallbacks."""
from pathlib import Path
import json
import sys
import tempfile
import shutil
import pytest
from jev_fullstack.contracts import REQUIRED_ENGINES, Bundle, EngineResponse, GoalRequest
from jev_fullstack.runtime import DEFAULT_PROMPTS, Supervisor
from jev_fullstack.native.common import Bridge

ROOT=Path(__file__).resolve().parents[1]

@pytest.fixture
def workspace():
    # AF_UNIX addresses have a much lower path limit than ordinary files.
    p=Path(tempfile.mkdtemp(prefix='jae-',dir='/tmp'))
    yield p
    shutil.rmtree(p,ignore_errors=True)

@pytest.fixture
def settings(workspace):
    return {'project_root':str(ROOT),'workspace':str(workspace),
        'engines':{n:{'version':'test-contract-only','python':sys.executable,
                    'source':str(ROOT/'native_envs/sources'/n),'execution':'container' if n=='aflow' else 'process'} for n in REQUIRED_ENGINES},
        'services':{'llm':{'external':False,'model':'test-fixture','requires_key':False},
                    'jev':{'external':False,'model':'test-fixture','requires_key':False}},
        'models':{},'datasets':{},'authority':{'max_actions':500,'max_units':100000,'max_depth':3}}

@pytest.fixture
def bundle(settings):
    return Bundle(version='contract-test',engines={n:'test-contract-only' for n in REQUIRED_ENGINES},
        prompts=DEFAULT_PROMPTS,model_bindings={})

class ContractProviderFixture:
    """Supplies explicit fixture bytes, not real LLM/GEPA inference."""
    def __init__(self): self.calls=[]
    def close(self): pass
    def chat(self,body,timeout=120):
        self.calls.append(body)
        v=json.loads(body['messages'][-1]['content'])
        if 'request_sha256' not in v: raise AssertionError('unexpected model call in contract fixture')
        c={'request_sha256':v['request_sha256'],'goal':v['goal'],'requirements':v['requirements'],
           'requirement_map':{f'R{i+1}':'$.value' for i in range(len(v['requirements']))},
           'output_schema':{'type':'object','properties':{'value':{},'input_id':{'type':'string'}},
                            'required':['value','input_id'],'additionalProperties':False},'unknowns':[]}
        return {'choices':[{'message':{'role':'assistant','content':json.dumps(c,ensure_ascii=False)},'finish_reason':'stop'}]}

class ContractRunnerFixture:
    """Only supervisor contract tests use this fixture; it is not an engine."""
    def __init__(self,decision=None): self.decision=decision; self.calls=[]
    def is_isolated(self,engine): return False
    def call(self,request,timeout,cancelled):
        self.calls.append(request.engine)
        if request.engine=='ldp':
            v=json.loads(request.payload['messages'][-1]['content'])
            if self.decision: decision=self.decision(v)
            elif not v['observations']:
                did=v['inputs'][0]['id']
                decision={'kind':'act','action':{'capability':'compute.table',
                    'arguments':{'input_id':did,'operation':'sum','column':'x'},'input_refs':[did]}}
            else: decision={'kind':'finish','output':v['observations'][-1]['value'],
                            'evidence':[v['observations'][-1]['action_id']]}
            val={'decision':decision,'fixture':True}
        elif request.engine=='aviary':
            val={'result':Bridge(request.context).post('/internal/invoke',request.payload['action'])}
        else: raise AssertionError('engine is not supplied by this explicit fixture: '+request.engine)
        return EngineResponse(request_id=request.request_id,engine=request.engine,status='ok',value=val,
            provenance={'kind':'unit_contract_fixture_NOT_upstream_execution'})

@pytest.fixture
def supervisor(settings):
    s=Supervisor(settings,runner=ContractRunnerFixture(),services=ContractProviderFixture())
    yield s
    s.close()

def request(value=10,*,label='public',doc_id='table',**limits):
    return GoalRequest.model_validate({'goal':'数値を合計し、入力IDと値を返す',
        'requirements':['欠損をゼロに置き換えない'],
        'inputs':[{'id':doc_id,'classification':label,'content':[{'x':value},{'x':3}]}],
        'constraints':limits})


def native_certificate_fixture(store,bundle_id):
    """Simulate a pre-existing certificate ONLY for transaction-level unit tests."""
    with store._tx() as connection:
        connection.execute('INSERT OR REPLACE INTO native_attestations VALUES(?,?)',
                           (bundle_id,store._pack({'UNIT_TEST_CERTIFICATE_FIXTURE':True})))
