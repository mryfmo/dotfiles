"""Real ASGI API contracts; no background worker or native model is simulated here."""
from fastapi.testclient import TestClient
import pytest
from jev_fullstack.api import create_app

def test_api_requires_key(settings,monkeypatch):
    monkeypatch.delenv('JEV_API_TOKEN',raising=False)
    with pytest.raises(ValueError):create_app(settings)

def test_api_auth_readiness_and_absent_resources(settings,monkeypatch):
    token='api-contract-test-token-'+'x'*40;monkeypatch.setenv('JEV_API_TOKEN',token)
    with TestClient(create_app(settings)) as client:
        assert client.get('/healthz').json()['readiness']=='not_assessed'
        assert client.get('/runs/missing').status_code==401
        headers={'Authorization':'Bearer '+token}
        assert client.get('/runs/missing',headers=headers).status_code==404
        assert client.get('/runs/missing/events',headers=headers).status_code==404
        assert client.post('/runs/missing/cancel',headers=headers).status_code==404
        assert client.post('/runs',json={'goal':'do work'},headers=headers).status_code==409
