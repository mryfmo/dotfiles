"""Contract and authorization invariants; no external models are used."""
import copy
import math
import pytest
from pydantic import ValidationError
from jsonschema import ValidationError as SchemaError
from jev_fullstack.contracts import *
from jev_fullstack.policy import Authority,authorize,permitted
from jev_fullstack.registry import CAPABILITIES
from conftest import request

def test_all_eleven_are_mandatory(bundle):
    assert len(REQUIRED_ENGINES)==11
    b=bundle.model_dump(); b['engines'].pop('trace')
    with pytest.raises(ValidationError): Bundle.model_validate(b)

@pytest.mark.parametrize('extra',[{'fake':True},{'script':'rm -rf /'}])
def test_request_rejects_unknown_keys(extra):
    with pytest.raises(ValidationError): GoalRequest.model_validate({'goal':'g',**extra})

def test_input_ids_unique():
    with pytest.raises(ValidationError): GoalRequest.model_validate({'goal':'g','inputs':[{'id':'a','content':1},{'id':'a','content':2}]})

@pytest.mark.parametrize('v',[float('inf'),float('-inf'),float('nan')])
def test_nonfinite_serialization(v):
    with pytest.raises(ValueError): canonical({'v':v})

@pytest.mark.parametrize('limit,value',[('max_actions',0),('max_units',-1),('max_depth',11),('deadline_seconds',0)])
def test_limits_rejected(limit,value):
    with pytest.raises(ValidationError): request(**{limit:value})

def test_remote_reference_rejected():
    with pytest.raises(ValueError): validate_schema({'$ref':'https://example.com/secret'})

def test_nested_remote_reference_rejected():
    with pytest.raises(ValueError): validate_schema({'properties':{'x':{'$ref':'file:///etc/passwd'}}})

def test_generated_contract_cannot_drop_requirement():
    r=request(); c=GoalContract(request_sha256=digest(r),goal=r.goal,requirements=r.requirements,
      output_schema={'type':'object'},requirement_map={'R1':'$.value'})
    c.bind(r)
    with pytest.raises(ValueError): c.model_copy(update={'requirements':()}).bind(r)
    with pytest.raises(ValueError): c.model_copy(update={'requirement_map':{}}).bind(r)

@pytest.mark.parametrize('kind,action',[('act',None),('finish',{'capability':'compute.table','arguments':{}})])
def test_decision_shape(kind,action):
    with pytest.raises(ValidationError): Decision(kind=kind,action=action)

@pytest.mark.parametrize('label',['internal','restricted'])
def test_nonpublic_never_egresses(label):
    with pytest.raises(PermissionError): authorize(CAPABILITIES['llm.reason'],None,
       request(label=label,allow_external=True),Authority(allow_external=True),'execute',0)

@pytest.mark.parametrize('operator,client',[(False,False),(False,True),(True,False)])
def test_both_external_permissions_required(operator,client):
    with pytest.raises(PermissionError): authorize(CAPABILITIES['llm.reason'],None,
        request(allow_external=client),Authority(allow_external=operator),'execute',0)

def test_improvement_can_use_llm_but_not_reverse():
    r=request(allow_external=True)
    authorize(CAPABILITIES['llm.reason'],None,r,Authority(allow_external=True),'improve',0)
    with pytest.raises(PermissionError): authorize(CAPABILITIES['gepa.optimize'],None,r,Authority(),'execute',0)

def test_autoskill_one_input_optional_alternative():
    a=Action(capability='autoskill.ingest',arguments={'messages':[{'role':'user','content':'rule'}]})
    authorize(CAPABILITIES[a.capability],a,request(),Authority(),'improve',0)

def test_unknown_argument_rejected():
    a=Action(capability='compute.table',arguments={'input_id':'table','operation':'count','run_shell':True})
    with pytest.raises(SchemaError): authorize(CAPABILITIES[a.capability],a,request(),Authority(),'execute',0)

def test_reference_and_delegation_rejected():
    a=Action(capability='compute.table',arguments={'input_id':'table','operation':'count'},input_refs=('foreign',))
    with pytest.raises(PermissionError): authorize(CAPABILITIES[a.capability],a,request(),Authority(),'execute',0)
    with pytest.raises(PermissionError): authorize(CAPABILITIES[a.capability],None,request(max_depth=0),Authority(),'execute',1)

def test_aflow_requires_enforced_sandbox():
    with pytest.raises(PermissionError): authorize(CAPABILITIES['aflow.execute'],None,request(),Authority(),'execute',0)

def test_registered_set_and_permitted_subset():
    assert {c.engine for c in CAPABILITIES.values()} >= REQUIRED_ENGINES
    allowed={c.id for c in permitted(CAPABILITIES.values(),request(allowed_capabilities=('source.read',)),Authority(),'execute',0)}
    assert allowed=={'source.read','ldp.decide','aviary.execute'}
