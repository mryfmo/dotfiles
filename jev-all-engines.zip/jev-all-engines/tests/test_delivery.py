"""Delivery-integrity tests, not native-model performance evidence."""
import importlib.util
import json
from pathlib import Path
import sys
import zipfile
import pytest

ROOT=Path(__file__).resolve().parents[1]

def script(name):
    spec=importlib.util.spec_from_file_location('delivery_'+name,ROOT/'scripts'/f'{name}.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

PACKAGE=script('package');VERIFY=script('verify_package')

@pytest.fixture
def project(tmp_path):
    root=tmp_path/'project';root.mkdir()
    required={'README_ja.md':'test','pyproject.toml':'[project]\nname="test"',
        'configs/engines.lock.json':'{}','src/jev_fullstack/runtime.py':'# integrity fixture',
        'scripts/verify_native_all.py':'# integrity fixture','scripts/verify_package.py':'# integrity fixture',
        'reports/native-acceptance.json':'{"status":"failed"}'}
    for name,text in required.items():
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
    return root


def test_delivery_roundtrip(project,tmp_path):
    info=PACKAGE.build(project,tmp_path/'a.zip')
    verified=VERIFY.verify(tmp_path/'a.zip',tmp_path/'unpacked')
    assert verified['verified'] and verified['sha256']==info['sha256']
    assert (tmp_path/'unpacked/jev-all-engines/src/jev_fullstack/runtime.py').read_bytes()==(project/'src/jev_fullstack/runtime.py').read_bytes()


def test_delivery_deterministic(project,tmp_path):
    a=PACKAGE.build(project,tmp_path/'a.zip');b=PACKAGE.build(project,tmp_path/'b.zip')
    assert a['sha256']==b['sha256']


def test_delivery_excludes_runtime_secrets(project,tmp_path):
    (project/'workspace').mkdir();(project/'workspace/master.key').write_text('secret')
    (project/'.env').write_text('SECRET=private')
    info=PACKAGE.build(project,tmp_path/'a.zip')
    with zipfile.ZipFile(info['path']) as z:
        assert not any(n.endswith('master.key') or n.endswith('/.env') for n in z.namelist())


def test_delivery_rejects_source_symlink(project,tmp_path):
    (project/'src/escape.py').symlink_to(project/'README_ja.md')
    with pytest.raises(ValueError,match='symlink'):PACKAGE.build(project,tmp_path/'a.zip')


def test_delivery_rejects_tampered_content(project,tmp_path):
    PACKAGE.build(project,tmp_path/'a.zip')
    with zipfile.ZipFile(tmp_path/'a.zip') as src,zipfile.ZipFile(tmp_path/'bad.zip','w') as dst:
        for name in src.namelist():dst.writestr(name,b'tampered' if name.endswith('/runtime.py') else src.read(name))
    with pytest.raises(ValueError,match='checksum'):VERIFY.verify(tmp_path/'bad.zip')


def test_delivery_refuses_existing_extract_target(project,tmp_path):
    PACKAGE.build(project,tmp_path/'a.zip')
    with pytest.raises(FileExistsError):VERIFY.verify(tmp_path/'a.zip',tmp_path)


def test_delivery_rejects_path_traversal(tmp_path):
    with zipfile.ZipFile(tmp_path/'bad.zip','w') as z:z.writestr('jev-all-engines/../../escape','bad')
    with pytest.raises(ValueError,match='unsafe'):VERIFY.verify(tmp_path/'bad.zip')


def test_delivery_does_not_relabel_native_failure(project,tmp_path):
    PACKAGE.build(project,tmp_path/'a.zip')
    with zipfile.ZipFile(tmp_path/'a.zip') as z:
        result=json.loads(z.read('jev-all-engines/reports/native-acceptance.json'))
    assert result['status']=='failed'
