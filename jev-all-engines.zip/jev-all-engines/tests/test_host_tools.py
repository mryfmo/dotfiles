"""Exact table operations, source continuity, and missing-value semantics."""
import pytest
from jev_fullstack.contracts import GoalRequest
from jev_fullstack.host_tools import execute,MissingValue

def req(data):return GoalRequest.model_validate({'goal':'table operation','inputs':[{'id':'t','content':data}]})

@pytest.mark.parametrize('op,args,expected',[
 ('sum',{'column':'x'},6),('mean',{'column':'x'},3),('count',{},2),
 ('group_sum',{'column':'x','group_by':'g'},{'a':6})])
def test_exact_aggregation(op,args,expected):
    result=execute('compute',{'input_id':'t','operation':op,**args},req([{'x':2,'g':'a'},{'x':4,'g':'a'}]))
    assert result['value']==expected

def test_filter_then_count_uses_recorded_observation():
    r=req([{'x':2},{'x':4},{'x':2}])
    filtered=execute('compute',{'input_id':'t','operation':'filter','column':'x','equals':2},r)
    obs=[{'action_id':'filter-step','status':'ok','value':filtered}]
    result=execute('compute',{'input_id':'filter-step','operation':'count'},r,observations=obs)
    assert result=={'value':2,'input_id':'filter-step'}
    with pytest.raises(KeyError):execute('compute',{'input_id':'some-other-run','operation':'count'},r,observations=obs)

@pytest.mark.parametrize('rows',[[{'x':None}],[{}]])
def test_missing_does_not_become_zero(rows):
    with pytest.raises(MissingValue):execute('compute',{'input_id':'t','operation':'sum','column':'x'},req(rows))

@pytest.mark.parametrize('value',[True,'2',float('inf')])
def test_not_a_numeric_measure(value):
    if value==float('inf'):
        # Domain validation forbids non-JSON infinity before execution.
        with pytest.raises(ValueError):req([{'x':value}])
    else:
        with pytest.raises(ValueError):execute('compute',{'input_id':'t','operation':'sum','column':'x'},req([{'x':value}]))

def test_empty_mean_is_unknown_and_count_zero():
    with pytest.raises(MissingValue):execute('compute',{'input_id':'t','operation':'mean','column':'x'},req([]))
    assert execute('compute',{'input_id':'t','operation':'count'},req([]))['value']==0

def test_sort_and_raw_reference():
    r=req([{'x':4},{'x':2}])
    assert execute('read',{'input_id':'t'},r)['content']==[{'x':4},{'x':2}]
    assert execute('compute',{'input_id':'t','operation':'sort','column':'x'},r)['rows']==[{'x':2},{'x':4}]
