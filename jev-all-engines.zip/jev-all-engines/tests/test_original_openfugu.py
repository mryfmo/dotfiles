"""Run the byte-verified, unmodified upstream Conductor module through real IPC.

Planner/worker responses below are explicit fixtures. This is native algorithm
integration, not a learned-router, general-purpose LLM or end-to-end acceptance test.
"""
import copy
import hashlib
import json
from pathlib import Path
import sys
import time
import pytest
from jev_fullstack.container_rpc import NativeRunner
from jev_fullstack.contracts import NativeRequest
from jev_fullstack.gateway import Gateway,Scope
from conftest import ROOT

SOURCE=ROOT/'third_party/source_modules/openfugu'
BLOB='4ec8991c20dff610de0007ce46f35dadf96cfbc8'

@pytest.fixture
def original_config(settings):
    settings['engines']['openfugu'].update(source=str(SOURCE),python=sys.executable,source_paths=['.'],
        repo='trotsky1997/OpenFugu',revision='7ad7ccf977c1b5f38bbd07ba33d86fe655c17be8',
        source_snapshot={'revision':'7ad7ccf977c1b5f38bbd07ba33d86fe655c17be8',
                         'files':{'openfugu/ultra.py':BLOB},'operations':['compose']})
    return settings

def invoke(original_config,workspace,plan):
    calls=[]
    def callback(scope,path,payload):
        if path=='/v1/chat/completions':
            return {'choices':[{'message':{'content':plan},'finish_reason':'stop'}]}
        assert path=='/internal/subtask'
        calls.append(payload)
        return {'status':'ok','value':{'fixture_result':len(calls)*11}}
    g=Gateway(callback,socket_path=workspace/'fugu.sock')
    scope=Scope('r','w',1,0,'execute',frozenset({'llm.reason'}),time.time()+30)
    ctx={'gateway_url':g.url,'gateway_unix_socket':g.socket_path,'gateway_token':g.issue(scope),
         'workspace':str(workspace/'native'),'allowed_capabilities':['llm.reason'],'timeout':10}
    try:
        r=NativeRunner(ROOT,original_config).call(NativeRequest(request_id='original-fugu',engine='openfugu',operation='compose',
             payload={'goal':'two dependent subtasks','slots':[{'capability':'llm.reason','description':'test worker'}]},context=ctx),timeout=15)
        return r,calls
    finally:g.close()

def test_complete_module_matches_upstream_git_blob():
    raw=(SOURCE/'openfugu/ultra.py').read_bytes()
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==BLOB
    assert len(raw)==18901

def test_original_dag_executor_real_process_and_gateway(original_config,workspace):
    r,calls=invoke(original_config,workspace,'model_id: [0,0]\nsubtasks: ["derive", "verify"]\naccess_list: [[],[0]]')
    assert r.status=='ok',r.model_dump()
    assert len(r.value['steps'])==2 and len(calls)==2
    assert r.value['steps'][1]['sees']==[0]
    assert '11' in calls[1]['context'][0]['content']
    assert '22' in r.value['final']
    assert r.provenance['source_identity']['files']['openfugu/ultra.py']==BLOB

@pytest.mark.parametrize('plan',[
 'model_id: [4]\nsubtasks: ["bad id"]\naccess_list: [[]]',
 'model_id: [0,0]\nsubtasks: ["first","last"]\naccess_list: [[1],[]]',
 'model_id: [0,0,0,0,0,0]\nsubtasks: ["a","b","c","d","e","f"]\naccess_list: [[],[],[],[],[],[]]',
 'model_id: [0]\nsubtasks: ["a","b"]\naccess_list: [[]]',
])
def test_invalid_dag_never_starts_worker(original_config,workspace,plan):
    r,calls=invoke(original_config,workspace,plan)
    assert r.status=='error' and not calls

def test_verified_module_is_not_claimed_as_router(original_config,workspace):
    req=NativeRequest(request_id='missing-mini',engine='openfugu',operation='route',payload={},context={'workspace':str(workspace/'native')})
    r=NativeRunner(ROOT,original_config).call(req)
    assert r.status=='blocked' and 'does not contain' in r.error

def test_tampered_upstream_code_blocked(original_config,workspace):
    source=workspace/'source';(source/'openfugu').mkdir(parents=True)
    (source/'openfugu/ultra.py').write_bytes((SOURCE/'openfugu/ultra.py').read_bytes()+b'\n# altered')
    original_config['engines']['openfugu']['source']=str(source)
    r,calls=invoke(original_config,workspace,'model_id:[0]\nsubtasks:["x"]\naccess_list:[[]]')
    assert r.status=='error' and 'blob mismatch' in r.error and not calls
