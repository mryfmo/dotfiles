"""Exercise the real supervisor/state/gateway using explicitly labelled model fixtures.

These tests do NOT claim execution of the LDP/GEPA models or other upstream engines.
"""
import copy
import json
import pytest
from jev_fullstack.contracts import Action,GoalRequest,digest
from jev_fullstack.evaluation import EvaluationManager
from jev_fullstack.runtime import Supervisor
from jev_fullstack.state import Conflict
from conftest import request,ContractRunnerFixture,ContractProviderFixture,native_certificate_fixture

def test_goal_action_observation_finish(supervisor):
    b=supervisor.seed();out=supervisor.run(supervisor.submit(request(),b))
    assert out['status']=='succeeded'
    assert out['state']['output']=={'value':13,'input_id':'table'}
    assert supervisor.runner.calls==['ldp','aviary','ldp']
    assert out['state']['semantic_acceptance']=='requires_independent_evaluation'
    assert len(out['operations'])==5 and all(o['status']=='complete' for o in out['operations'])
    assert not out['state']['authorization_to_act']

def test_repeated_decision_bounded(settings):
    def repeat(v):return {'kind':'act','action':{'capability':'compute.table','arguments':{'input_id':'table','operation':'count'}}}
    s=Supervisor(settings,runner=ContractRunnerFixture(repeat),services=ContractProviderFixture())
    try:
        out=s.run(s.submit(request(),s.seed()))
        assert out['status']=='failed' and 'repeated' in out['state']['error']['detail']
        assert out['calls']<20
    finally:s.close()

def test_unknown_capability_never_executed(settings):
    s=Supervisor(settings,runner=ContractRunnerFixture(lambda v:{'kind':'act','action':{'capability':'unregistered.shell','arguments':{}}}),services=ContractProviderFixture())
    try:
        out=s.run(s.submit(request(),s.seed()))
        assert out['status']=='failed' and s.runner.calls==['ldp']
        assert out['state']['error']['type']=='PermissionError'
    finally:s.close()

def test_fabricated_evidence_rejected(settings):
    dec=lambda v:{'kind':'finish','output':{'value':13,'input_id':'table'},'evidence':['made-up-id']}
    s=Supervisor(settings,runner=ContractRunnerFixture(dec),services=ContractProviderFixture())
    try:
        out=s.run(s.submit(request(),s.seed()))
        assert out['status']=='failed' and 'fabricated' in out['state']['error']['detail']
    finally:s.close()

def test_budget_enforced_before_extra_model_calls(supervisor):
    out=supervisor.run(supervisor.submit(request(max_units=8),supervisor.seed()))
    assert out['status']=='failed' and out['units']==8
    assert len(supervisor.services.calls)==1

def test_pending_crash_does_not_duplicate(supervisor):
    b=supervisor.seed();rid=supervisor.submit(request(),b);f=supervisor.store.claim(rid,'crashed',lease_seconds=.01)
    supervisor.store.reserve(rid,'crashed',f,{'effect':'already possibly performed'},1)
    import time;time.sleep(.03)
    out=supervisor.run(rid)
    assert out['status']=='failed' and out['operations'][0]['status']=='outcome_unknown'
    assert not supervisor.runner.calls and not supervisor.services.calls

def test_sticky_classification_blocks_empty_input_egress(supervisor):
    b=supervisor.seed();rid=supervisor.submit(request(),b);f=supervisor.store.claim(rid,'w')
    supervisor.store.record_lineage(rid,[],'restricted')
    row=supervisor.store.get(rid);r=supervisor._policy_request(row)
    assert r.inputs[0].classification.value=='restricted'
    assert supervisor.store.get(rid)['state']['request']['inputs'][0]['classification']=='public'

def test_bundle_rejects_model_binding_drift(supervisor):
    b=supervisor.seed();supervisor.settings['services']['llm']['model']='another-model'
    with pytest.raises(ValueError):supervisor.submit(request(),b)

def example(i,split,value):
    return {'id':f'{split}-{i}','group':f'{split}-{i}','request':request(value).model_dump(mode='json'),
            'expected':{'value':value+3,'input_id':'table'}}

def test_full_host_evaluation_promotion_reuse_rollback(supervisor):
    a=supervisor.seed();b=a.model_copy(update={'version':'candidate-v2','parent':a.sha256,
      'prompts':{**a.prompts,'select':a.prompts['select']+' 型を確認する。'}})
    supervisor.store.add_bundle(b)
    data={sp:{'split':sp,'examples':[example(1,sp,v)]} for sp,v in [('train',10),('validation',20),('test',30)]}
    e=EvaluationManager(supervisor,data)
    assert 'expected' not in e.examples('train')[0]
    with pytest.raises(PermissionError):e.examples('test')
    report=e.verify(b,'test',baseline=a)
    assert report['passed'] and report['accuracy']==1
    baseline_eid=supervisor.store.record_evaluation(a.sha256,None,{'split':'test','passed':True,
        'run_ids':[r['run_id'] for r in report['baseline']]})
    supervisor.store.attest(a.sha256,baseline_eid)
    native_certificate_fixture(supervisor.store,a.sha256)
    native_certificate_fixture(supervisor.store,b.sha256)
    supervisor.promote(a.sha256,None)
    supervisor.promote(b.sha256,a.sha256)
    next_run=supervisor.run(supervisor.submit(request(45)))
    assert next_run['state']['bundle_sha256']==b.sha256 and next_run['state']['output']['value']==48
    supervisor.promote(a.sha256,b.sha256)
    assert supervisor.store.active()==a.sha256
    with pytest.raises(ValueError):e.verify(b,'test',baseline=a)

def test_optimizer_cannot_rewrite_evaluator_keys(supervisor):
    e=EvaluationManager(supervisor,{'train':{'split':'train','examples':[example(1,'train',91)]}})
    b=supervisor.seed()
    with pytest.raises(ValueError):e._candidate(b,{**b.prompts,'passing_score':'0'})
    with pytest.raises(ValueError):e._candidate(b,{k:'' for k in b.prompts})

def test_holdout_exact_reference_catches_wrong_answer(supervisor):
    ex=example(1,'test',71);ex['expected']['value']=999
    e=EvaluationManager(supervisor,{'test':{'split':'test','examples':[ex]}})
    b=supervisor.seed();report=e.verify(b,'test')
    assert not report['passed'] and report['accuracy']==0
    with pytest.raises(PermissionError):supervisor.promote(b.sha256,None)

def test_improvement_consumes_parent_budget(supervisor):
    e=EvaluationManager(supervisor,{'train':{'split':'train','examples':[example(1,'train',81)]}})
    b=supervisor.seed();rid=supervisor.submit(request(20),b);f=supervisor.store.claim(rid,'o')
    scope=supervisor._scope(rid,'o',f,phase='improve')
    out=e.evaluate_candidate({'dataset_id':'train','candidate':b.prompts},scope)
    assert out['score']==1 and supervisor.store.get(rid)['calls']>0
    child=supervisor.store.get(out['items'][0]['run_id'])
    assert child['parent_id']==rid
