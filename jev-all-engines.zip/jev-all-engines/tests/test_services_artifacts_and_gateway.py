"""HTTP wire validation, immutable artifacts, scoped callbacks and portable settings."""
import copy
import hashlib
import http.client
import json
import os
from pathlib import Path
import sys
import time
import httpx
import pytest
from jev_fullstack.artifacts import ArtifactStore
from jev_fullstack.contracts import digest
from jev_fullstack.gateway import Gateway,Scope
from jev_fullstack.native.common import Bridge,NativeBlocked,model_directory
from jev_fullstack.services import ModelServices,ProviderFailure
from jev_fullstack.settings import load_settings

@pytest.fixture
def model_settings(settings):
    settings=copy.deepcopy(settings)
    settings['services']['llm']={'endpoint':'https://example.invalid/chat','model':'controller-fixed',
        'external':True,'requires_key':False,'routes':{'expert-a':{'model':'expert-fixed-a'}},'require_response_model':True}
    return settings

def transport_service(settings,handler):
    s=ModelServices(settings);s.client.close();s.client=httpx.Client(transport=httpx.MockTransport(handler),follow_redirects=False)
    return s

def test_trusted_model_binding_reaches_wire(model_settings):
    seen=[]
    def handler(r):
        v=json.loads(r.content);seen.append(v)
        return httpx.Response(200,json={'model':v['model'],'choices':[{'finish_reason':'stop','message':{'content':'ok'}}]})
    s=transport_service(model_settings,handler)
    try:
        s.chat({'model':'expert-a','messages':[],'endpoint':'https://attacker.invalid','max_tokens':999999})
        assert seen[0]['model']=='expert-fixed-a' and seen[0]['max_tokens']==4096
        assert 'endpoint' not in seen[0]
        with pytest.raises(ProviderFailure):s.chat({'model':'unregistered','messages':[]})
        assert len(seen)==1
    finally:s.close()

@pytest.mark.parametrize('status',[302,400,401,403,429,500,529])
def test_provider_failure_does_not_silently_retry(model_settings,status):
    calls=[]
    def handler(r): calls.append(r);return httpx.Response(status,text='secret provider body')
    s=transport_service(model_settings,handler)
    try:
        with pytest.raises(ProviderFailure) as e:s.chat({'messages':[]})
        assert len(calls)==1 and 'secret' not in str(e.value)
        assert e.value.retryable==(status in (429,500,529))
    finally:s.close()

@pytest.mark.parametrize('case',['malformed','oversized','wrong_model','truncated','missing_text'])
def test_provider_contract_violation(model_settings,case):
    value={'model':'controller-fixed','choices':[{'finish_reason':'stop','message':{'content':'ok'}}]}
    if case=='wrong_model':value['model']='new-alias'
    if case=='truncated':value['choices'][0]['finish_reason']='length'
    if case=='missing_text':value['choices'][0]['message']['content']=None
    res=httpx.Response(200,text='not-json') if case=='malformed' else httpx.Response(200,text='x'*2000001) if case=='oversized' else httpx.Response(200,json=value)
    s=transport_service(model_settings,lambda r:res)
    try:
        with pytest.raises(ProviderFailure):s.chat({'messages':[]})
    finally:s.close()

def test_missing_key_blocks_before_http(model_settings,monkeypatch):
    model_settings['services']['llm'].update(requires_key=True,api_key_env='NONEXISTENT_JEV_TEST_KEY')
    monkeypatch.delenv('NONEXISTENT_JEV_TEST_KEY',raising=False)
    s=transport_service(model_settings,lambda r:pytest.fail('must not contact provider'))
    try:
        with pytest.raises(ProviderFailure,match='credential_missing'):s.chat({'messages':[]})
    finally:s.close()

def test_real_jev_decoder_enforces_response(model_settings):
    model_settings['services']['jev']={'endpoint':'https://example.invalid/jev','model':'jev-1.13.0','requires_key':False}
    args={'state':'解約しません','questions':{'cancel':{'type':'choice','instructions':'解約を希望するか','criteria':{'yes':'希望する','no':'希望しない'}}}}
    response={'model':'jev-1.13.0','answers':{'cancel':{'type':'choice','choice':'no','confidence':.95,'probabilities':{'yes':.01,'no':.99}}},'usage':{'input_tokens':20,'output_tokens':0}}
    s=transport_service(model_settings,lambda r:httpx.Response(200,json=response))
    try:
        result=s.jev(args)
        assert result['answers']['cancel']['choice']=='no' and result['authorization_to_act'] is False
        response['answers']['cancel']['choice']='yes'
        with pytest.raises(ProviderFailure):s.jev(args)
    finally:s.close()

def test_gateway_scope_revocation_and_http(workspace):
    calls=[];g=Gateway(lambda scope,path,data:calls.append((scope.run_id,path,data)) or {'ok':True},socket_path=workspace/'g.sock')
    scope=Scope('run','owner',1,0,'execute',frozenset({'x'}),time.time()+10)
    token=g.issue(scope);ctx={'gateway_url':g.url,'gateway_unix_socket':g.socket_path,'gateway_token':token,'timeout':3}
    try:
        assert Bridge(ctx).post('/registered',{'x':1})=={'ok':True}
        http_ctx={**ctx};http_ctx.pop('gateway_unix_socket')
        assert Bridge(http_ctx).post('/registered',{'x':2})=={'ok':True}
        g.revoke(token)
        with pytest.raises(PermissionError):Bridge(ctx).post('/registered',{})
        assert len(calls)==2
    finally:g.close()
    assert not (workspace/'g.sock').exists()

def test_artifact_capture_use_tamper_and_revoke(workspace):
    store=ArtifactStore(workspace);src=workspace/'candidate';src.mkdir();(src/'SKILL.md').write_text('単位を保つ')
    aid=store.capture(src,allowed_root=workspace,kind='skills',run_id='r',operation_id='o',input_fingerprints=['fp'],classification='restricted')
    dest,manifest=store.resolve(aid);assert (dest/'SKILL.md').read_text()=='単位を保つ'
    (dest/'SKILL.md').write_text('changed')
    with pytest.raises(ValueError):store.resolve(aid)
    assert aid in store.revoke_input('fp')
    with pytest.raises(PermissionError):store.resolve(aid)

def test_artifact_symlink_escape(workspace):
    a=ArtifactStore(workspace);src=workspace/'candidate';src.mkdir();(src/'escape').symlink_to('/etc/passwd')
    with pytest.raises(ValueError):a.capture(src,allowed_root=workspace,kind='skills',run_id='r',operation_id='o',input_fingerprints=[],classification='public')

def test_model_checkpoint_hash_mismatch_and_path_escape(workspace):
    model=workspace/'model';model.mkdir();(model/'config.json').write_text('{}')
    ctx={'models':{'m':{'path':str(model),'files':{'config.json':hashlib.sha256(b'{}').hexdigest()}}}}
    assert model_directory(ctx,'m')==str(model)
    (model/'config.json').write_text('{"changed":true}')
    with pytest.raises(NativeBlocked):model_directory(ctx,'m')
    ctx['models']['m']['files']={'../secret':'x'}
    with pytest.raises(NativeBlocked):model_directory(ctx,'m')

def test_venv_symlink_is_not_resolved(settings,workspace):
    bin=workspace/'v/bin';bin.mkdir(parents=True);py=bin/'python';py.symlink_to(sys.executable)
    settings['engines']['ldp']['python']=str(py)
    p=workspace/'config.json';p.write_text(json.dumps(settings))
    assert load_settings(p)['engines']['ldp']['python']==str(py)

@pytest.mark.parametrize('mod',[{'api_key':'secret'},{'endpoint':'http://remote.invalid/a'},{'endpoint':'https://user:pass@remote.invalid'},{'endpoint':'https://remote.invalid','external':False}])
def test_invalid_service_bindings(settings,workspace,mod):
    settings['services']['llm'].update(mod);p=workspace/'c.json';p.write_text(json.dumps(settings))
    with pytest.raises(ValueError):load_settings(p)

def test_nested_route_tls_and_keys(settings,workspace):
    settings['services']['llm']['routes']={'x':{'model':'x','endpoint':'http://remote.invalid'}}
    p=workspace/'c.json';p.write_text(json.dumps(settings))
    with pytest.raises(ValueError):load_settings(p)

def test_long_workdir_keeps_private_unix_socket(workspace):
    long=workspace/('p'*80)/('q'*80)/'gateway.sock'
    g=Gateway(lambda s,p,d:{'ok':True},socket_path=long)
    actual=Path(g.socket_path)
    try:
        assert len(os.fsencode(g.socket_path))<100
        assert actual.parent.stat().st_mode & 0o777==0o700
        assert actual.stat().st_mode & 0o777==0o600
        token=g.issue(Scope('r','o',1,0,'execute',frozenset(),time.time()+10))
        assert Bridge({'gateway_unix_socket':g.socket_path,'gateway_token':token}).post('/test',{})=={'ok':True}
    finally:g.close()
    assert not actual.exists()
