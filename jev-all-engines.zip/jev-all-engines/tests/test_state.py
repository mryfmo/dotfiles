"""Real SQLite transactions, process contention, fencing and release evidence."""
import concurrent.futures
import copy
import hashlib
import sqlite3
import multiprocessing
import time
import pytest
from jev_fullstack.state import Store,Conflict,BudgetExceeded
from jev_fullstack.contracts import digest
from conftest import request,native_certificate_fixture

def competing_claim(args):
    root,rid,owner=args
    try:return Store(root).claim(rid,owner)
    except Conflict:return 'conflict'

def reserve_from_process(args):
    root,rid,owner,fence=args
    try: Store(root).reserve(rid,owner,fence,{'operation':'test'},1);return True
    except BudgetExceeded:return False

def completed(s,b,r):
    rid=s.create(r,b);f=s.claim(rid,'test');row=s.get(rid)
    row['state']['output']={'value':13};s.save(rid,'test',f,row['revision'],row['state'],'succeeded')
    return rid

def test_encrypted_state_and_integrity(workspace,bundle):
    s=Store(workspace);r=request();rid=s.create(r,bundle)
    assert s.get(rid)['state']['request']['goal']==r.goal
    for f in workspace.glob('state.sqlite3*'):assert r.goal.encode() not in f.read_bytes()
    assert s.events(rid)[0]['type']=='created'

def test_one_process_claims(workspace,bundle):
    s=Store(workspace);rid=s.create(request(),bundle)
    with concurrent.futures.ProcessPoolExecutor(max_workers=3,mp_context=multiprocessing.get_context('spawn')) as pool:
        results=list(pool.map(competing_claim,[(str(workspace),rid,'w'+str(i)) for i in range(3)]))
    assert sum(v!='conflict' for v in results)==1

def test_expired_worker_fenced(workspace,bundle):
    s=Store(workspace);rid=s.create(request(),bundle);f=s.claim(rid,'old',lease_seconds=.01)
    time.sleep(.03);new=s.claim(rid,'new')
    assert new>f
    with pytest.raises(Conflict):s.reserve(rid,'old',f,{},1)

def test_revision_and_request_immutable(workspace,bundle):
    s=Store(workspace);rid=s.create(request(),bundle);f=s.claim(rid,'w');state=s.get(rid)['state']
    rev=s.save(rid,'w',f,0,state)
    with pytest.raises(Conflict):s.save(rid,'w',f,0,state)
    state['request']['goal']='easier goal'
    with pytest.raises(ValueError):s.save(rid,'w',f,rev,state)

def test_root_budget_across_processes(workspace,bundle):
    s=Store(workspace);rid=s.create(request(max_actions=4),bundle);f=s.claim(rid,'w')
    with concurrent.futures.ProcessPoolExecutor(max_workers=4,mp_context=multiprocessing.get_context('spawn')) as pool:
        result=list(pool.map(reserve_from_process,[(str(workspace),rid,'w',f)]*9))
    assert sum(result)==4 and s.get(rid)['calls']==4

def test_nested_calls_debit_ancestors(workspace,bundle):
    s=Store(workspace);p=s.create(request(max_actions=2,max_units=5),bundle);pf=s.claim(p,'p')
    r=s.create(request(),bundle,parent_id=p);f=s.claim(r,'c')
    s.reserve(r,'c',f,{},3)
    assert s.get(p)['units']==s.get(r)['units']==3
    with pytest.raises(BudgetExceeded):s.reserve(r,'c',f,{},3)
    assert s.get(p)['calls']==1

def test_unknown_outcome_not_retried(workspace,bundle):
    s=Store(workspace);r=s.create(request(),bundle);f=s.claim(r,'w')
    s.reserve(r,'w',f,{'side_effect':'external-update'},1)
    assert s.abort_pending(r,'w',f)==1
    assert s.operations(r)[0]['status']=='outcome_unknown'
    assert s.abort_pending(r,'w',f)==0

def test_duplicate_completion_rejected(workspace,bundle):
    s=Store(workspace);r=s.create(request(),bundle);f=s.claim(r,'w');oid=s.reserve(r,'w',f,{},1)
    s.complete_operation(oid,r,'w',f,{'ok':True})
    with pytest.raises(Conflict):s.complete_operation(oid,r,'w',f,{'ok':True})

def test_cancel_fences_descendants(workspace,bundle):
    s=Store(workspace);p=s.create(request(),bundle);s.claim(p,'p');c=s.create(request(),bundle,parent_id=p);f=s.claim(c,'c')
    s.cancel(p)
    assert s.get(p)['status']==s.get(c)['status']=='cancelled'
    assert not s.execution_current(c,'c',f)
    with pytest.raises(KeyError):s.cancel('not-a-run')

def test_audit_tampering_detected(workspace,bundle):
    s=Store(workspace);rid=s.create(request(),bundle)
    with sqlite3.connect(s.path) as c:c.execute("UPDATE events SET chain='false' WHERE run_id=?",(rid,))
    with pytest.raises(ValueError):s.events(rid)

def test_renamed_input_cannot_cross_split(workspace):
    s=Store(workspace);a=request(doc_id='a');b=request(doc_id='renamed')
    fp=s.register_eval_input(a,'x','train')
    with pytest.raises(ValueError):s.register_eval_input(b,'x','test')
    assert fp==s.register_eval_input(b,'y','train')

def test_holdout_consumption_atomic(workspace):
    s=Store(workspace);s.consume_test(['a'],'ev1')
    with pytest.raises(ValueError):s.consume_test(['b','a'],'ev2')
    s.consume_test(['b'],'ev3')

def test_self_attested_success_not_promotable(workspace,bundle):
    s=Store(workspace);s.add_bundle(bundle)
    with pytest.raises(PermissionError):s.promote(bundle.sha256,None)
    eid=s.record_evaluation(bundle.sha256,None,{'split':'test','passed':True,'run_ids':['fake']})
    with pytest.raises(ValueError):s.attest(bundle.sha256,eid)

def test_promotion_cas_and_rollback(workspace,bundle):
    s=Store(workspace)
    for i,b in enumerate([bundle,bundle.model_copy(update={'version':'v2','parent':bundle.sha256})]):
        rid=completed(s,b,request(i));eid=s.record_evaluation(b.sha256,None,{'split':'test','passed':True,'run_ids':[rid]})
        s.attest(b.sha256,eid)
        native_certificate_fixture(s,b.sha256)
        if i==0:first=b.sha256;s.promote(first,None)
        else:second=b.sha256;s.promote(second,first)
    with pytest.raises(Conflict):s.promote(first,first)
    s.promote(first,second);assert Store(workspace).active()==first

def test_revocation_reaches_bundle(workspace,bundle):
    s=Store(workspace);r=request(label='restricted');rid=completed(s,bundle,r)
    derived=bundle.model_copy(update={'version':'derived','dataset_lineage':(rid,)})
    s.add_bundle(derived);fp=digest(r.inputs[0].content)
    s.invalidate_lineage(fp,[])
    assert s.is_revoked(derived.sha256)
    with pytest.raises(PermissionError):s.create(r,bundle)


def test_successful_output_alone_cannot_bypass_all_engine_gate(workspace,bundle):
    s=Store(workspace);rid=completed(s,bundle,request())
    eid=s.record_evaluation(bundle.sha256,None,{'split':'test','passed':True,'run_ids':[rid]})
    s.attest(bundle.sha256,eid)
    with pytest.raises(PermissionError,match='all-engine'):s.promote(bundle.sha256,None)
    with pytest.raises(ValueError,match='all native'):s.attest_native(bundle.sha256,[])
