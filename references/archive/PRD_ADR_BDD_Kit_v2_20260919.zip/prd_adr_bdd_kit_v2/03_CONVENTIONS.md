# 共通規約：正本・ID・関係・状態・記法

## 1. 3つの文書の分担

| 文書 | 答える問い | 書かないこと |
|---|---|---|
| PRD | 誰の何のために、どの能力を、どの品質で提供するか。どう成功を測るか | 方式・製品名・内部パラメータ（→ADR）、API やスキーマの詳細（→SPEC） |
| ADR | この制約のもとで、なぜその設計を選び、何を引き受けるか | 要件そのもの（→PRD）、実装手順や設計の全体像（→SPEC） |
| BDD | この条件でこの出来事が起きたら、何が観察できれば正しいか | 画面操作の手順、内部のデータ確認、試験上の仕掛け（→自動化コード） |

```mermaid
flowchart LR
    accTitle: 文書と生成物の関係
    accDescr: PRDの要件をBDDのルールが具体化し、ADRが設計判断で応える。追跡表と.featureは正本から生成される。
    PRD["PRD：目的・要件"] -->|"受入：RULE-ID"| BDD["BDD：ルール・具体例"]
    BDD -->|"タグ：FR-ID"| PRD
    ADR["ADR：設計判断"] -->|"addresses：FR-ID"| PRD
    PRD -->|"論点：ADR-ID"| ADR
    BDD -.->|"extract"| F[".feature（生成物）"]
    PRD -.->|"trace"| T["追跡表（生成物）"]
    BDD -.-> T
    ADR -.-> T
```

小さな変更が具体例から始まっても、設計の論点から始まってもよい。順番は固定しない。固定するのは「同じ情報の正本は1か所」だけである。

## 2. 正本

| 情報 | 正本 | 他の文書での扱い |
|---|---|---|
| 目的・指標・要件（FR／NFR）・検証計画（NVT） | PRD | IDで参照する。要求文を写さない |
| 要件と設計判断の対応 | ADR の front matter `addresses` | 追跡表は生成する |
| 要件とルールの対応 | PRD の「受入」列と、シナリオの `@FR-nnn` タグ（両方に書き、リンターが一致を検査） | 追跡表は生成する |
| 期待する振る舞い | BDD のルールとシナリオ | 実装やテストコードから逆算して書き換えない |
| Gherkin | front matter `gherkin_source` が指す側（`markdown` または `feature`） | 反対側は生成物。手で直さない |
| 追跡表・.feature | 生成物 | 手で直すと check が不合格にする |

## 3. ID

| 種類 | 形式 | 置き場 | 規則 |
|---|---|---|---|
| 目的・指標・ガードレール | GOAL-001・KPI-001・GRD-001 | PRD 3章 | — |
| 根拠・主体・リスク | EVID-001・ACT-001・RISK-001 | PRD | — |
| 要件 | FR-001・NFR-001 | PRD 7・8章。表の先頭セルに `<a id="FR-001"></a>` を置く | 1要件1ID。意味を変えたら新しいIDにする |
| 専用検証 | NVT-001 | PRD 9章 | 計画のID。実行結果のIDではない |
| 設計判断 | ADR-0001 | ファイル名と front matter | 連番。欠番を埋めない |
| 機能・ルール・シナリオ | FEAT-001・RULE-001・SCN-001 | Gherkin のタグ | そのまま `@RULE-001` と書く |
| 質問 | Q-001 | BDD 2章 | — |

IDは削除しても再利用しない。複数の製品を同じ場所で管理するなら `PAY-FR-001` のように接頭辞を付ける（リンターの ID パターンは接頭辞に対応していないため、その場合は `kit_lint.py` の `ID` を変更する）。

## 4. 関係の種類

| 関係 | 向き | 成立の条件 | 出所 |
|---|---|---|---|
| motivates | GOAL／KPI／GRD → FR | FR の「根拠」に書かれている | PRD |
| measures | FR → KPI | KPI の「計測手段」に書かれている | PRD |
| specifies | RULE／SCN → FR | 受入列とタグが一致している | PRD・BDD |
| addresses | ADR → FR／NFR | `addresses` に書かれている | ADR |
| plans-to-verify | NVT → NFR／FR | 検証計画に書かれている | PRD |
| verifies | 実行証跡 → SCN／NVT | 対象の版・環境・日時・結果を持つ実行記録がある | 実行証跡（本キットの範囲外） |
| supersedes | 新ADR → 旧ADR | 双方の front matter に書かれている | ADR |

タグが付いているだけの状態は specifies であって verifies ではない。

## 5. 状態

| 対象 | 状態 | 誤解してはいけないこと |
|---|---|---|
| PRD | draft → in_review → approved → retired | approved は製品の合格でも効果の実証でもない |
| ADR | proposed → accepted ／ rejected、accepted → deprecated ／ superseded | accepted は実装済みを意味しない。deprecated は使うのをやめた、superseded は後継に置き換えた |
| BDD | draft → agreed | agreed は関係者の合意で、試験の合格ではない |
| 自動化・実行 | `automation`：not_implemented／implemented、`last_run`：not_run／passed／failed | 未定義・保留・スキップを passed に読み替えない |
| サンプル | front matter `sample: true` | 架空であることは status ではなくこのキーで示す |

承認は、承認者・日時・対象の版・条件を変更履歴の表に書く。役職名だけの記載や、AI が生成した承認欄は承認ではない。

## 6. ゲート

| ゲート | 単位 | 通過の条件 |
|---|---|---|
| G1 実装着手 | 対象スライス | 要件・ルール・具体例が合意済み。必要な ADR が accepted。未決事項に保留範囲がある |
| G2 受入 | 実装した版 | シナリオと G2 対象の NVT を実行して合格。逸脱は判定者が記録 |
| G3 本番導入 | リリース | 運用・復旧・移行・権限の確認 |
| G4 成果評価 | 利用期間 | KPI・ガードレール・SLO の実測に基づく継続・改修・撤回の判断 |

未決の部分だけを保留し、独立した部分の調査や試作は止めない。

## 7. Markdown と Mermaid

| 項目 | 規則 |
|---|---|
| 文字コードと改行 | UTF-8、末尾に改行 |
| 見出し | H1 は1つ。階層を飛ばさない |
| リンク | 相対パス。文書内の位置は明示アンカー `<a id="..."></a>` にだけ張る（見出しから自動生成されるアンカーは表示環境によって異なる） |
| 表 | 列数を揃える。セルに縦棒を書かない |
| front matter | テンプレートと同じキーを持つ（サンプルは `sample: true` を追加） |
| 図の種類 | flowchart、sequenceDiagram、stateDiagram-v2 に限る |
| 図の書き方 | ノードIDは英数字、ラベルは二重引用符で囲む。`click`・HTML・スクリプトを書かない。`accTitle` と `accDescr` を必ず書く |
| 図と本文 | 図は本文の説明であり、仕様を図だけで決めない。食い違えば本文が正しい |
| Mermaid の版 | 12.0.0 から既定のレイアウトと見た目が変わったため、ノードの位置や色に意味を持たせない。配置を固定したい図だけ、図の先頭に設定（`layout: dagre` など）を書く。表示環境が採用している版は環境ごとに確認する |

## 8. 検証コマンド

| コマンド | 内容 |
|---|---|
| `python tools/kit_lint.py check` | 全検査。不合格なら終了コード1 |
| `python tools/kit_lint.py trace` | 追跡表を生成 |
| `python tools/kit_lint.py extract` | Markdown の Gherkin から `features/*.feature` を生成 |
| `python tools/kit_lint.py selftest` | 欠陥を注入してリンターが検出できるかを確認 |
| `python tools/render_mermaid.py --mermaid-dir <mermaidパッケージ>` | 全図を解析・描画し、図ごとのハッシュ付きで証跡を記録 |

依存は `gherkin-official` と `PyYAML`（描画は `playwright` と npm の `mermaid`）。自分の案件で使うときは `kit.toml` の `[docs]` を自分の文書のパスに書き換える。
