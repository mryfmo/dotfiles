<!-- 自動生成：python tools/kit_lint.py trace。手で編集しない（check が差分を不合格にする）。 -->
# 追跡表：要件→ルール→シナリオ→設計判断→専用検証

ルールとシナリオは要件を**具体化**（specifies）するだけで、合格を意味しない。実行結果がないため、検証済み（verifies）の関係は1件も発行していない。

## 機能要件

| 要件 | 優先度 | ルール | シナリオ | 設計判断 | 専用検証 |
|---|---|---|---|---|---|
| [FR-001](prd/PRD_SAMPLE.md#FR-001) | Must | RULE-003, RULE-012 | SCN-008, SCN-010, SCN-024 | — | NVT-002 |
| [FR-002](prd/PRD_SAMPLE.md#FR-002) | Must | RULE-003 | SCN-007, SCN-009 | — | — |
| [FR-003](prd/PRD_SAMPLE.md#FR-003) | Must | RULE-001 | SCN-001, SCN-003, SCN-004 | — | — |
| [FR-004](prd/PRD_SAMPLE.md#FR-004) | Must | RULE-001 | SCN-002, SCN-003, SCN-005 | — | — |
| [FR-005](prd/PRD_SAMPLE.md#FR-005) | Must | RULE-002 | SCN-006 | — | — |
| [FR-006](prd/PRD_SAMPLE.md#FR-006) | Must | RULE-004 | SCN-011 | — | — |
| [FR-007](prd/PRD_SAMPLE.md#FR-007) | Must | RULE-005 | SCN-012 | — | — |
| [FR-008](prd/PRD_SAMPLE.md#FR-008) | Must | RULE-006 | SCN-013, SCN-014 | ADR-0001 | — |
| [FR-009](prd/PRD_SAMPLE.md#FR-009) | Must | RULE-007 | SCN-015 | — | — |
| [FR-010](prd/PRD_SAMPLE.md#FR-010) | Must | RULE-007 | SCN-016 | ADR-0001 | — |
| [FR-011](prd/PRD_SAMPLE.md#FR-011) | Must | RULE-008 | SCN-017, SCN-018 | — | — |
| [FR-012](prd/PRD_SAMPLE.md#FR-012) | Must | RULE-009 | SCN-019 | — | — |
| [FR-013](prd/PRD_SAMPLE.md#FR-013) | Must | RULE-010 | SCN-020, SCN-021 | — | — |
| [FR-014](prd/PRD_SAMPLE.md#FR-014) | Must | RULE-011 | SCN-022 | ADR-0002 | NVT-010 |
| [FR-015](prd/PRD_SAMPLE.md#FR-015) | Must | RULE-012 | SCN-023, SCN-024, SCN-025 | ADR-0002 | — |
| [FR-016](prd/PRD_SAMPLE.md#FR-016) | Must | RULE-013 | SCN-026, SCN-027 | ADR-0002 | — |
| [FR-017](prd/PRD_SAMPLE.md#FR-017) | Should | RULE-014 | SCN-028 | ADR-0002 | — |
| [FR-018](prd/PRD_SAMPLE.md#FR-018) | Must | RULE-015 | SCN-029 | — | — |
| [FR-019](prd/PRD_SAMPLE.md#FR-019) | Must | RULE-016 | SCN-030 | — | — |
| [FR-020](prd/PRD_SAMPLE.md#FR-020) | Must | RULE-017 | SCN-031 | — | — |
| [FR-021](prd/PRD_SAMPLE.md#FR-021) | Must | RULE-018 | SCN-032, SCN-033 | — | NVT-009 |
| [FR-022](prd/PRD_SAMPLE.md#FR-022) | Must | RULE-019 | SCN-034, SCN-035 | — | — |
| [FR-023](prd/PRD_SAMPLE.md#FR-023) | Could | RULE-019 | SCN-036 | — | — |
| [FR-024](prd/PRD_SAMPLE.md#FR-024) | Must | RULE-020 | SCN-037 | ADR-0001 | — |
| [FR-025](prd/PRD_SAMPLE.md#FR-025) | Should | RULE-021 | SCN-038 | — | — |
| [FR-026](prd/PRD_SAMPLE.md#FR-026) | Must | — | — | — | NVT-011 |
| [FR-027](prd/PRD_SAMPLE.md#FR-027) | Must | RULE-022 | SCN-040 | — | — |
| [FR-028](prd/PRD_SAMPLE.md#FR-028) | Must | RULE-023 | SCN-041, SCN-042 | — | — |

## 非機能要件

| 要件 | 品質特性 | 専用検証 | シナリオ | 設計判断 |
|---|---|---|---|---|
| [NFR-001](prd/PRD_SAMPLE.md#NFR-001) | 性能効率性 | NVT-001 | — | — |
| [NFR-002](prd/PRD_SAMPLE.md#NFR-002) | セキュリティ（機密性・完全性） | NVT-002 | — | — |
| [NFR-003](prd/PRD_SAMPLE.md#NFR-003) | 信頼性（可用性） | NVT-003 | — | — |
| [NFR-004](prd/PRD_SAMPLE.md#NFR-004) | 信頼性（回復性） | NVT-004 | — | — |
| [NFR-005](prd/PRD_SAMPLE.md#NFR-005) | 性能効率性（時間効率性） | NVT-005 | — | ADR-0002 |
| [NFR-006](prd/PRD_SAMPLE.md#NFR-006) | インタラクション能力 | NVT-006 | — | — |
| [NFR-007](prd/PRD_SAMPLE.md#NFR-007) | 機能適合性（AIの正確性） | NVT-007 | — | — |
| [NFR-008](prd/PRD_SAMPLE.md#NFR-008) | セキュリティ（責任追跡性） | NVT-008 | — | — |
| [NFR-009](prd/PRD_SAMPLE.md#NFR-009) | セキュリティ（機密性） | NVT-009 | — | — |

## ルール

| ルール | 業務ルール | シナリオ | 要件 |
|---|---|---|---|
| RULE-001 | 入力規則を満たす下書きだけが提出できる | SCN-001, SCN-002, SCN-003, SCN-004, SCN-005 | FR-003, FR-004 |
| RULE-002 | 提出済みの内容は直接編集できない | SCN-006 | FR-005 |
| RULE-003 | 権限のない相手には申請の内容も存在も明かさない | SCN-007, SCN-008, SCN-009, SCN-010 | FR-001, FR-002 |
| RULE-004 | 参考意見は出典付きの参考情報として示す | SCN-011 | FR-006 |
| RULE-005 | 出典で裏付けられない主張は未確認と示す | SCN-012 | FR-007 |
| RULE-006 | AIは申請の状態を変えられない | SCN-013, SCN-014 | FR-008 |
| RULE-007 | AIが使えなくても人の審査は続けられる | SCN-015, SCN-016 | FR-009, FR-010 |
| RULE-008 | 有効な審査者は他人の提出済み申請を理由付きで決裁できる | SCN-017, SCN-018 | FR-011 |
| RULE-009 | 審査者は自分が提出した申請を決裁できない | SCN-019 | FR-012 |
| RULE-010 | 古い版に対する決裁は成立しない | SCN-020, SCN-021 | FR-013 |
| RULE-011 | 決裁と監査記録は必ず対で成立する | SCN-022 | FR-014 |
| RULE-012 | 同じ決裁要求の再送で決裁は重複しない | SCN-023, SCN-024, SCN-025 | FR-001, FR-015 |
| RULE-013 | 確定した決裁は申請者に1件だけ通知される | SCN-026, SCN-027 | FR-016 |
| RULE-014 | 届けられない通知は運用者が把握できる | SCN-028 | FR-017 |
| RULE-015 | 申請者は終端前の自分の申請を取り消せる | SCN-029 | FR-018 |
| RULE-016 | 差戻された申請の修正は新しい内容版になる | SCN-030 | FR-019 |
| RULE-017 | 終端状態の決裁は変更できない | SCN-031 | FR-020 |
| RULE-018 | 終端から90日で本文は削除対象になる | SCN-032, SCN-033 | FR-021 |
| RULE-019 | 放置された申請は自動で取り消される | SCN-034, SCN-035, SCN-036 | FR-022, FR-023 |
| RULE-020 | 停止中は新しい参考意見を受け付けない | SCN-037 | FR-024 |
| RULE-021 | 停止前に始まった結果は停止後に採用しない | SCN-038 | FR-025 |
| RULE-022 | 参考意見は作成時の内容版にだけ結び付く | SCN-040 | FR-027 |
| RULE-023 | 複数の拒否条件に当たる要求には決まった優先順位の理由だけを返す | SCN-041, SCN-042 | FR-028 |
